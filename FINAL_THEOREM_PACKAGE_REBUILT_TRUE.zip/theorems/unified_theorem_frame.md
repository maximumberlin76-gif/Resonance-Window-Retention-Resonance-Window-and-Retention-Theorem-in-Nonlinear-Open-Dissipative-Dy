# Unified Theorem Frame

## One Framework, Two Theorems

```text
1. Resonance Window Theorem
2. Hybrid Retention Theorem
```

## Shared Invariants

```text
Invariant 1:
Θ_N = Σ W_period(k) ≥ Θ_crit

Invariant 2:
∫(C(t) − P(t)) dt > 0 over completed periods
```

where:

```text
C(t) — general endogenous structural coherence and regenerative support of retained organizational persistence.
P(t) — dissipative loss, destabilizing pressure, fragmentation pressure, or structural degradation load.
```

## Functional Difference

```text
Resonance Window Theorem:
defines admissible state selection.

Hybrid Retention Theorem:
defines channel-separated stabilization of the selected state.
```

## Unified Core

```text
Resonance is the process.
R is an indicator.
Ω(t) is the admissible state corridor.
Θ_N is the admission criterion.
Ω_ret is the retained domain.
Retention completes the window.
Hybrid control is the engineering pathway.
```

## Hybrid Extension

```text
Ω(t) → Ω(t, μ_env, χ_mix)
```

where:

```text
μ_env  = medium/environment parameter
χ_mix  = mixture composition vector
```

## Generalized Critical Ramp-Scaling Support

```text
dC/dt = vtC − gC^n
t_delay ~ v^(−1/2)
C_critical ~ g^(−1/(n−1))v^(1/(2(n−1)))
```

Under geometric dimensional closure:

```text
V_coh,d ∝ C^d
n = d
V_coh,3 ∝ C³
```
