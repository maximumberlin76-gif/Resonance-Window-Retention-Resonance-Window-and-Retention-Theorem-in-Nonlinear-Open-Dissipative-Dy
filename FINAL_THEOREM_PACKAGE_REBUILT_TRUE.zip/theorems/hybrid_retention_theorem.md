# Hybrid Retention Theorem

The theorem defines a candidate channel-separation architecture.

Corrected v35.2 screening anchor:

screening_candidate: 242

em_only → hybrid_em_retention → hybrid_balanced → hybrid_soft → acoustic_only

The screening ranking does not dynamically validate physical channel superiority.
