# Reproducibility Matrix

## Required Per Experiment

Each experiment package must contain:

```text
README
configs
scripts
results
equations/model
journal
validation
checksums
logs
```

## Upload Rule

Before GitHub upload:

```text
1. Open ZIP.
2. Check file structure.
3. Check for scripts/config/results.
4. Check README and conclusion.
5. Check validation/checksums.
6. Upload only if complete.
```

## GitHub Principle

The repository is a proof-path archive.

Commit history must preserve:

```text
sequence
proof logic
reproducibility
variability
```

## Directory-Name Boundary

The `validation/` directory name denotes execution checks, package-integrity records, and declared acceptance checks. It does not by itself assert independent physical validation.
