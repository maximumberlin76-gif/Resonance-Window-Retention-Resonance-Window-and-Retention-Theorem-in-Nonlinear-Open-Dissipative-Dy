# GitHub Upload Order

## Commit 1 — Core theorem layer

```text
FINAL_THEOREM_PACKAGE_ENHANCED_TRUE.zip
```

Commit message:

```text
Add unified resonance window and hybrid retention theorem package
```

## Commit 2 — Hybrid regime matrix

```text
resonance_system_v35_HYBRID_MULTI_GAS_REGIME_MATRIX_TRUE.zip
```

## Commit 3 — Acoustic + EM retention

```text
resonance_system_v35_1_AR_HE_HYBRID_ACOUSTIC_EM_RETENTION_TRUE.zip
```

## Commit 4 — Deep hybrid configuration screening

```text
resonance_system_v35_2_AR_HE_H_DEEP_HYBRID_TESTS_TRUE.zip
```

## Commit 5 — Retention theorem package

```text
resonance_system_v35_3_HYBRID_RETENTION_THEOREM_PACKAGE_TRUE.zip
```
