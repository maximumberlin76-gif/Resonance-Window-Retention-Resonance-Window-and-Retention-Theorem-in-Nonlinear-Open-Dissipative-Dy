# Resonance Properties

## Property 1 — Not Instantaneous

Synthesis is not immediate.

It occurs through accumulation over completed periods.

## Property 2 — Not Arbitrary Control

Resonance windows define admissible state regions.

They do not grant arbitrary control over matter.

## Property 3 — Work-Based Admission

A state enters the window only if accumulated positive work exceeds the threshold.

## Property 4 — Retention-Based Acceptance

A state is valid only if it remains stable after external drive reduction.

## Property 5 — Indicator Separation

R(t) may indicate phase alignment or synchronization accessibility.

R(t) does not prove synthesis by itself.

The admission criterion is Θ_N.

Retention completes the window.

## Property 6 — Medium Dependence

For hybrid or molecular systems:

```text
Ω(t) → Ω(t, μ_env, χ_mix)
```
