# Session Journal — v35

Hybrid Multi-Gas Regime Matrix.

User requested hybrid mode:
argon, helium, hydrogen, oxygen, methane, carbon dioxide.

Added Ω(t, μ_env, χ_mix).
