# Session Journal — v35

Hybrid Multi-Gas Regime Matrix.

User requested hybrid mode:
argon, helium, hydrogen, oxygen, methane, carbon dioxide.

Added Ω(t, μ_env, χ_mix).

## Evidence Classification Correction — 2026-07-29

The package is classified as a deterministic design-space prioritization matrix.

## Public-Language Closure — 2026-07-29

The former validity-labelled input field was renamed to `legacy_reference_ratio`.

The numerical values and prioritization equations were not changed.
