# v35 Configured Prioritization Equations

Ω(t) → Ω(t, μ_env, χ_mix)

screening_status = candidate_for_dynamic_testing

The status marks a configured candidate only.
