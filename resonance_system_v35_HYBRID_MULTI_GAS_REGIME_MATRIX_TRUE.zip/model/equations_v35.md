# v35 Equations

Ω(t) → Ω(t, μ_env, χ_mix)

valid_window =
Θ_N >= Θ_crit
and
(C - P)_periodic > 0
and
retention holds
and
chemistry overload is bounded

Hybrid principle:
inertial buffer + fast probe + molecular calibration
