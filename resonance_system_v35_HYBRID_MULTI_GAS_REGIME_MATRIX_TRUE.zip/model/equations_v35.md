# v35 Configured Prioritization Equations

Ω(t) → Ω(t, μ_env, χ_mix)

screening_status = candidate_for_dynamic_testing

The status marks a configured candidate only.

Configured reference term:

legacy_reference_ratio = historical package ratio used only as an input coefficient in the prioritization score

The field name does not assert current physical validity.
