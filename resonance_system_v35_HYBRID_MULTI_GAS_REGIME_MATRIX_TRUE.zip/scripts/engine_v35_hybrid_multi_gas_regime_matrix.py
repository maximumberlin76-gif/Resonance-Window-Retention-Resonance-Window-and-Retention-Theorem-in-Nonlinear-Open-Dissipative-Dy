#!/usr/bin/env python3
from __future__ import annotations
import json, argparse
from pathlib import Path

def gas_score(g):
    valid = g["known_valid_ratio"] if g["known_valid_ratio"] is not None else 0.12
    return 1.8*g["retention"] + 1.2*valid + 0.8*g["response_speed"] - 1.0*g["dissipation_risk"] - 0.9*g["chemistry_risk"]

def pair_score(a,b):
    response_gain = abs(a["response_speed"] - b["response_speed"])
    retention_support = max(a["retention"], b["retention"])
    chemistry_penalty = max(a["chemistry_risk"], b["chemistry_risk"])
    diss_penalty = (a["dissipation_risk"] + b["dissipation_risk"]) / 2
    return 1.1*response_gain + 1.2*retention_support - 0.8*chemistry_penalty - 0.6*diss_penalty

def sequence_score(seq, gases):
    gas_terms = sum(gas_score(gases[x]) for x in seq) / len(seq)
    pair_terms = sum(pair_score(gases[seq[i]], gases[seq[i+1]]) for i in range(len(seq)-1)) / max(1, len(seq)-1)
    chemistry_load = sum(gases[x]["chemistry_risk"] for x in seq) / len(seq)
    retention_floor = min(gases[x]["retention"] for x in seq)
    return gas_terms + pair_terms + 0.5*retention_floor - 0.5*chemistry_load

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    gases = cfg["gases"]

    gas_rank = sorted([{"gas":n, "score":gas_score(g), **g} for n,g in gases.items()], key=lambda x:x["score"], reverse=True)

    seqs = []
    for seq in cfg["hybrid_sequences"]:
        sc = sequence_score(seq, gases)
        seqs.append({
            "sequence": seq,
            "score": sc,
            "roles": [gases[x]["role"] for x in seq],
            "anchor_chain_mhz": [gases[x]["anchor_mhz"] for x in seq],
            "screening_status": "candidate_for_dynamic_testing" if sc > 0.35 else "requires_additional_configuration_review"
        })
    seqs.sort(key=lambda x:x["score"], reverse=True)

    corridor = [{"gas":n,"anchor_mhz":g["anchor_mhz"],"primary_band_mhz":g["anchor_mhz"],"second_harmonic_mhz":round(2*g["anchor_mhz"],4),"f_norm_primary":1.0} for n,g in gases.items()]

    summary = {
        "system_class": cfg["system_class"],
        "model_class": cfg["model_class"],
        "evidence_scope": cfg["evidence_scope"],
        "criterion": cfg["criterion"],
        "gas_rank": gas_rank,
        "hybrid_sequence_rank": seqs,
        "normalized_corridor": corridor,
        "main_conclusion": "configured_design_space_priority_is_" + "_then_".join(seqs[0]["sequence"]),
        "recommended_start": {"sequence": seqs[0]["sequence"], "reason": "highest configured score; requires independent dynamic testing"},
        "theorem_note": "The matrix prioritizes configured candidates and does not validate a physical resonance window."
    }

    out = Path(args.outdir); out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"hybrid_multi_gas_regime_matrix_summary.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)

    md = "# Hybrid Multi-Gas Regime Matrix — Summary\n\n"
    md += "## Main conclusion\n\n" + summary["main_conclusion"] + "\n\n"
    md += "## Gas rank\n\n"
    for g in gas_rank:
        md += f"- {g['gas']}: score={g['score']:.4f}, role={g['role']}\n"
    md += "\n## Best hybrid sequences\n\n"
    for s in seqs:
        md += f"- {' → '.join(s['sequence'])}: score={s['score']:.4f}, status={s['screening_status']}\n"
    md += "\n## Theorem note\n\n" + summary["theorem_note"] + "\n"
    (out/"hybrid_multi_gas_regime_matrix_summary.md").write_text(md, encoding="utf-8")

    print(json.dumps({"recommended_start": summary["recommended_start"], "top_sequences": seqs[:3], "top_gases": gas_rank[:3]}, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
