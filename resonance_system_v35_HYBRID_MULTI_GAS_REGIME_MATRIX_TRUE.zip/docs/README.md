# v35 — Hybrid Multi-Gas Regime Matrix

## Abstract

This module starts the hybrid gas-regime layer for:

```text
Argon → Helium → Hydrogen → Oxygen → Methane → Carbon Dioxide
```

The system class remains:

```text
nonlinear dissipative open dynamic systems
```

This is the hybrid regime matrix used to decide the next simulation sequence.

## Core Principle

```text
R is an indicator.
Θ_N is the admission criterion.
Retention completes the window.
Chemistry loss can close the window.
```

## Hybrid Extension

```text
Ω(t) → Ω(t, μ_env, χ_mix)
```

where:

```text
μ_env  = medium/environment parameter
χ_mix  = mixture composition vector
```

## Run

```bash
python scripts/engine_v35_hybrid_multi_gas_regime_matrix.py --outdir results
python tests/smoke_test.py
```
