# v35 — Hybrid Multi-Gas Design-Space Prioritization

Classification: deterministic design-space prioritization matrix.

This package ranks configured gas and sequence candidates. It does not integrate plasma dynamics through time and does not constitute dynamic validation.
