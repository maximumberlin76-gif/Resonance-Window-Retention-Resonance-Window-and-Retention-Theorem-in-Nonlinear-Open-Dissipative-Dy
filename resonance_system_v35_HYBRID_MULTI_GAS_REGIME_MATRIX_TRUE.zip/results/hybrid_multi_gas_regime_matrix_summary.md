# Hybrid Multi-Gas Regime Matrix — Summary

## Main conclusion

configured_design_space_priority_is_argon_then_helium_then_hydrogen

## Gas rank

- argon: score=1.9683, role=retention buffer / inertial stabilizer
- helium: score=1.4350, role=fast response / drift probe
- hydrogen: score=0.8877, role=extreme speed / high mobility stress test
- carbon_dioxide: score=-0.0980, role=heavy molecular vibrational-loss stress test
- oxygen: score=-0.1140, role=reactive molecular plasma / oxidation channel
- methane: score=-0.3635, role=hydrocarbon dissociation-recombination stress test

## Best hybrid sequences

- argon → helium → hydrogen: score=2.2278, status=candidate_for_dynamic_testing
- helium → hydrogen → argon: score=2.1403, status=candidate_for_dynamic_testing
- argon → helium → oxygen: score=1.8108, status=candidate_for_dynamic_testing
- argon → helium → hydrogen → oxygen → methane → carbon_dioxide: score=0.6978, status=candidate_for_dynamic_testing
- argon → carbon_dioxide → methane: score=0.4463, status=candidate_for_dynamic_testing
- argon → methane → carbon_dioxide: score=0.3873, status=candidate_for_dynamic_testing

## Theorem note

The matrix prioritizes configured candidates and does not validate a physical resonance window.
