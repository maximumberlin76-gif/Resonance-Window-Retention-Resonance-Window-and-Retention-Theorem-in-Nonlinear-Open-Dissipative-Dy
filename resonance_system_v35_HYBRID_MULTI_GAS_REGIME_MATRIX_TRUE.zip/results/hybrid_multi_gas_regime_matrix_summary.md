# Hybrid Multi-Gas Regime Matrix — Summary

## Main conclusion

hybrid_regime_should_use_inertial_buffer_plus_fast_probe_plus_molecular_calibration

## Gas rank

- argon: score=1.9683, role=retention buffer / inertial stabilizer
- helium: score=1.4350, role=fast response / drift probe
- hydrogen: score=0.8877, role=extreme speed / high mobility stress test
- carbon_dioxide: score=-0.0980, role=heavy molecular vibrational-loss stress test
- oxygen: score=-0.1140, role=reactive molecular plasma / oxidation channel
- methane: score=-0.3635, role=hydrocarbon dissociation-recombination stress test

## Best hybrid sequences

- argon → helium → hydrogen: score=2.2278, mode=hybrid_window_candidate
- helium → hydrogen → argon: score=2.1403, mode=hybrid_window_candidate
- argon → helium → oxygen: score=1.8108, mode=hybrid_window_candidate
- argon → helium → hydrogen → oxygen → methane → carbon_dioxide: score=0.6978, mode=hybrid_window_candidate
- argon → carbon_dioxide → methane: score=0.4463, mode=hybrid_window_candidate
- argon → methane → carbon_dioxide: score=0.3873, mode=hybrid_window_candidate

## Theorem note

For hybrid gas mixtures Ω(t) must be extended to Ω(t, μ_env, χ_mix), where μ_env captures medium parameters and χ_mix captures mixture composition.
