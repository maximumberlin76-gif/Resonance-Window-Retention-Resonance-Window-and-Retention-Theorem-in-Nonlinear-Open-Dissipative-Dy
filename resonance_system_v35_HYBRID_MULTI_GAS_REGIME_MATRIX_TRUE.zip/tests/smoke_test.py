#!/usr/bin/env python3
from pathlib import Path
import json
p = Path("results/hybrid_multi_gas_regime_matrix_summary.json")
assert p.exists() and p.stat().st_size > 100
s = json.load(open(p, "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "hybrid_sequence_rank" in s
assert s["model_class"] == "deterministic_design_space_prioritization_matrix"
assert all("expected_mode" not in row for row in s["hybrid_sequence_rank"])
cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
former_key = "known" + "_valid_ratio"
assert former_key not in json.dumps(s, ensure_ascii=False)
assert former_key not in json.dumps(cfg, ensure_ascii=False)
assert all("legacy_reference_ratio" in gas for gas in cfg["gases"].values())
print("SMOKE_OK")
