# Core equations
R_net = P_in * η - D