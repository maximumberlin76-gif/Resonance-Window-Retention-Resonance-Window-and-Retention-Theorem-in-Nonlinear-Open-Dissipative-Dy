v35.3 HYBRID RETENTION THEOREM PACKAGE

Contains the theorem text and the corrected v35.2 screening package.
