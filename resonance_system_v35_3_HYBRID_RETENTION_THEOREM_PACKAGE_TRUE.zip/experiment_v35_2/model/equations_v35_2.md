# v35.2 Algebraic Screening Equations

screening_candidate = Θ_N_proxy and balance_proxy and retention_tail_proxy and stable_periods_proxy and collapse_risk_proxy

A screening candidate requires independent dynamic testing.
