# Session Journal — v35.2

## Step

Ar-He-H Deep Hybrid Tests.

## Reason

User requested deeper testing and larger test count for the acoustic-entry / EM-retention hybrid model.

## Added

- larger Monte Carlo matrix
- five channel modes
- six stress scenarios
- explicit failure modes
- channel and scenario ranking

## Evidence Classification Correction — 2026-07-29

The package is classified as Monte Carlo configuration screening.

The corrected internal ranking is led by `em_only`, followed by `hybrid_em_retention` and `hybrid_balanced`.
