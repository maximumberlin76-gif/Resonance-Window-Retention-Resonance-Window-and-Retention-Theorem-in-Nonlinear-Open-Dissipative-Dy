# Ar-He-H Monte Carlo Configuration Screening — Summary

Total screening trials: 720

## Configured channel ranking

- em_only: candidate_ratio=0.895833, retention=0.757252, collapse=0.08475
- hybrid_em_retention: candidate_ratio=0.645833, retention=0.646982, collapse=0.131563
- hybrid_balanced: candidate_ratio=0.131944, retention=0.549538, collapse=0.175102
- hybrid_soft: candidate_ratio=0.006944, retention=0.457418, collapse=0.208994
- acoustic_only: candidate_ratio=0.0, retention=0.095031, collapse=0.370574

## Best scenarios

- baseline_argon_buffer: candidate_ratio=0.491667, theta_N=0.81448
- low_cost_acoustic_entry: candidate_ratio=0.458333, theta_N=0.805758
- high_drift_hydrogen: candidate_ratio=0.341667, theta_N=0.768916
- retention_hard_cut: candidate_ratio=0.3, theta_N=0.77701
- hydrogen_fast_probe: candidate_ratio=0.275, theta_N=0.761195
- helium_first_transfer: candidate_ratio=0.15, theta_N=0.728726
