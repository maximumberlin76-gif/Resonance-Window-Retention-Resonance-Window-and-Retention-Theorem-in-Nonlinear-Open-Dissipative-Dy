# v35.2 — Ar-He-H Monte Carlo Configuration Screening

Classification: Monte Carlo configuration screening model.

The package propagates configured coefficients through algebraic screening equations with seeded perturbations. It does not contain time-resolved plasma dynamics or a matched no-drive control.
