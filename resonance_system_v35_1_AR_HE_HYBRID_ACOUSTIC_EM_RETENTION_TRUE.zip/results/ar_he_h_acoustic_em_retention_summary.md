# Ar-He-H Hybrid Acoustic + EM Retention — Summary

## Main conclusion

configured_scoring_ranks_hybrid_for_argon_then_helium_then_hydrogen

## Recommended sequence

argon → helium → hydrogen via `hybrid`

## Protocol

### phase_1: acoustic_entry
- purpose: cheaply push the system toward Ω(t) and begin Θ_N accumulation
- control: track W_period and (C-P)_periodic; do not require full phase lock yet

### phase_2: hybrid_overlap
- purpose: apply low-to-moderate EM assist while acoustic drive continues
- control: increase phase precision without forcing destructive overdrive

### phase_3: em_retention
- purpose: reduce acoustic input and use EM to stabilize retention
- control: verify retention_R_tail, Ω_ret membership, and no collapse after acoustic reduction

### phase_4: drive_reduction
- purpose: test synthesis condition
- control: F_acoustic -> 0 first, then reduce F_EM; accept only if Θ_N and retention persist

## Theorem note

The channel-role separation is a configured engineering hypothesis. This package scores it and does not dynamically validate it.
