# v35.1 — Ar-He-H Hybrid Acoustic + Electromagnetic Retention

## Abstract

This module tests the engineering control concept:

```text
acoustic entry + electromagnetic retention
```

for the hybrid sequence:

```text
Argon → Helium → Hydrogen
```

The system class remains:

```text
nonlinear dissipative open dynamic systems
```

## Core Idea

Argon plasma already shows stronger retention.

Therefore the proposed hybrid strategy is:

```text
Argon = inertial retention buffer
Acoustic channel = cheap entry into Ω(t)
Electromagnetic channel = precision retention / Ω_ret stabilization
Helium/Hydrogen = fast response and drift stress tests
```

## Control Logic

```text
R is an indicator.
Θ_N is the admission criterion.
Retention completes the window.
```

## Four-Phase Protocol

1. Acoustic entry  
2. Hybrid overlap  
3. EM retention  
4. Drive reduction test

## Theorem Extension

Hybrid control separates the channel roles:

```text
acoustic drive → economical Θ_N initiation
EM drive → Ω_ret stabilization
```

## Run

```bash
python scripts/engine_v35_1_ar_he_h_acoustic_em_retention.py --outdir results
python tests/smoke_test.py
```
