#!/usr/bin/env python3
from pathlib import Path
import json
p = Path("results/ar_he_h_acoustic_em_retention_summary.json")
assert p.exists() and p.stat().st_size > 100
s = json.load(open(p, "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "operational_protocol" in s
print("SMOKE_OK")
