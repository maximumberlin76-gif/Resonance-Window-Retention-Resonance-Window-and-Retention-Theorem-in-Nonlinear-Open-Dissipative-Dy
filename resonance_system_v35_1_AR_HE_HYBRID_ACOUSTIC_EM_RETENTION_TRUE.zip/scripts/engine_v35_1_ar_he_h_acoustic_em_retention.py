#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

def gas_channel_score(g, ch):
    return (
        1.4 * g["retention_strength"] * ch["phase_precision"]
        + 1.2 * g["acoustic_entry_efficiency"] * ch["work_accumulation_gain"]
        + 1.0 * g["em_retention_efficiency"] * ch["phase_precision"]
        - 0.8 * g["dissipation_risk"] * ch["dissipation_penalty"]
        - 0.4 * ch["cost_factor"]
    )

def sequence_score(seq, gases, channel):
    scores = [gas_channel_score(gases[g], channel) for g in seq]
    retention_floor = min(gases[g]["retention_strength"] for g in seq)
    dissipation_mean = sum(gases[g]["dissipation_risk"] for g in seq) / len(seq)
    # Reward Ar first as stabilizing buffer.
    entry_bonus = 0.25 if seq[0] == "argon" else 0.0
    return sum(scores)/len(scores) + 0.55*retention_floor - 0.25*dissipation_mean + entry_bonus

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    gases = cfg["gases"]
    channels = cfg["channels"]

    channel_results = {}
    for cname, ch in channels.items():
        channel_results[cname] = {}
        for gname, g in gases.items():
            channel_results[cname][gname] = round(gas_channel_score(g, ch), 6)

    seq_results = []
    for seq in cfg["sequences"]:
        row = {"sequence": seq, "channel_scores": {}}
        for cname, ch in channels.items():
            row["channel_scores"][cname] = round(sequence_score(seq, gases, ch), 6)
        row["best_channel"] = max(row["channel_scores"], key=row["channel_scores"].get)
        row["best_score"] = row["channel_scores"][row["best_channel"]]
        seq_results.append(row)
    seq_results.sort(key=lambda x: x["best_score"], reverse=True)

    protocol = {
        "phase_1": {
            "name": "acoustic_entry",
            "purpose": "cheaply push the system toward Ω(t) and begin Θ_N accumulation",
            "control": "track W_period and (C-P)_periodic; do not require full phase lock yet"
        },
        "phase_2": {
            "name": "hybrid_overlap",
            "purpose": "apply low-to-moderate EM assist while acoustic drive continues",
            "control": "increase phase precision without forcing destructive overdrive"
        },
        "phase_3": {
            "name": "em_retention",
            "purpose": "reduce acoustic input and use EM to stabilize retention",
            "control": "verify retention_R_tail, Ω_ret membership, and no collapse after acoustic reduction"
        },
        "phase_4": {
            "name": "drive_reduction",
            "purpose": "test synthesis condition",
            "control": "F_acoustic -> 0 first, then reduce F_EM; accept only if Θ_N and retention persist"
        }
    }

    summary = {
        "system_class": cfg["system_class"],
        "model_class": cfg["model_class"],
        "evidence_scope": cfg["evidence_scope"],
        "hybrid_mode": cfg["hybrid_mode"],
        "channel_results": channel_results,
        "sequence_results": seq_results,
        "recommended_sequence": seq_results[0],
        "operational_protocol": protocol,
        "main_conclusion": "configured_scoring_ranks_" + seq_results[0]["best_channel"] + "_for_" + "_then_".join(seq_results[0]["sequence"]),
        "theorem_note": "The channel-role separation is a configured engineering hypothesis. This package scores it and does not dynamically validate it."
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"ar_he_h_acoustic_em_retention_summary.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)

    md = "# Ar-He-H Hybrid Acoustic + EM Retention — Summary\n\n"
    md += "## Main conclusion\n\n" + summary["main_conclusion"] + "\n\n"
    md += "## Recommended sequence\n\n"
    md += " → ".join(summary["recommended_sequence"]["sequence"]) + f" via `{summary['recommended_sequence']['best_channel']}`\n\n"
    md += "## Protocol\n\n"
    for k,v in protocol.items():
        md += f"### {k}: {v['name']}\n- purpose: {v['purpose']}\n- control: {v['control']}\n\n"
    md += "## Theorem note\n\n" + summary["theorem_note"] + "\n"
    (out/"ar_he_h_acoustic_em_retention_summary.md").write_text(md, encoding="utf-8")

    print(json.dumps({
        "main_conclusion": summary["main_conclusion"],
        "recommended_sequence": summary["recommended_sequence"],
        "channel_results": channel_results
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
