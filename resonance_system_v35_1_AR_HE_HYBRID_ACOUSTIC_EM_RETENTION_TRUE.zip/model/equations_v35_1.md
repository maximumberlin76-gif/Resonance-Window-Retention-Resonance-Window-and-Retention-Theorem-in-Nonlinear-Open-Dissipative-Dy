# v35.1 Equations

## Hybrid Channel Separation

F_total(t) = F_acoustic(t) + F_EM(t)

## Work Accumulation

Θ_N = Σ W_period(k)

## Engineering Rule

Acoustic:
cheap entry into Ω(t)

Electromagnetic:
phase precision and Ω_ret stabilization

## Valid Window

valid_window =
Θ_N >= Θ_crit
and
(C - P)_periodic > 0
and
retention holds after acoustic reduction and EM reduction
