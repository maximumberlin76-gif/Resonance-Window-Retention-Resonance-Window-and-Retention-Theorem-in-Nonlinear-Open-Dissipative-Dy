# v35.1 Configured Engineering Scoring

F_total(t) = F_acoustic(t) + F_EM(t)

The package does not compute a time-resolved Θ_N trajectory or post-drive dynamics.
