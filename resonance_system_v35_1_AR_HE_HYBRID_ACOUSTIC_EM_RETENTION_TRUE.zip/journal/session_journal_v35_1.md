# Session Journal — v35.1

## Step

Ar-He-H Hybrid Acoustic + EM Retention.

## User premise

Argon plasma has retention.
Acoustic resonance is cheaper than EM.
Hybrid mode should use acoustic for entry and EM for retention.

## Added

- acoustic/EM channel separation
- Ar retention buffer logic
- He/H transfer sequence
- four-phase operational protocol
