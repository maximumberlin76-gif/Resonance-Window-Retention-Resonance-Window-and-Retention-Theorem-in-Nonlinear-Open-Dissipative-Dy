#!/usr/bin/env python3
"""
Resonance System v21 FULL ADAPTIVE GAIN SCHEDULING

v20 reduced smoothing artifacts but overshoot remained too high.
v21 introduces adaptive gain scheduling.

Core idea:
- fixed follow_gain is too crude
- gain must depend on current state:
  tracking_error
  predictive_error
  drift pressure
  previous overshoot
  stability streak

The controller reduces gain when the system risks overshoot
and gradually restores gain after stable tracking.

Computational sandbox only.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path
from typing import Dict, Any, List


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def mean(xs: List[float]) -> float:
    return sum(xs) / max(1, len(xs))


def simulate_trial(trial: Dict[str, Any], cfg: Dict[str, Any], seed: int) -> Dict[str, Any]:
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    window_center = trial.get("f_center", rng.choice([76.4, 150.0, 458.4]))
    f0 = window_center

    C = clamp(trial["reentry_norm"] - trial["new_edge_penalty"])

    gain = cfg["gain"]["base"]
    stable_streak = 0
    overshoot_count = 0
    lock_loss_count = 0
    gain_cut_count = 0
    gain_boost_count = 0

    previous_error = 0.0
    previous_delta = 0.0
    history = [window_center]

    series = []
    collapsed = False
    collapse_at = None

    for t in range(cycles):
        # Floating window movement.
        drift = cfg["floating"]["drift_rate"] * math.sin(2 * math.pi * t / cfg["floating"]["period"])
        jitter = rng.uniform(-cfg["floating"]["jitter"], cfg["floating"]["jitter"])
        window_center += drift + jitter
        history.append(window_center)

        # Simple local drift predictor.
        recent = history[-cfg["predictor"]["history"]:]
        if len(recent) >= 2:
            predicted_drift = (recent[-1] - recent[0]) / (len(recent) - 1)
        else:
            predicted_drift = 0.0

        predicted_center = window_center + cfg["predictor"]["lead"] * predicted_drift

        raw_error = predicted_center - f0
        tracking_error = abs(window_center - f0) / max(1.0, abs(window_center))
        predictive_error = abs(predicted_center - window_center) / max(1.0, abs(window_center))

        # Overshoot proxy: error sign flip or excessive correction demand.
        sign_flip = (previous_error * raw_error) < 0
        correction_pressure = abs(raw_error) / max(1.0, abs(window_center))
        overshoot_risk = sign_flip or correction_pressure > cfg["gain"]["overshoot_pressure"]

        # Adaptive gain scheduling.
        gain_candidate = cfg["gain"]["base"] * (
            1.0
            - cfg["gain"]["k_tracking"] * tracking_error
            - cfg["gain"]["k_predictive"] * predictive_error
        )

        if overshoot_risk:
            gain_candidate *= cfg["gain"]["decay"]
            stable_streak = 0
            gain_cut_count += 1
        else:
            stable_streak += 1
            if stable_streak >= cfg["gain"]["stable_streak_for_boost"]:
                gain_candidate += cfg["gain"]["boost"]
                gain_boost_count += 1

        gain = clamp(gain_candidate, cfg["gain"]["min"], cfg["gain"]["max"])

        delta = gain * raw_error

        # Delta and jerk limits.
        max_delta = abs(window_center) * cfg["gain"]["max_delta_ratio"]
        if abs(delta) > max_delta:
            delta = max_delta * (1 if delta > 0 else -1)
            overshoot_count += 1

        jerk = delta - previous_delta
        max_jerk = abs(window_center) * cfg["gain"]["max_jerk_ratio"]
        if abs(jerk) > max_jerk:
            delta = previous_delta + max_jerk * (1 if jerk > 0 else -1)

        f0 += delta
        f1 = 2.0 * f0
        f2 = 0.5 * f0

        new_tracking_error = abs(window_center - f0) / max(1.0, abs(window_center))

        # Adaptive corridor.
        corridor = cfg["floating"]["base_corridor"] + min(
            cfg["floating"]["max_extra_corridor"],
            abs(predicted_drift) / max(1.0, abs(window_center)) * cfg["floating"]["corridor_gain"]
        )
        in_corridor = new_tracking_error <= corridor

        if not in_corridor:
            lock_loss_count += 1

        # Coherence loop.
        D_t = cfg["dissipation_rate"] * (1.0 + 0.010 * t)
        noise = rng.uniform(-cfg["noise"], cfg["noise"])
        repair = cfg["recovery_gain"] * max(0.0, 1.0 - C)

        gain_health = 1.0 - abs(gain - cfg["gain"]["base"]) / max(1e-9, cfg["gain"]["base"])
        gain_health = clamp(gain_health)

        lock_support = cfg["floating"]["lock_support"] * (1.0 - new_tracking_error) if in_corridor else -cfg["floating"]["lock_penalty"]
        gain_support = cfg["gain"]["gain_support"] * gain_health

        C = clamp(C + repair + lock_support + gain_support - D_t + noise)

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

        series.append({
            "t": t,
            "window_center": window_center,
            "predicted_center": predicted_center,
            "predicted_drift": predicted_drift,
            "f0": f0,
            "f1": f1,
            "f2": f2,
            "gain": gain,
            "raw_error": raw_error,
            "tracking_error": new_tracking_error,
            "predictive_error": predictive_error,
            "correction_pressure": correction_pressure,
            "overshoot_risk": overshoot_risk,
            "in_corridor": in_corridor,
            "corridor": corridor,
            "C": C,
            "D_t": D_t,
            "repair": repair,
            "lock_support": lock_support,
            "gain_support": gain_support,
            "noise": noise
        })

        previous_error = raw_error
        previous_delta = delta

    Cs = [x["C"] for x in series]
    tracking_errors = [x["tracking_error"] for x in series]
    predictive_errors = [x["predictive_error"] for x in series]
    gains = [x["gain"] for x in series]

    mean_C = mean(Cs)
    var_C = mean([(x - mean_C) ** 2 for x in Cs])
    mean_tracking_error = mean(tracking_errors)
    mean_predictive_error = mean(predictive_errors)
    mean_gain = mean(gains)
    gain_var = mean([(x - mean_gain) ** 2 for x in gains])

    overshoot_rate = overshoot_count / cycles
    lock_loss_rate = lock_loss_count / cycles
    gain_cut_rate = gain_cut_count / cycles
    gain_boost_rate = gain_boost_count / cycles

    S_gain = (
        mean_C
        - var_C
        - 0.40 * overshoot_rate
        - 0.35 * lock_loss_rate
        - 0.45 * mean_tracking_error
        - 0.25 * mean_predictive_error
        - 0.15 * gain_var
    )

    if collapsed:
        label = "gain_collapse"
    elif (
        S_gain >= cfg["thresholds"]["gain_stable"]
        and overshoot_rate <= cfg["thresholds"]["max_overshoot"]
        and lock_loss_rate <= cfg["thresholds"]["max_lock_loss"]
    ):
        label = "gain_stable"
    elif S_gain >= cfg["thresholds"]["gain_metastable"]:
        label = "gain_metastable"
    else:
        label = "gain_weak"

    return {
        "mean_C": mean_C,
        "var_C": var_C,
        "mean_tracking_error": mean_tracking_error,
        "mean_predictive_error": mean_predictive_error,
        "mean_gain": mean_gain,
        "gain_var": gain_var,
        "overshoot_rate": overshoot_rate,
        "lock_loss_rate": lock_loss_rate,
        "gain_cut_rate": gain_cut_rate,
        "gain_boost_rate": gain_boost_rate,
        "S_gain": S_gain,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "label": label,
        "series": series
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="results/predictive_drive_trials.json")
    parser.add_argument("--outdir", default="results")
    args = parser.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    trials = json.load(open(args.input, "r", encoding="utf-8"))

    rows = []
    for idx, trial in enumerate(trials):
        base = {
            "trial_index": trial.get("trial_index", idx),
            "previous_label": trial.get("label", "predictive_unknown"),
            "reentry_norm": trial.get("reentry_norm", 0.80),
            "new_edge_penalty": trial.get("new_edge_penalty", 0.10),
            "f_center": [76.4, 150.0, 458.4][idx % 3],
        }
        sim = simulate_trial(base, cfg, cfg["seed"] + idx * 100)
        rows.append({**base, **sim})

    stable = [r for r in rows if r["label"] == "gain_stable"]
    meta = [r for r in rows if r["label"] == "gain_metastable"]
    weak = [r for r in rows if r["label"] == "gain_weak"]
    collapse = [r for r in rows if r["label"] == "gain_collapse"]

    summary = {
        "trials": len(rows),
        "gain_stable": len(stable),
        "gain_metastable": len(meta),
        "gain_weak": len(weak),
        "gain_collapse": len(collapse),
        "mean_S_gain": mean([r["S_gain"] for r in rows]),
        "mean_tracking_error": mean([r["mean_tracking_error"] for r in rows]),
        "mean_predictive_error": mean([r["mean_predictive_error"] for r in rows]),
        "mean_overshoot_rate": mean([r["overshoot_rate"] for r in rows]),
        "mean_lock_loss_rate": mean([r["lock_loss_rate"] for r in rows]),
        "mean_gain": mean([r["mean_gain"] for r in rows]),
        "mean_gain_cut_rate": mean([r["gain_cut_rate"] for r in rows]),
        "mean_gain_boost_rate": mean([r["gain_boost_rate"] for r in rows]),
        "label": "adaptive_gain_success" if len(stable) + len(meta) >= len(rows) * 0.75 and len(collapse) == 0 else "adaptive_gain_limited",
        "top_trials": sorted(rows, key=lambda x: x["S_gain"], reverse=True)[:10],
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out / "adaptive_gain_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out / "adaptive_gain_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "gain_stable": summary["gain_stable"],
        "gain_metastable": summary["gain_metastable"],
        "gain_weak": summary["gain_weak"],
        "gain_collapse": summary["gain_collapse"],
        "mean_S_gain": summary["mean_S_gain"],
        "mean_overshoot_rate": summary["mean_overshoot_rate"],
        "mean_lock_loss_rate": summary["mean_lock_loss_rate"],
        "label": summary["label"]
    }, indent=2))


if __name__ == "__main__":
    main()
