#!/usr/bin/env python3
"""Generate deterministic v20-like predictive trials for v21 full package."""
from pathlib import Path
import json
import random

random.seed(2121)
rows = []
for i in range(18):
    rows.append({
        "trial_index": i,
        "label": "smooth_stable" if i < 12 else "smooth_metastable",
        "reentry_norm": random.uniform(0.74, 1.0),
        "new_edge_penalty": random.uniform(0.03, 0.18),
        "mean_C": random.uniform(0.72, 0.94),
        "S_smooth": random.uniform(0.62, 0.90),
        "mean_tracking_error": random.uniform(0.004, 0.015),
        "mean_predictive_error": random.uniform(0.001, 0.006),
        "overshoot_rate": random.uniform(0.12, 0.24),
        "lock_loss_rate": random.uniform(0.02, 0.10),
        "series": []
    })

Path("results").mkdir(exist_ok=True)
json.dump(rows, open("results/predictive_drive_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("generated predictive trials", len(rows))
