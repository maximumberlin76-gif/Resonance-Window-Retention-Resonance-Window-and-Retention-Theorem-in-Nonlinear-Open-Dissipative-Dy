# v21 Adaptive Gain Protocol

1. Load predictive/smooth trials from v20 layer.
2. Simulate a floating window.
3. Predict local drift.
4. Compute tracking error and predictive error.
5. Estimate overshoot risk:
   - error sign flip
   - excessive correction pressure
6. Adjust gain:
   - cut gain under overshoot risk
   - boost gain after stable streak
7. Apply delta limit.
8. Apply jerk limit.
9. Update f0, f1, f2.
10. Measure:
   - tracking_error
   - predictive_error
   - overshoot_rate
   - lock_loss_rate
   - gain_cut_rate
   - gain_boost_rate
11. Classify gain stability.
