# v21 Equations

## Gain Candidate

gain_candidate =
gain_base * (
  1
  - k_tracking * tracking_error
  - k_predictive * predictive_error
)

## Overshoot Risk

overshoot_risk =
sign_flip(raw_error)
OR
correction_pressure > overshoot_pressure

## Gain Update

if overshoot_risk:
    gain = gain_candidate * decay
else if stable_streak >= N:
    gain = gain_candidate + boost

## Score

S_gain =
mean_C
- var_C
- 0.40 * overshoot_rate
- 0.35 * lock_loss_rate
- 0.45 * mean_tracking_error
- 0.25 * mean_predictive_error
- 0.15 * gain_var
