# Resonance System v21 FULL ADAPTIVE GAIN SCHEDULING

## Purpose

v20 introduced smooth predictive control, but overshoot remained too high.
v21 attacks the root cause: fixed gain.

A fixed `follow_gain` reacts the same way in calm and unstable conditions.
That is wrong for a floating resonance window.

v21 makes gain state-dependent.

## Main Idea

```text
gain = function(
    tracking_error,
    predictive_error,
    correction_pressure,
    overshoot_risk,
    stable_streak
)
```

The controller:

- cuts gain when overshoot risk appears,
- limits correction size,
- limits jerk,
- restores gain only after stable tracking,
- penalizes gain variance in the final score.

## What v21 Adds

1. Adaptive gain scheduling
2. Overshoot-risk detection
3. Gain decay on risk
4. Gain boost after stable streak
5. Delta limit
6. Jerk limit
7. Gain stability score

## Run

```bash
python scripts/generate_predictive_seed.py
python scripts/engine_v21_adaptive_gain.py --input results/predictive_drive_trials.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/adaptive_gain_summary.json
results/adaptive_gain_trials.json
validation/triple_validation_summary.json
```

## Interpretation

- `gain_stable`:
  adaptive gain keeps lock and limits overshoot.

- `gain_metastable`:
  tracking works, but overshoot or lock-loss remains too high.

- `gain_weak`:
  gain schedule is insufficient.

- `gain_collapse`:
  coherence collapses.

## Engineering Meaning

v21 moves the system from “predictive drive” toward a true control loop.
The next natural step is state-aware memory control / PID-like correction.

## Limitation

Computational sandbox only.
