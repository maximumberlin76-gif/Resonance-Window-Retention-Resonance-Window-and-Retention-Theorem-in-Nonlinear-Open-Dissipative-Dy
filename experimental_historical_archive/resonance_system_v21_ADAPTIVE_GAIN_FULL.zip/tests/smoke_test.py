#!/usr/bin/env python3
from pathlib import Path
import json

required = [
    "scripts/engine_v21_adaptive_gain.py",
    "scripts/generate_predictive_seed.py",
    "results/adaptive_gain_summary.json",
    "results/adaptive_gain_trials.json",
    "docs/README.md",
    "model/protocol_v21_adaptive_gain.md",
    "model/equations_v21.md",
]

for item in required:
    p = Path(item)
    assert p.exists(), f"missing: {item}"
    assert p.stat().st_size > 100, f"too small: {item}"

summary = json.load(open("results/adaptive_gain_summary.json", "r", encoding="utf-8"))
for key in ["mean_overshoot_rate", "mean_lock_loss_rate", "mean_S_gain", "all_trials"]:
    assert key in summary, f"missing key: {key}"

print("SMOKE_OK")
