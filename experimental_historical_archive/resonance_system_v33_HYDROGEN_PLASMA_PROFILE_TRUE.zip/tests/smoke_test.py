#!/usr/bin/env python3
from pathlib import Path
import json

required = [
    "scripts/engine_v33_hydrogen_plasma_profile.py",
    "results/hydrogen_plasma_profile_summary.json",
    "results/hydrogen_plasma_profile_trials.json",
    "docs/README.md",
    "model/equations_v33.md",
    "journal/session_journal_v33.md"
]
for item in required:
    p = Path(item)
    assert p.exists(), f"missing {item}"
    assert p.stat().st_size > 100, f"too small {item}"

s = json.load(open("results/hydrogen_plasma_profile_summary.json", "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "hydrogen_reference" in s
print("SMOKE_OK")
