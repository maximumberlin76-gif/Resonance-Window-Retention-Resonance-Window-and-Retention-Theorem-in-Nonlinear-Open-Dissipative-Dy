# v33 Equations

## Useful Coherent Work

W_coh(τ) =
∫ useful_alignment_work(t) dt

## Coherence Balance

Δ(t) = C(t) - P(t) - D(t)

## Extra Molecular Loss

D(t) includes simplified molecular loss channels for hydrogen.

## Spectrum Score

spectrum_score =
frequency_band × pressure_band × duty_band

## Resonance Window Candidate

hydrogen_resonance_window_synthesis_candidate if:

7 <= stable_periods <= 9
and
chaos_rate < threshold
and
drift_rate < threshold
