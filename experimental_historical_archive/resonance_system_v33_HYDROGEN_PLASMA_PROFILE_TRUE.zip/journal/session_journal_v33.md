# Session Journal — v33

## Step

v33 — Hydrogen Plasma Resonance Window Profile.

## Reason

After argon and helium, hydrogen tests the extreme light-gas limit.

## Added

- hydrogen ionization reference
- Balmer diagnostic line anchors
- fast response proxy
- higher drift sensitivity
- simplified molecular loss channel
- useful coherent work W_coh
- resonance-window candidate classification

## Core Principle

Hydrogen should respond fastest, but it should also be the hardest to retain without tight period control.
