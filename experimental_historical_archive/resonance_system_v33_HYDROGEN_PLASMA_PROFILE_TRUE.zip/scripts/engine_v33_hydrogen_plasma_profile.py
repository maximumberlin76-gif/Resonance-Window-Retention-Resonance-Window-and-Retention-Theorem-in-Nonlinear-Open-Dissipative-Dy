#!/usr/bin/env python3
"""
v33 TRUE HYDROGEN PLASMA RESONANCE WINDOW PROFILE

Purpose:
Map the resonance-window framework onto a simplified hydrogen plasma profile.

System class:
nonlinear dissipative open dynamic systems

Important:
This is a computational resonance-window sandbox, not a laboratory measurement.

Hydrogen expectation:
- lightest gas
- fastest response
- highest drift/noise sensitivity
- weak retention unless period control is tight
- additional molecular channels are simplified here and will be expanded later if H2 chemistry is modeled explicitly

Core premise:
Phase transition occurs over a finite period when useful coherent work accumulates over time:

W_coh(τ) = ∫ useful_alignment_work(t) dt

and reaches the holding threshold of the old configuration.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def gaussian(x, mu, sigma):
    return math.exp(-0.5 * ((x - mu) / max(1e-12, sigma)) ** 2)

def spectrum_score(freq_mhz, duty, pressure_mTorr, cfg):
    h = cfg["hydrogen"]
    anchor = h["acoustic_anchor_mhz"]

    anchor_component = gaussian(freq_mhz, anchor, 3.5)
    harmonic_component = 0.70 * gaussian(freq_mhz, anchor * 2.0, 6.0)
    rf_component = 0.50 * gaussian(freq_mhz, h["rf_reference_mhz"], 3.5)
    high_component = 0.35 * gaussian(freq_mhz, h["high_branch_mhz"], 7.0)

    pressure_component = gaussian(pressure_mTorr, h["pressure_center_mTorr"], h["pressure_sigma_mTorr"])
    duty_component = gaussian(duty, h["duty_center"], h["duty_sigma"])

    return clamp((anchor_component + harmonic_component + rf_component + high_component) * pressure_component * duty_component)

def simulate(seed, drive, cfg):
    rng = random.Random(seed)
    steps = cfg["simulation"]["steps"]
    period_steps = cfg["simulation"]["period_steps"]
    h = cfg["hydrogen"]

    Te = rng.uniform(4.0, 9.0)
    ne = rng.uniform(2e8, 2e10)
    ion_frac = rng.uniform(1e-7, 5e-5)
    C = rng.uniform(0.25, 0.46)

    W_coh = 0.0
    theta = 0.0
    stable_periods = 0
    period_work = 0.0
    period_theta = 0.0

    chaos_events = 0
    drift_events = 0
    molecular_loss_accum = 0.0

    sample = []
    spec = spectrum_score(drive["freq_mhz"], drive["duty"], drive["pressure_mTorr"], cfg)

    for t in range(steps):
        phase = 2 * math.pi * (t % period_steps) / period_steps
        pulse = 1.0 if (t % period_steps) < int(period_steps * drive["duty"]) else 0.0
        modulation = 1.0 + 0.28 * math.sin(phase)

        heating = drive["power_norm"] * spec * pulse * modulation
        collision_rate = drive["pressure_mTorr"] / 280.0

        # Hydrogen is highly mobile: stronger drift proxy.
        drift_pressure = 0.085 * abs(math.sin(2 * math.pi * t / max(1, steps)))

        # Simplified H2 molecular channel: extra loss if Te too high or pressure too high.
        molecular_loss = (
            h["molecular_loss_base"]
            + 0.04 * max(0.0, Te - h["Te_molecular_soft_eV"])
            + 0.025 * max(0.0, collision_rate - 1.0)
        )
        molecular_loss_accum += molecular_loss

        dissipation = (
            h["base_dissipation"]
            + 0.085 * collision_rate
            + 0.040 * abs(Te - h["Te_target_eV"])
            + molecular_loss
        )

        destructive = (
            h["base_pressure"]
            + 0.080 * max(0.0, Te - h["Te_upper_soft_eV"])
            + drift_pressure
        )

        useful_alignment = spec * pulse * gaussian(Te, h["Te_target_eV"], h["Te_sigma_eV"])
        useful_work_step = useful_alignment * drive["power_norm"] * cfg["simulation"]["work_gain"]

        # Fast thermal response.
        Te += (
            0.070 * heating
            - 0.038 * (Te - h["Te_relax_eV"])
            - 0.012 * collision_rate
            - 0.010 * molecular_loss
            + rng.uniform(-0.030, 0.030)
        )
        Te = max(0.1, min(35.0, Te))

        ion_drive = gaussian(Te, h["Te_ionization_eff_eV"], h["Te_ionization_sigma_eV"]) * heating
        ion_frac = clamp(
            ion_frac
            + 9e-4 * ion_drive
            - 4e-4 * collision_rate * ion_frac
            - 2e-4 * molecular_loss * ion_frac,
            0.0,
            0.08
        )

        ne = max(
            1e6,
            ne * (1.0 + 0.014 * ion_drive - 0.004 * collision_rate - 0.003 * molecular_loss + rng.uniform(-0.006, 0.006))
        )

        P = destructive
        D = dissipation
        C_prev = C

        C = clamp(
            C
            + 0.034 * useful_alignment * (1.0 - C)
            - 0.014 * P
            - 0.012 * D
            + rng.uniform(-cfg["simulation"]["noise"], cfg["simulation"]["noise"])
        )

        if abs(C - C_prev) > cfg["simulation"]["safe_dC_limit"]:
            chaos_events += 1
        if drift_pressure > 0.075:
            drift_events += 1

        delta = C - P - D

        if delta > 0:
            theta += delta
            period_theta += delta
            W_coh += useful_work_step
            period_work += useful_work_step

        if (t + 1) % period_steps == 0:
            if (
                period_theta >= cfg["thresholds"]["period_theta_min"]
                and period_work >= cfg["thresholds"]["period_work_min"]
            ):
                stable_periods += 1
            period_theta = 0.0
            period_work = 0.0

        if t % cfg["simulation"]["sample_every"] == 0 or t == steps - 1:
            sample.append({
                "step": t,
                "Te_eV": Te,
                "ne_cm3": ne,
                "ionization_fraction_proxy": ion_frac,
                "C": C,
                "P": P,
                "D": D,
                "delta": delta,
                "W_coh": W_coh,
                "theta": theta,
                "molecular_loss": molecular_loss
            })

    chaos_rate = chaos_events / steps
    drift_rate = drift_events / steps
    mean_molecular_loss = molecular_loss_accum / steps

    if chaos_rate >= cfg["thresholds"]["chaos_rate_limit"]:
        outcome = "hydrogen_chaotic_overdrive"
    elif drift_rate >= cfg["thresholds"]["drift_rate_limit"]:
        outcome = "hydrogen_drift_unstable"
    elif stable_periods >= cfg["thresholds"]["closed_structure_periods"]:
        outcome = "hydrogen_closed_structure_candidate"
    elif cfg["thresholds"]["synthesis_min_periods"] <= stable_periods <= cfg["thresholds"]["synthesis_max_periods"]:
        outcome = "hydrogen_resonance_window_synthesis_candidate"
    elif stable_periods > 0:
        outcome = "hydrogen_accumulation_in_progress"
    else:
        outcome = "hydrogen_no_stable_window"

    return {
        "seed": seed,
        "drive": drive,
        "spectrum_score": spec,
        "W_coh": W_coh,
        "theta": theta,
        "stable_periods": stable_periods,
        "chaos_rate": chaos_rate,
        "drift_rate": drift_rate,
        "mean_molecular_loss": mean_molecular_loss,
        "mean_C": mean([x["C"] for x in sample]),
        "mean_Te_eV": mean([x["Te_eV"] for x in sample]),
        "mean_ne_cm3": mean([x["ne_cm3"] for x in sample]),
        "mean_ionization_fraction_proxy": mean([x["ionization_fraction_proxy"] for x in sample]),
        "outcome": outcome,
        "series_sampled": sample
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))

    drives = []
    for freq in cfg["scan"]["freq_mhz"]:
        for power in cfg["scan"]["power_norm"]:
            for pressure in cfg["scan"]["pressure_mTorr"]:
                for duty in cfg["scan"]["duty"]:
                    drives.append({"freq_mhz": freq, "power_norm": power, "pressure_mTorr": pressure, "duty": duty})

    rows = [simulate(cfg["seed"] + i * 100, drive, cfg) for i, drive in enumerate(drives)]

    outcomes = {}
    for r in rows:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1

    best = sorted(
        rows,
        key=lambda r: (
            r["outcome"] == "hydrogen_resonance_window_synthesis_candidate",
            r["stable_periods"],
            r["W_coh"],
            r["spectrum_score"],
            -r["chaos_rate"],
            -r["drift_rate"]
        ),
        reverse=True
    )[:12]

    freq_hits = {}
    for r in best:
        f = str(r["drive"]["freq_mhz"])
        freq_hits[f] = freq_hits.get(f, 0) + 1

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "hydrogen_reference": {
            "ionization_energy_eV": cfg["hydrogen"]["ionization_energy_eV"],
            "rf_reference_mhz": cfg["hydrogen"]["rf_reference_mhz"],
            "diagnostic_lines_nm": cfg["hydrogen"]["diagnostic_lines_nm"],
            "note": "Computational profile, not laboratory measurement."
        },
        "trials": len(rows),
        "outcomes": outcomes,
        "best_candidates": best,
        "recommended_frequency_hits_mhz": freq_hits,
        "main_conclusion": "hydrogen_is_extreme_speed_drift_test_and_requires_tight_period_retention",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"hydrogen_plasma_profile_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"hydrogen_plasma_profile_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": len(rows),
        "outcomes": outcomes,
        "recommended_frequency_hits_mhz": freq_hits,
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
