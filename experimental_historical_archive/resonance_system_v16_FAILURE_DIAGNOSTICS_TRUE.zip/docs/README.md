# Resonance System v16 TRUE FAILURE DIAGNOSTICS

## Purpose

v15 showed that some recovered modes remain stable over time,
some become metastable, and some collapse.

v16 explains why.

It diagnoses failure mechanisms from temporal stability traces.

## Diagnosed Failure Causes

- excessive_recovery_edges
- weak_reentry
- dissipation_dominance
- negative_coherence_drift
- noise_sensitive
- late_cycle_degradation
- no_single_failure_cause

## Method

For every temporal trial, v16 computes:

- early_C
- late_C
- C_slope
- D_mean
- repair_mean
- noise_abs_mean
- C_variance
- risk_score

Then it groups causes by temporal label:

- temporal_stable
- temporal_metastable
- temporal_collapse

## Run

```bash
python scripts/generate_temporal_seed.py
python scripts/engine_v16_failure_diagnostics.py --input results/temporal_stability_summary.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/failure_diagnostics_all.json
results/failure_diagnostics_summary.json
validation/triple_validation_summary.json
```

## Interpretation

v16 is the diagnostic layer:
it does not merely say “stable/collapsed”.
It tells which mechanism caused collapse or instability.

## Limitation

Computational sandbox only.
