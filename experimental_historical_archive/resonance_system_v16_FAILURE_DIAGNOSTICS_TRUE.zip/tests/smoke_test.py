#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v16_failure_diagnostics.py","results/failure_diagnostics_summary.json","results/failure_diagnostics_all.json","docs/README.md"]:
    fp=Path(p); assert fp.exists() and fp.stat().st_size>100, p
s=json.load(open("results/failure_diagnostics_summary.json","r",encoding="utf-8"))
assert "cause_counts" in s and "label_summary" in s
print("SMOKE_OK")
