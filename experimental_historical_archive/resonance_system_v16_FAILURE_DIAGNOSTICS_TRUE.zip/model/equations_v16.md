# v16 Metrics

C_slope = linear trend of C(t)

S_time = mean(C) - var(C)

risk_score =
0.25*new_edge_penalty
+ 0.25*max(0, 0.75 - reentry_norm)
+ 10*max(0, D_mean - repair_mean)
+ 30*max(0, -C_slope)
+ 0.25*C_var
