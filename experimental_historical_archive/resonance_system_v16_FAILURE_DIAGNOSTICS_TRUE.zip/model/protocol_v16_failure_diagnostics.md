# v16 Failure Diagnostics Protocol

1. Load temporal stability traces from v15.
2. Extract C(t), D(t), repair(t), noise(t).
3. Compute early/late coherence.
4. Compute coherence slope.
5. Compare dissipation and repair.
6. Detect noise sensitivity.
7. Detect excessive recovery-edge penalty.
8. Assign cause labels.
9. Rank trials by risk_score.
