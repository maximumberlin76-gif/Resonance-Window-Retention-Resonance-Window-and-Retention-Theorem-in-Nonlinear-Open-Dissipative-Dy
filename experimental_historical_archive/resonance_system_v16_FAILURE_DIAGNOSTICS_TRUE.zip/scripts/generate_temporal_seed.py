#!/usr/bin/env python3
"""Generate deterministic v15-like temporal summary for v16 self-contained diagnostics."""
from pathlib import Path
import json, random
random.seed(1616)

labels = ["temporal_stable"]*5 + ["temporal_metastable"]*5 + ["temporal_collapse"]*8
trials = []
for idx, label in enumerate(labels):
    collapsed = label == "temporal_collapse"
    reentry_norm = random.uniform(0.72, 1.0) if label != "temporal_collapse" else random.uniform(0.35, 0.72)
    penalty = random.uniform(0.02, 0.18) if label == "temporal_stable" else random.uniform(0.12, 0.35)
    C = max(0.05, reentry_norm - penalty)
    series = []
    collapse_at = None
    for t in range(120):
        D_t = 0.004 * (1 + 0.015*t)
        repair = 0.018 * max(0.0, 1.0 - C)
        noise = random.uniform(-0.025, 0.025)
        if collapsed:
            C = max(0, C + repair - D_t*1.65 + noise*1.15)
        elif label == "temporal_metastable":
            C = max(0, min(1, C + repair - D_t*1.15 + noise))
        else:
            C = max(0, min(1, C + repair - D_t*0.75 + noise*0.65))
        if C < 0.35 and collapse_at is None:
            collapse_at = t
        series.append({"t":t,"C":C,"D_t":D_t,"repair":repair,"noise":noise})
    mean_C = sum(x["C"] for x in series)/len(series)
    var_C = sum((x["C"]-mean_C)**2 for x in series)/len(series)
    trials.append({
        "trial_index": idx,
        "trial_label": "recovered",
        "damage_mode": "hub" if idx%2==0 else "random",
        "damage_fraction": [0.15,0.25,0.35][idx%3],
        "boost": [0.025,0.05,0.075][idx%3],
        "label": label,
        "raw_reentry": reentry_norm,
        "reentry_norm": reentry_norm,
        "new_edge_penalty": penalty,
        "mean_C": mean_C,
        "var_C": var_C,
        "S_time": mean_C-var_C,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "series": series
    })
summary = {
    "trials": len(trials),
    "temporal_stable": 5,
    "temporal_metastable": 5,
    "temporal_weak": 0,
    "temporal_collapse": 8,
    "mean_S_time": sum(t["S_time"] for t in trials)/len(trials),
    "mean_C": sum(t["mean_C"] for t in trials)/len(trials),
    "label": "limited_temporal_stability",
    "all_trials": trials
}
Path("results").mkdir(exist_ok=True)
json.dump(summary, open("results/temporal_stability_summary.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
print("generated temporal summary", len(trials))
