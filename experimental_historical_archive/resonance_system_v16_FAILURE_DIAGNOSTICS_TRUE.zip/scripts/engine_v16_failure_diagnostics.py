#!/usr/bin/env python3
"""
Resonance System v16 TRUE FAILURE DIAGNOSTICS

v15 separated stable/metastable/collapse over time.
v16 explains WHY:
- dissipation dominance
- insufficient repair gain
- excessive new-edge penalty
- low initial coherence
- noise sensitivity
- late-cycle drift

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json
from pathlib import Path
from statistics import mean, pstdev

def slope(values):
    if len(values) < 2:
        return 0.0
    n = len(values)
    x_mean = (n - 1) / 2
    y_mean = mean(values)
    num = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
    den = sum((i - x_mean) ** 2 for i in range(n))
    return num / den if den else 0.0

def diagnose_trial(trial):
    series = trial["series"]
    C = [x["C"] for x in series]
    D = [x["D_t"] for x in series]
    repair = [x["repair"] for x in series]
    noise = [x["noise"] for x in series]

    early_C = mean(C[:max(1, len(C)//5)])
    late_C = mean(C[-max(1, len(C)//5):])
    C_slope = slope(C)
    D_mean = mean(D)
    repair_mean = mean(repair)
    noise_abs_mean = mean(abs(x) for x in noise)
    C_var = pstdev(C) if len(C) > 1 else 0.0

    causes = []

    if trial["new_edge_penalty"] >= 0.20:
        causes.append("excessive_recovery_edges")
    if trial["reentry_norm"] < 0.65:
        causes.append("weak_reentry")
    if D_mean > repair_mean * 1.25:
        causes.append("dissipation_dominance")
    if C_slope < -0.002:
        causes.append("negative_coherence_drift")
    if noise_abs_mean > 0.018 and C_var > 0.08:
        causes.append("noise_sensitive")
    if late_C < early_C * 0.75:
        causes.append("late_cycle_degradation")
    if not causes:
        causes.append("no_single_failure_cause")

    risk_score = (
        trial["new_edge_penalty"] * 0.25
        + max(0.0, 0.75 - trial["reentry_norm"]) * 0.25
        + max(0.0, D_mean - repair_mean) * 10.0
        + max(0.0, -C_slope) * 30.0
        + C_var * 0.25
    )

    return {
        "trial_index": trial["trial_index"],
        "original_label": trial["label"],
        "damage_mode": trial["damage_mode"],
        "damage_fraction": trial["damage_fraction"],
        "boost": trial["boost"],
        "mean_C": trial["mean_C"],
        "S_time": trial["S_time"],
        "collapsed": trial["collapsed"],
        "collapse_at": trial["collapse_at"],
        "reentry_norm": trial["reentry_norm"],
        "new_edge_penalty": trial["new_edge_penalty"],
        "early_C": early_C,
        "late_C": late_C,
        "C_slope": C_slope,
        "D_mean": D_mean,
        "repair_mean": repair_mean,
        "noise_abs_mean": noise_abs_mean,
        "C_var": C_var,
        "causes": causes,
        "risk_score": risk_score
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="results/temporal_stability_summary.json")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    src = json.load(open(args.input, "r", encoding="utf-8"))
    trials = src["all_trials"]

    diagnostics = [diagnose_trial(t) for t in trials]
    diagnostics.sort(key=lambda x: x["risk_score"], reverse=True)

    cause_counts = {}
    for d in diagnostics:
        for c in d["causes"]:
            cause_counts[c] = cause_counts.get(c, 0) + 1

    by_label = {}
    for d in diagnostics:
        by_label.setdefault(d["original_label"], []).append(d)

    label_summary = {}
    for label, rows in by_label.items():
        label_summary[label] = {
            "count": len(rows),
            "mean_risk": sum(r["risk_score"] for r in rows)/len(rows),
            "mean_C": sum(r["mean_C"] for r in rows)/len(rows),
            "mean_S_time": sum(r["S_time"] for r in rows)/len(rows),
            "top_causes": sorted(
                {c: sum(1 for r in rows if c in r["causes"]) for r in set(c for r in rows for c in r["causes"])}.items(),
                key=lambda x: x[1],
                reverse=True
            )
        }

    summary = {
        "trials": len(diagnostics),
        "cause_counts": dict(sorted(cause_counts.items(), key=lambda x: x[1], reverse=True)),
        "label_summary": label_summary,
        "highest_risk": diagnostics[:5],
        "lowest_risk": sorted(diagnostics, key=lambda x: x["risk_score"])[:5],
        "main_conclusion": "failure_modes_identified"
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(diagnostics, open(out/"failure_diagnostics_all.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(summary, open(out/"failure_diagnostics_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "cause_counts": summary["cause_counts"],
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
