
import json,random,math,argparse
from pathlib import Path
def clamp(x): return max(0,min(1,x))
def mean(a): return sum(a)/len(a)

def sim(trial,cfg,seed):
    rng=random.Random(seed)
    fc=trial["f_center"]; f0=fc; g=cfg["g_base"]
    C=clamp(trial["reentry_norm"]-trial["new_edge_penalty"])
    overs=0; lock_loss=0; series=[]
    for t in range(cfg["cycles"]):
        fc+=cfg["drift"]*math.sin(t/10)+rng.uniform(-0.05,0.05)
        err=fc-f0
        tracking=abs(err)/max(1,abs(fc))
        pred_err=tracking*0.6

        # adaptive gain
        g_eff=g*(1-cfg["k1"]*tracking-cfg["k2"]*pred_err)
        if tracking>cfg["overshoot_trigger"]:
            g_eff*=cfg["decay"]; overs+=1
        else:
            g_eff=min(cfg["g_max"], g_eff+cfg["boost"])

        f0+=g_eff*err
        if tracking>cfg["corridor"]: lock_loss+=1

        C=clamp(C+0.02*(1-C)-0.004*t/cfg["cycles"]+rng.uniform(-0.02,0.02))
        series.append({"tracking":tracking,"C":C})

    mt=mean([x["tracking"] for x in series])
    ll=lock_loss/cfg["cycles"]
    orate=overs/cfg["cycles"]
    S=mean([x["C"] for x in series])-0.4*mt-0.4*orate-0.3*ll
    label="stable" if S>0.6 and orate<0.1 else "ok" if S>0.45 else "weak"
    return {"S":S,"tracking":mt,"overshoot":orate,"lock_loss":ll,"label":label}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--outdir",default="results")
    args=ap.parse_args()
    cfg=json.load(open("configs/config.json"))
    trials=[{"f_center":f,"reentry_norm":random.uniform(0.75,1),"new_edge_penalty":random.uniform(0.05,0.15)} for f in [76.4,150,458.4]*6]
    out=[]
    for i,t in enumerate(trials):
        out.append(sim(t,cfg,100+i))
    summary={
        "trials":len(out),
        "stable":sum(1 for x in out if x["label"]=="stable"),
        "mean_tracking":sum(x["tracking"] for x in out)/len(out),
        "mean_overshoot":sum(x["overshoot"] for x in out)/len(out),
        "mean_lock_loss":sum(x["lock_loss"] for x in out)/len(out)
    }
    Path(args.outdir).mkdir(exist_ok=True)
    json.dump(summary,open("results/summary.json","w"),indent=2)
    json.dump(out,open("results/trials.json","w"),indent=2)
    print(summary)

if __name__=="__main__": main()
