
import json,os
assert os.path.exists("results/summary.json")
s=json.load(open("results/summary.json"))
assert "mean_overshoot" in s
print("OK")
