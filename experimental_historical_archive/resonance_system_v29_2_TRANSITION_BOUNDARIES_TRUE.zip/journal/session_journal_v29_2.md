# Session Journal — v29.2

## Step

v29.2 — Transition Boundaries.

## Reason

v29.1 showed only accumulation_in_progress.
That meant parameters were too narrow.

## Added

- three operating bands:
  - slow_accumulation
  - synthesis_band
  - overdrive
- global outcome distribution
- scale/band boundary summary

## Core Principle

To see synthesis, the model must allow enough time and enough coherent accumulation.
To see chaos, it must allow excessive speed, overshoot, or violent drive.

## Next Step

v29.3 — tune the synthesis_band so the model produces a controlled number of 7–9 period synthesis candidates without collapsing into closed_structure_candidate too quickly.
