#!/usr/bin/env python3
from pathlib import Path
import json
required = [
    "scripts/engine_v29_2_transition_boundaries.py",
    "results/transition_boundaries_summary.json",
    "results/transition_boundaries_trials.json",
    "docs/README.md",
    "model/equations_v29_2.md",
    "journal/session_journal_v29_2.md"
]
for item in required:
    p = Path(item)
    assert p.exists(), f"missing: {item}"
    assert p.stat().st_size > 100, f"too small: {item}"
s = json.load(open("results/transition_boundaries_summary.json", "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "global_outcomes" in s
print("SMOKE_OK")
