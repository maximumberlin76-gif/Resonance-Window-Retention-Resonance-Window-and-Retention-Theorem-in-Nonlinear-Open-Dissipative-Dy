#!/usr/bin/env python3
"""
v29.2 TRUE TRANSITION BOUNDARIES

Goal:
After v29.1 all regimes remained accumulation_in_progress.
v29.2 widens the parameter field to expose three zones:

1. accumulation_in_progress
2. synthesis_window_candidate
3. chaos_or_overshoot

System class:
nonlinear dissipative open dynamic systems

Core:
synthesis is not a spike.
synthesis requires accumulated coherence over several stable periods.
"""

from __future__ import annotations
import json, random, math, argparse
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def simulate(seed, scale_name, band_name, band_cfg, scale_cfg, cfg):
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    C = rng.uniform(*band_cfg["C0"])
    P = scale_cfg["P"] * band_cfg["P_mult"]
    D = scale_cfg["D"] * band_cfg["D_mult"]
    growth_rate = scale_cfg["growth_rate"] * band_cfg["growth_mult"]
    cycle_time = scale_cfg["cycle_time"]
    period_len = scale_cfg["period_steps"]

    theta = 0.0
    current_tau_steps = 0
    max_tau_steps = 0
    stable_periods = 0
    period_accum = 0.0
    period_thetas = []
    chaos_events = 0
    overshoot_events = 0
    series = []

    for t in range(cycles):
        phase = 2 * math.pi * (t % period_len) / period_len
        modulation = 1.0 + scale_cfg["modulation"] * math.sin(phase)
        noise = rng.uniform(-scale_cfg["noise"] * band_cfg["noise_mult"], scale_cfg["noise"] * band_cfg["noise_mult"])

        dC = (
            growth_rate * modulation * (1.0 - C)
            - D * scale_cfg["dissipation_weight"]
            - P * scale_cfg["load_weight"]
            + noise
        )

        if rng.random() < scale_cfg["spike_prob"] * band_cfg["spike_mult"]:
            spike = rng.uniform(scale_cfg["spike_min"], scale_cfg["spike_max"]) * band_cfg["spike_strength"]
            dC += spike
            overshoot_events += 1

        if abs(dC) > cfg["safe_dC_limit"]:
            chaos_events += 1

        C = clamp(C + dC)
        delta = C - P - D

        if delta > 0:
            theta += delta
            period_accum += delta
            current_tau_steps += 1
        else:
            max_tau_steps = max(max_tau_steps, current_tau_steps)
            current_tau_steps = 0

        if (t + 1) % period_len == 0:
            period_thetas.append(period_accum)
            if period_accum >= cfg["period_theta_min"]:
                stable_periods += 1
            period_accum = 0.0

        max_tau_steps = max(max_tau_steps, current_tau_steps)

        series.append({
            "t_step": t,
            "t_physical": t * cycle_time,
            "scale": scale_name,
            "band": band_name,
            "C": C,
            "P": P,
            "D": D,
            "delta": delta,
            "theta": theta,
            "tau_steps": current_tau_steps,
            "tau_physical": current_tau_steps * cycle_time,
            "dC": dC
        })

    tau_physical = max_tau_steps * cycle_time
    chaos_rate = chaos_events / cycles
    overshoot_rate = overshoot_events / cycles
    dwell_period_count = max_tau_steps / max(1, period_len)

    if chaos_rate >= cfg["chaos_rate_limit"] or overshoot_rate >= cfg["overshoot_rate_limit"]:
        outcome = "chaos_or_overshoot"
    elif stable_periods >= 10:
        outcome = "closed_structure_candidate"
    elif 7 <= stable_periods <= 9:
        outcome = "synthesis_window_candidate"
    elif stable_periods >= 1:
        outcome = "accumulation_in_progress"
    else:
        outcome = "no_stable_accumulation"

    return {
        "seed": seed,
        "scale": scale_name,
        "band": band_name,
        "cycle_time": cycle_time,
        "period_steps": period_len,
        "theta": theta,
        "max_tau_steps": max_tau_steps,
        "tau_physical": tau_physical,
        "stable_periods": stable_periods,
        "dwell_period_count": dwell_period_count,
        "period_thetas": period_thetas,
        "chaos_rate": chaos_rate,
        "overshoot_rate": overshoot_rate,
        "outcome": outcome,
        "mean_C": mean([x["C"] for x in series]),
        "mean_delta": mean([x["delta"] for x in series]),
        "series": series
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    rows = []

    for scale_name, scale_cfg in cfg["scales"].items():
        for band_name, band_cfg in cfg["bands"].items():
            for i in range(cfg["trials_per_band"]):
                seed = cfg["seed"] + scale_cfg["seed_offset"] + band_cfg["seed_offset"] + i * 100
                rows.append(simulate(seed, scale_name, band_name, band_cfg, scale_cfg, cfg))

    by_key = {}
    for r in rows:
        by_key.setdefault((r["scale"], r["band"]), []).append(r)

    boundary_summary = {}
    for (scale, band), items in by_key.items():
        outcomes = {}
        for x in items:
            outcomes[x["outcome"]] = outcomes.get(x["outcome"], 0) + 1
        boundary_summary[f"{scale}/{band}"] = {
            "count": len(items),
            "mean_theta": mean([x["theta"] for x in items]),
            "mean_tau_steps": mean([x["max_tau_steps"] for x in items]),
            "mean_tau_physical": mean([x["tau_physical"] for x in items]),
            "mean_stable_periods": mean([x["stable_periods"] for x in items]),
            "mean_chaos_rate": mean([x["chaos_rate"] for x in items]),
            "mean_overshoot_rate": mean([x["overshoot_rate"] for x in items]),
            "outcomes": outcomes
        }

    global_outcomes = {}
    for r in rows:
        global_outcomes[r["outcome"]] = global_outcomes.get(r["outcome"], 0) + 1

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "trials": len(rows),
        "main_conclusion": "transition_boundaries_require_scale_and_drive_band_separation",
        "global_outcomes": global_outcomes,
        "boundary_summary": boundary_summary,
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"transition_boundaries_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"transition_boundaries_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "global_outcomes": global_outcomes,
        "main_conclusion": summary["main_conclusion"],
        "boundary_summary": boundary_summary
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
