# v29.2 — Transition Boundaries

## Abstract

This module extends scale-aware calibration in nonlinear dissipative open dynamic systems by separating three operating bands:

1. slow_accumulation
2. synthesis_band
3. overdrive

The goal is to expose transition boundaries rather than average all regimes into a single accumulation state.

## Core Idea

A system does not move from accumulation to synthesis by a single threshold crossing.

It passes through a time-dependent region where coherence accumulation, dwell duration, dissipation, and drive strength jointly determine the outcome.

## Outcomes

```text
accumulation_in_progress
synthesis_window_candidate
closed_structure_candidate
chaos_or_overshoot
```

## Key Distinction

Slow accumulation:

```text
not enough periods yet
```

Synthesis band:

```text
7–9 stable accumulation periods
```

Closed structure:

```text
10+ stable periods
```

Overdrive:

```text
too fast / too violent / unstable
```

## System Class

All results apply strictly to:

```text
nonlinear dissipative open dynamic systems
```

## Why This Matters

The same control logic cannot be used for all regimes.

Accumulation, synthesis, and chaos are not moral labels.
They are dynamic regions separated by dwell time, coherence integral, dissipation, and overshoot.

## Run

```bash
python scripts/engine_v29_2_transition_boundaries.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/transition_boundaries_summary.json
results/transition_boundaries_trials.json
journal/session_journal_v29_2.md
```

## Limitation

This is a computational calibration sandbox.
