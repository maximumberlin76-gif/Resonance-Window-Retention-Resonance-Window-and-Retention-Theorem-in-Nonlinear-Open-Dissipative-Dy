# v29.2 Equations

## Physical Time

tau_physical = tau_steps · cycle_time(scale)

## Accumulation Integral

Theta(t0, tau) =
∫[C(t) - P(t) - D(t)] dt

## Band Logic

slow_accumulation:
    low growth, stronger load/dissipation

synthesis_band:
    moderate growth, reduced destructive pressure

overdrive:
    excessive growth/noise/spike strength

## Outcome Rule

7 <= stable_periods <= 9:
    synthesis_window_candidate

stable_periods >= 10:
    closed_structure_candidate

chaos_rate or overshoot_rate too high:
    chaos_or_overshoot
