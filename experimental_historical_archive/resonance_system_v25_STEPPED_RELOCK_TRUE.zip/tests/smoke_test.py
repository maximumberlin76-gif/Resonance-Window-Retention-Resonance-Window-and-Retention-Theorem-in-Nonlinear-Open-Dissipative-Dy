#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v25_stepped_relock.py","results/stepped_relock_summary.json","results/stepped_relock_trials.json","docs/README.md"]:
    fp=Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s=json.load(open("results/stepped_relock_summary.json","r",encoding="utf-8"))
assert "mean_relock_success_rate" in s and "all_trials" in s
print("SMOKE_OK")
