# Resonance System v25 TRUE STEPPED RE-LOCK

## Purpose

v24 survived adversarial stress but still had false prediction damage.
v25 replaces passive fallback with stepped recovery.

This is the transition:

```text
fallback = emergency brake
re-lock = active self-healing recovery
```

## Stepped Recovery Sequence

1. FREEZE  
   Temporarily stop trusting prediction.

2. ANCHOR  
   Move toward observed anchor at low gain.

3. LOW-GAIN SPIRAL  
   Search phase gently using small dither.

4. LOCK CONFIRMATION  
   Require several stable steps before accepting lock.

5. CONTROLLED RETURN  
   Return to model mode without abrupt transition.

## Entry Conditions

Re-lock starts when:

- tracking error rises sharply
- confidence drops
- false prediction damage appears
- fallback streak becomes too long

## Metrics

- relock_success_rate
- mean_relock_time
- false_prediction_damage
- damage_per_cycle
- shock_recovery_rate
- S_relock

## Run

```bash
python scripts/generate_adversarial_seed.py
python scripts/engine_v25_stepped_relock.py --input results/adversarial_stress_trials.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/stepped_relock_summary.json
results/stepped_relock_trials.json
validation/triple_validation_summary.json
journal/session_journal_v25.md
```

## Limitation

Computational sandbox only.
