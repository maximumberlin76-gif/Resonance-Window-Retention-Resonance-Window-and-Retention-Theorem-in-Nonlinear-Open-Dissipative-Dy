#!/usr/bin/env python3
from pathlib import Path
import json, random
random.seed(2525)
rows=[]
for i in range(18):
    rows.append({
        "trial_index": i,
        "label": "adversarial_stable",
        "reentry_norm": random.uniform(0.78,1.0),
        "new_edge_penalty": random.uniform(0.03,0.15),
        "mean_C": random.uniform(0.72,0.96),
        "S_adversarial": random.uniform(0.62,1.05),
        "false_prediction_damage": random.uniform(0.02,0.20),
        "fallback_rate": random.uniform(0.02,0.10),
        "series": []
    })
Path("results").mkdir(exist_ok=True)
json.dump(rows, open("results/adversarial_stress_trials.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
print("generated adversarial trials", len(rows))
