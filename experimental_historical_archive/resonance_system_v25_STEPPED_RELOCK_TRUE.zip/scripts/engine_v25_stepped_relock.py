#!/usr/bin/env python3
"""
Resonance System v25 TRUE STEPPED RE-LOCK / SELF-HEALING CONTROL

v24 showed adversarial resilience but nonzero false_prediction_damage.
v25 replaces passive fallback with stepped re-lock:

1. FREEZE prediction
2. ANCHOR approach
3. LOW-GAIN SPIRAL / dither search
4. LOCK CONFIRMATION
5. CONTROLLED RETURN to model mode

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from typing import Dict, Any, List

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def heavy_noise(rng, base, p, scale):
    return rng.uniform(-base*scale, base*scale) if rng.random() < p else rng.uniform(-base, base)

def detect_relock(tracking, confidence, false_damage_step, fallback_streak, cfg):
    return (
        tracking > cfg["relock"]["tracking_enter"]
        or confidence < cfg["relock"]["confidence_enter"]
        or false_damage_step > cfg["relock"]["false_damage_enter"]
        or fallback_streak >= cfg["relock"]["fallback_streak_enter"]
    )

def relock_step(state, true_center, cfg, rng):
    phase = state["relock_phase"]
    f0 = state["f0"]
    anchor = state["anchor"]

    if phase == "freeze":
        control = 0.0
        state["phase_ticks"] += 1
        if state["phase_ticks"] >= cfg["relock"]["freeze_steps"]:
            state["relock_phase"] = "anchor"
            state["phase_ticks"] = 0

    elif phase == "anchor":
        control = cfg["relock"]["anchor_gain"] * (anchor - f0)
        state["phase_ticks"] += 1
        if abs(anchor - f0) / max(1.0, abs(anchor)) < cfg["relock"]["anchor_tolerance"]:
            state["relock_phase"] = "spiral"
            state["phase_ticks"] = 0

    elif phase == "spiral":
        dither = cfg["relock"]["dither_amp"] * math.sin(state["phase_ticks"] * cfg["relock"]["dither_rate"])
        control = cfg["relock"]["spiral_gain"] * (true_center - f0) + dither
        state["phase_ticks"] += 1
        tracking = abs(true_center - (f0 + control)) / max(1.0, abs(true_center))
        if tracking < cfg["relock"]["lock_candidate_error"]:
            state["relock_phase"] = "confirm"
            state["phase_ticks"] = 0
            state["confirm_count"] = 1

    elif phase == "confirm":
        control = cfg["relock"]["confirm_gain"] * (true_center - f0)
        tracking = abs(true_center - (f0 + control)) / max(1.0, abs(true_center))
        if tracking < cfg["relock"]["confirm_error"]:
            state["confirm_count"] += 1
        else:
            state["confirm_count"] = 0
            state["relock_phase"] = "spiral"
        if state["confirm_count"] >= cfg["relock"]["confirm_steps"]:
            state["relock_phase"] = "return"
            state["phase_ticks"] = 0

    else:  # return
        control = cfg["relock"]["return_gain"] * (true_center - f0)
        state["phase_ticks"] += 1
        if state["phase_ticks"] >= cfg["relock"]["return_steps"]:
            state["mode"] = "model"
            state["relock_phase"] = None
            state["phase_ticks"] = 0
            state["confirm_count"] = 0

    max_control = abs(true_center) * cfg["relock"]["max_control_ratio"]
    return clamp(control, -max_control, max_control)

def model_control(f0, predicted_center, confidence, cfg):
    err = predicted_center - f0
    max_control = abs(predicted_center) * cfg["model"]["max_control_ratio"]
    if confidence < cfg["model"]["min_confidence"]:
        max_control *= cfg["model"]["low_confidence_scale"]
    return clamp(cfg["model"]["kp"] * err, -max_control, max_control)

def simulate_trial(trial: Dict[str, Any], cfg: Dict[str, Any], seed: int):
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    true_center = trial.get("f_center", rng.choice([76.4,150.0,458.4]))
    f0 = true_center
    C = clamp(trial["reentry_norm"] - trial["new_edge_penalty"])

    history = [true_center]
    latency = [true_center] * cfg["adversarial"]["latency_steps"]

    state = {
        "mode": "model",
        "relock_phase": None,
        "phase_ticks": 0,
        "confirm_count": 0,
        "anchor": true_center,
        "f0": f0
    }

    relock_entries = 0
    relock_success = 0
    relock_times = []
    relock_start = None
    fallback_streak = 0
    false_prediction_damage = 0.0
    lock_loss_count = 0
    shock_events = 0
    shock_recovered = 0
    shock_start = None
    collapsed = False
    collapse_at = None
    series = []

    for t in range(cycles):
        drift = cfg["floating"]["drift_rate"] * math.sin(2*math.pi*t/cfg["floating"]["period"])
        noise = heavy_noise(rng, cfg["noise"], cfg["adversarial"]["heavy_tail_prob"], cfg["adversarial"]["tail_scale"])
        true_center += drift + noise

        jump = 0.0
        if rng.random() < cfg["adversarial"]["jump_prob"]:
            jump = rng.choice([-1,1]) * rng.uniform(cfg["adversarial"]["jump_min"], cfg["adversarial"]["jump_max"])
            true_center += jump
            shock_events += 1
            shock_start = t

        latency.append(true_center)
        observed = latency.pop(0)
        history.append(observed)

        h = history[-cfg["predictor"]["history"]:]
        drift_est = (h[-1] - h[0]) / max(1, len(h)-1) if len(h) > 1 else 0.0
        fake = 0.0
        fake_signal = False
        if rng.random() < cfg["adversarial"]["fake_drift_prob"]:
            fake = rng.choice([-1,1]) * rng.uniform(cfg["adversarial"]["fake_drift_min"], cfg["adversarial"]["fake_drift_max"])
            fake_signal = True

        confidence_bias = cfg["adversarial"]["confidence_trap_bias"] if rng.random() < cfg["adversarial"]["confidence_trap_prob"] else 0.0
        predicted = observed + cfg["predictor"]["lead"] * (drift_est + fake)
        confidence = clamp(1.0 - abs(fake)/max(1.0,abs(observed))*cfg["predictor"]["uncertainty_gain"] + confidence_bias)

        tracking_before = abs(true_center - f0) / max(1.0, abs(true_center))
        predicted_tracking = abs(predicted - f0) / max(1.0, abs(predicted))

        false_damage_step = 0.0
        if fake_signal and tracking_before > predicted_tracking:
            false_damage_step = tracking_before - predicted_tracking
            false_prediction_damage += false_damage_step

        # enter stepped re-lock
        if state["mode"] == "model" and detect_relock(tracking_before, confidence, false_damage_step, fallback_streak, cfg):
            state["mode"] = "relock"
            state["relock_phase"] = "freeze"
            state["phase_ticks"] = 0
            state["confirm_count"] = 0
            state["anchor"] = observed
            relock_entries += 1
            relock_start = t

        if state["mode"] == "relock":
            state["f0"] = f0
            control = relock_step(state, true_center, cfg, rng)
            used_relock = True
            fallback_streak = 0
            if state["mode"] == "model" and relock_start is not None:
                relock_success += 1
                relock_times.append(t - relock_start)
                relock_start = None
        else:
            control = model_control(f0, predicted, confidence, cfg)
            used_relock = False
            if confidence < cfg["model"]["min_confidence"]:
                fallback_streak += 1
            else:
                fallback_streak = 0

        f0 += control
        f1 = 2*f0
        f2 = 0.5*f0

        tracking = abs(true_center - f0) / max(1.0, abs(true_center))
        in_corridor = tracking <= (cfg["floating"]["base_corridor"] + cfg["floating"]["max_extra_corridor"])
        if not in_corridor:
            lock_loss_count += 1

        if shock_start is not None and in_corridor:
            shock_recovered += 1
            shock_start = None

        D = cfg["dissipation_rate"] * (1.0 + 0.010*t)
        repair = cfg["recovery_gain"] * max(0.0, 1.0-C)
        lock_support = cfg["floating"]["lock_support"]*(1-tracking) if in_corridor else -cfg["floating"]["lock_penalty"]
        relock_support = cfg["relock"]["support"] if used_relock else 0.0
        damage_penalty = cfg["adversarial"]["false_damage_penalty"] * false_damage_step

        C = clamp(C + repair + lock_support + relock_support - D - damage_penalty + rng.uniform(-cfg["noise"], cfg["noise"]))

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

        series.append({
            "t": t,
            "true_center": true_center,
            "observed_center": observed,
            "predicted_center": predicted,
            "confidence": confidence,
            "mode": state["mode"],
            "relock_phase": state["relock_phase"],
            "jump": jump,
            "fake_signal": fake_signal,
            "fake_drift": fake,
            "f0": f0,
            "f1": f1,
            "f2": f2,
            "control": control,
            "tracking_error": tracking,
            "in_corridor": in_corridor,
            "false_damage_step": false_damage_step,
            "C": C,
            "D": D,
            "repair": repair,
            "lock_support": lock_support,
            "relock_support": relock_support
        })

    Cs = [x["C"] for x in series]
    tracking_errors = [x["tracking_error"] for x in series]
    mean_C = mean(Cs)
    var_C = mean([(x-mean_C)**2 for x in Cs])
    mean_tracking = mean(tracking_errors)
    lock_loss_rate = lock_loss_count / cycles
    relock_success_rate = relock_success / max(1, relock_entries)
    mean_relock_time = mean(relock_times) if relock_times else None
    shock_recovery_rate = shock_recovered / max(1, shock_events)
    damage_per_cycle = false_prediction_damage / cycles

    S_relock = (
        mean_C
        - var_C
        - 0.45*mean_tracking
        - 0.35*lock_loss_rate
        - 0.25*damage_per_cycle
        + 0.18*relock_success_rate
        + 0.10*shock_recovery_rate
    )

    if collapsed:
        label = "relock_collapse"
    elif S_relock >= cfg["thresholds"]["relock_stable"] and relock_success_rate >= cfg["thresholds"]["min_relock_success"]:
        label = "relock_stable"
    elif S_relock >= cfg["thresholds"]["relock_metastable"]:
        label = "relock_metastable"
    else:
        label = "relock_weak"

    return {
        "mean_C": mean_C,
        "var_C": var_C,
        "mean_tracking_error": mean_tracking,
        "lock_loss_rate": lock_loss_rate,
        "relock_entries": relock_entries,
        "relock_success": relock_success,
        "relock_success_rate": relock_success_rate,
        "mean_relock_time": mean_relock_time,
        "shock_events": shock_events,
        "shock_recovery_rate": shock_recovery_rate,
        "false_prediction_damage": false_prediction_damage,
        "damage_per_cycle": damage_per_cycle,
        "S_relock": S_relock,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "label": label,
        "series": series
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="results/adversarial_stress_trials.json")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json","r",encoding="utf-8"))
    trials = json.load(open(args.input,"r",encoding="utf-8"))

    rows = []
    for idx, trial in enumerate(trials):
        base = {
            "trial_index": trial.get("trial_index",idx),
            "previous_label": trial.get("label","adversarial_unknown"),
            "reentry_norm": trial.get("reentry_norm",0.84),
            "new_edge_penalty": trial.get("new_edge_penalty",0.09),
            "f_center": [76.4,150.0,458.4][idx%3]
        }
        rows.append({**base, **simulate_trial(base,cfg,cfg["seed"]+idx*100)})

    stable = [r for r in rows if r["label"]=="relock_stable"]
    meta = [r for r in rows if r["label"]=="relock_metastable"]
    weak = [r for r in rows if r["label"]=="relock_weak"]
    col = [r for r in rows if r["label"]=="relock_collapse"]

    summary = {
        "trials": len(rows),
        "relock_stable": len(stable),
        "relock_metastable": len(meta),
        "relock_weak": len(weak),
        "relock_collapse": len(col),
        "mean_S_relock": mean([r["S_relock"] for r in rows]),
        "mean_tracking_error": mean([r["mean_tracking_error"] for r in rows]),
        "mean_lock_loss_rate": mean([r["lock_loss_rate"] for r in rows]),
        "mean_relock_success_rate": mean([r["relock_success_rate"] for r in rows]),
        "mean_false_prediction_damage": mean([r["false_prediction_damage"] for r in rows]),
        "mean_damage_per_cycle": mean([r["damage_per_cycle"] for r in rows]),
        "mean_shock_recovery_rate": mean([r["shock_recovery_rate"] for r in rows]),
        "label": "stepped_relock_success" if len(stable)+len(meta)>=len(rows)*0.70 and len(col)==0 else "stepped_relock_limited",
        "top_trials": sorted(rows,key=lambda x:x["S_relock"], reverse=True)[:10],
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"stepped_relock_summary.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"stepped_relock_trials.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "relock_stable": summary["relock_stable"],
        "relock_metastable": summary["relock_metastable"],
        "relock_weak": summary["relock_weak"],
        "relock_collapse": summary["relock_collapse"],
        "mean_S_relock": summary["mean_S_relock"],
        "mean_relock_success_rate": summary["mean_relock_success_rate"],
        "mean_false_prediction_damage": summary["mean_false_prediction_damage"],
        "label": summary["label"]
    }, indent=2))

if __name__ == "__main__":
    main()
