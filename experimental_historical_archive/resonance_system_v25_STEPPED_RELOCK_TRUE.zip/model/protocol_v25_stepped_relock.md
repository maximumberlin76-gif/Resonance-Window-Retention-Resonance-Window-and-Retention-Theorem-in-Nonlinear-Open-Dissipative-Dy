# v25 Stepped Re-lock Protocol

1. Load v24 adversarial trials.
2. Simulate adversarial floating window.
3. Detect failure:
   - tracking spike
   - confidence drop
   - false prediction damage
   - fallback streak
4. Enter stepped re-lock:
   - freeze
   - anchor
   - spiral
   - confirm
   - return
5. Measure re-lock success and time.
6. Compare false prediction damage.
7. Classify self-healing control.
