# v25 Equations

Re-lock phase control:

freeze:
f0(t+1) = f0(t)

anchor:
f0(t+1) = f0(t) + alpha * (anchor - f0)

spiral:
f0(t+1) = f0(t) + beta * (true_center - f0) + dither

confirm:
lock accepted after N stable steps

S_relock =
mean_C
- var_C
- 0.45 * mean_tracking_error
- 0.35 * lock_loss_rate
- 0.25 * damage_per_cycle
+ 0.18 * relock_success_rate
+ 0.10 * shock_recovery_rate
