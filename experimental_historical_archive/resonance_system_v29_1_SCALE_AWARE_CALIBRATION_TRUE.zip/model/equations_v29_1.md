# v29.1 Equations

## Physical Time Conversion

tau_physical = tau_steps · cycle_time(scale)

## Coherence Accumulation

Theta(t0, tau) =
∫[C(t) - P(t) - D(t)] dt

## Scale-Aware Thresholds

Theta_crit = Theta_crit(scale)

tau_min = tau_min(scale)

## Period Band Hypothesis

7 <= stable_periods <= 9:
    synthesis_window_candidate

stable_periods >= 10:
    closed_structure_candidate

## Anti-condition

If accumulation is too fast or unstable:
    chaos_or_overshoot
