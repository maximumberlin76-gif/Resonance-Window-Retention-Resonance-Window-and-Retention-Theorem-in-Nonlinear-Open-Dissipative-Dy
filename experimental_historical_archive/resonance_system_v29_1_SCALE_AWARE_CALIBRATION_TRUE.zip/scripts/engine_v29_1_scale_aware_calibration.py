#!/usr/bin/env python3
"""
v29.1 TRUE SCALE-AWARE CALIBRATION

Correction after v29:
tau_steps is not physical time.

In nonlinear dissipative open dynamic systems,
coherence accumulation depends on scale.

Core:
tau_physical = tau_steps * cycle_time(scale)

Working hypothesis:
7-9 stable accumulation periods -> synthesis-window candidate.
10+ stable periods -> closed-structure candidate.

This is a calibration sandbox, not a physical claim.
"""

from __future__ import annotations
import json, random, math, argparse
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def simulate(seed, scale_name, scale_cfg, cfg):
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    C = rng.uniform(0.35, 0.55)
    P = scale_cfg["P"]
    D = scale_cfg["D"]
    growth_rate = scale_cfg["growth_rate"]
    cycle_time = scale_cfg["cycle_time"]

    theta = 0.0
    current_tau_steps = 0
    max_tau_steps = 0
    stable_periods = 0
    period_accum = 0.0
    period_len = scale_cfg["period_steps"]

    period_thetas = []
    chaos_events = 0
    series = []

    for t in range(cycles):
        phase = 2 * math.pi * (t % period_len) / period_len
        modulation = 1.0 + scale_cfg["modulation"] * math.sin(phase)
        noise = rng.uniform(-scale_cfg["noise"], scale_cfg["noise"])

        dC = growth_rate * modulation * (1.0 - C) - D * scale_cfg["dissipation_weight"] - P * scale_cfg["load_weight"] + noise

        if rng.random() < scale_cfg["spike_prob"]:
            dC += rng.uniform(scale_cfg["spike_min"], scale_cfg["spike_max"])

        if abs(dC) > cfg["safe_dC_limit"]:
            chaos_events += 1

        C = clamp(C + dC)
        delta = C - P - D

        if delta > 0:
            theta += delta
            period_accum += delta
            current_tau_steps += 1
        else:
            max_tau_steps = max(max_tau_steps, current_tau_steps)
            current_tau_steps = 0

        if (t + 1) % period_len == 0:
            period_thetas.append(period_accum)
            if period_accum >= cfg["period_theta_min"]:
                stable_periods += 1
            period_accum = 0.0

        max_tau_steps = max(max_tau_steps, current_tau_steps)

        series.append({
            "t_step": t,
            "t_physical": t * cycle_time,
            "scale": scale_name,
            "C": C,
            "P": P,
            "D": D,
            "delta": delta,
            "theta": theta,
            "tau_steps": current_tau_steps,
            "tau_physical": current_tau_steps * cycle_time,
            "dC": dC
        })

    tau_physical = max_tau_steps * cycle_time
    chaos_rate = chaos_events / cycles
    dwell_period_count = max_tau_steps / max(1, period_len)

    if chaos_rate >= cfg["chaos_rate_limit"]:
        outcome = "chaos_or_overshoot"
    elif stable_periods >= 10:
        outcome = "closed_structure_candidate"
    elif stable_periods in (7, 8, 9):
        outcome = "synthesis_window_candidate"
    elif stable_periods >= 1:
        outcome = "accumulation_in_progress"
    else:
        outcome = "no_stable_accumulation"

    return {
        "seed": seed,
        "scale": scale_name,
        "cycle_time": cycle_time,
        "period_steps": period_len,
        "theta": theta,
        "max_tau_steps": max_tau_steps,
        "tau_physical": tau_physical,
        "stable_periods": stable_periods,
        "dwell_period_count": dwell_period_count,
        "period_thetas": period_thetas,
        "chaos_rate": chaos_rate,
        "outcome": outcome,
        "mean_C": mean([x["C"] for x in series]),
        "mean_delta": mean([x["delta"] for x in series]),
        "series": series
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    rows = []
    for scale_name, scale_cfg in cfg["scales"].items():
        for i in range(cfg["trials_per_scale"]):
            rows.append(simulate(cfg["seed"] + i * 100 + scale_cfg["seed_offset"], scale_name, scale_cfg, cfg))

    by_scale = {}
    for r in rows:
        by_scale.setdefault(r["scale"], []).append(r)

    scale_summary = {}
    for scale, items in by_scale.items():
        outcomes = {}
        for x in items:
            outcomes[x["outcome"]] = outcomes.get(x["outcome"], 0) + 1
        scale_summary[scale] = {
            "count": len(items),
            "cycle_time": items[0]["cycle_time"],
            "mean_theta": mean([x["theta"] for x in items]),
            "mean_tau_steps": mean([x["max_tau_steps"] for x in items]),
            "mean_tau_physical": mean([x["tau_physical"] for x in items]),
            "mean_stable_periods": mean([x["stable_periods"] for x in items]),
            "mean_dwell_period_count": mean([x["dwell_period_count"] for x in items]),
            "outcomes": outcomes
        }

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "trials": len(rows),
        "hypothesis": "synthesis_requires_accumulation_over_multiple_periods_in_time",
        "tested_period_bands": {
            "synthesis_window_candidate": "7-9 stable accumulation periods",
            "closed_structure_candidate": "10 or more stable accumulation periods"
        },
        "scale_summary": scale_summary,
        "main_conclusion": "tau_steps_must_be_converted_to_tau_physical_by_scale",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"scale_aware_calibration_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"scale_aware_calibration_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "main_conclusion": summary["main_conclusion"],
        "scale_summary": scale_summary
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
