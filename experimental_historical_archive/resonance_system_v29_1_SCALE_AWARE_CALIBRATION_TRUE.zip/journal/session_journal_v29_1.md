# Session Journal — v29.1

## Step

v29.1 — Scale-Aware Calibration.

## User correction

Time cannot be treated as abstract iteration count.
The key word is "over time", which implies periods and dwell duration.

## Fixed Invariants

1. Synthesis requires accumulated coherence over time.
2. tau_steps is not tau_physical.
3. There are different cycle times for micro, meso, and macro regimes.
4. Stable accumulation likely requires multiple periods.
5. The 7/9 period band is tested as a hypothesis, not asserted as dogma.
6. 10+ periods are treated as possible closed-structure candidates.

## Core Formula

tau_physical = tau_steps · cycle_time(scale)

## Next Step

v29.2 — tune scale parameters so each regime produces:
- accumulation_in_progress
- synthesis_window_candidate
- chaos_or_overshoot

This will define transition boundaries.
