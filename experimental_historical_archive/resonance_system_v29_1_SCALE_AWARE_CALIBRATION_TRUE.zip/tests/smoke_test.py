#!/usr/bin/env python3
from pathlib import Path
import json
required = [
    "scripts/engine_v29_1_scale_aware_calibration.py",
    "results/scale_aware_calibration_summary.json",
    "results/scale_aware_calibration_trials.json",
    "docs/README.md",
    "model/equations_v29_1.md",
    "journal/session_journal_v29_1.md"
]
for item in required:
    p = Path(item)
    assert p.exists(), f"missing: {item}"
    assert p.stat().st_size > 100, f"too small: {item}"
s = json.load(open("results/scale_aware_calibration_summary.json", "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "scale_summary" in s
print("SMOKE_OK")
