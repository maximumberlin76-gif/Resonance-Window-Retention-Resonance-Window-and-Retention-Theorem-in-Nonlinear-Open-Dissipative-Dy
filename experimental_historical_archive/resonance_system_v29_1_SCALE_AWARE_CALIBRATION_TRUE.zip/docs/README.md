# v29.1 — Scale-Aware Calibration

## Abstract

This module extends calibration of coherence accumulation in nonlinear dissipative open dynamic systems by separating computational step count from physical time.

The key correction is:

```text
tau_steps ≠ tau_physical
tau_physical = tau_steps · cycle_time(scale)
```

The same number of computational iterations can represent radically different physical durations in micro, meso, and macro regimes.

This matters because synthesis is not an instantaneous threshold event. It is a consequence of accumulated structural coherence over time.

## Core Claim

Fast accumulation tends toward spike, rupture, or chaos.

Slow accumulation over multiple periods allows:

- adaptation,
- internal reconfiguration,
- scaling,
- controlled transition.

## Period Hypothesis

The module tests a working hypothesis:

```text
7–9 stable accumulation periods → synthesis-window candidate
10+ stable accumulation periods → closed-structure candidate
```

This is not treated as dogma. It is a calibration band for testing dwell time.

## System Class

All results apply strictly to:

```text
nonlinear dissipative open dynamic systems
```

## Why Scale Matters

A micro-scale process can complete many coherence cycles in extremely short physical time.

A macro-scale process may require much longer dwell time.

Therefore:

```text
tau_min must be scale-aware
Theta_crit must be scale-aware
```

## Run

```bash
python scripts/engine_v29_1_scale_aware_calibration.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/scale_aware_calibration_summary.json
results/scale_aware_calibration_trials.json
journal/session_journal_v29_1.md
```

## Limitation

This is a computational calibration sandbox, not a direct physical measurement.
