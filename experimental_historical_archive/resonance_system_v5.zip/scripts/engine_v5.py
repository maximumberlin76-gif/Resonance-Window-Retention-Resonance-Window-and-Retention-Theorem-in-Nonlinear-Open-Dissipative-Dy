
import numpy as np
import json
import random

class ResonanceSystem:
    def __init__(self, N=30):
        self.N = N
        self.reset()

    def reset(self):
        self.theta = np.random.uniform(0, 2*np.pi, self.N)
        self.omega = np.random.uniform(0.9,1.1,self.N)
        self.K = 0.6

    def order_param(self):
        return np.abs(np.mean(np.exp(1j*self.theta)))

    def step(self, f0,f1,f2,A,phi,duty,noise,dt=0.05):
        drive = A*(np.sin(2*np.pi*f0*dt+phi)+
                   np.sin(2*np.pi*f1*dt)+
                   np.sin(2*np.pi*f2*dt))
        drive *= duty

        for i in range(self.N):
            coupling = np.sum(np.sin(self.theta - self.theta[i]))
            noise_term = noise*np.random.randn()
            self.theta[i] += (self.omega[i] + self.K*coupling/self.N + drive + noise_term)*dt

    def run(self, f0,f1,f2,A,phi,duty,noise,steps=200):
        R_vals=[]
        for _ in range(steps):
            self.step(f0,f1,f2,A,phi,duty,noise)
            R_vals.append(self.order_param())
        return np.mean(R_vals)

def retention_test(sys, params):
    R_on = sys.run(**params)
    R_off = sys.run(0,0,0,0,0,0,params["noise"])
    return R_on, R_off

def classify(R_on,R_off):
    if R_off > 0.65:
        return "stable"
    elif R_on > 0.5:
        return "metastable"
    else:
        return "reject"

def reproducibility_test(params, runs=5):
    scores=[]
    for _ in range(runs):
        sys = ResonanceSystem()
        R_on,R_off = retention_test(sys,params)
        scores.append(R_off)
    return np.mean(scores), np.std(scores)

def scan(freqs, A_range, phi_range, duty_range, noise):
    results=[]
    for f0 in freqs:
        for f1 in freqs:
            for f2 in freqs:
                for A in A_range:
                    for phi in phi_range:
                        for duty in duty_range:
                            params = {
                                "f0":f0,"f1":f1,"f2":f2,
                                "A":A,"phi":phi,"duty":duty,
                                "noise":noise
                            }
                            mean,std = reproducibility_test(params)
                            label = classify(mean,mean)
                            results.append({
                                **params,
                                "R_mean":float(mean),
                                "R_std":float(std),
                                "class":label
                            })
    return results

if __name__ == "__main__":
    freqs = [50,100,150,300,600]
    A_range = [0.3,0.5,0.7]
    phi_range = [0,1.57,3.14]
    duty_range = [0.3,0.6,0.9]

    res = scan(freqs,A_range,phi_range,duty_range,noise=0.02)

    with open("results.json","w") as f:
        json.dump(res,f,indent=2)

    print("Scan complete.")
