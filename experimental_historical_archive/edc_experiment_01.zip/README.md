# Experiment 01 — Resonance Window Search

## Goal

Detect candidate resonance windows in a nonlinear dynamic dissipative oscillator ensemble.

## Cycle

1. Scan frequency `omega_ext`
2. Scan amplitude `F_ext`
3. Scan phase `phi`
4. Scan duty-cycle
5. Estimate `D_proxy`
6. Compute:

```text
R_net = P_in · eta_eff − D_proxy
```

7. Fix or reject window.

## Outputs

- `baseline.json`
- `sweep_results.csv`
- `top_candidates.csv`
- `top_candidates.json`

## Candidate logic

Candidate window = high `R_net`, high `R_mean_last_10pct`, positive retention after forcing OFF.
