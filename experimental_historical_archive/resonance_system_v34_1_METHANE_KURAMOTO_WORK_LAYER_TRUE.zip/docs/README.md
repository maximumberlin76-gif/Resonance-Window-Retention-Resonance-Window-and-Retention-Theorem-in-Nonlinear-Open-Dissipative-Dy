# v34.1 — Methane Kuramoto / Work-Accumulation Coupling Layer

## Abstract

This module adds a Kuramoto phase-coherence layer to methane plasma and filters it through the strict work-accumulation criterion.

The system is treated strictly as a nonlinear dissipative open dynamic system.

Methane is molecular, so the model includes:

- dissociation fraction,
- recombination load,
- chemistry loss,
- chemistry overload rejection.

This is a computational sandbox, not laboratory evidence.

## Core Principle

```text
R is an indicator.
Θ_N is the admission criterion.
Chemistry loss can close the window.
```

## Tested Scenarios

- baseline
- resonance
- off_resonance
- pulsed
- soft_pulsed
- chemistry_overload
- retention_off

## Candidate Rule

```text
R_final >= R_lock
and
stable_work_periods >= synthesis_min_periods
and
Θ_N >= Θ_work_crit
and
retention_R_tail >= R_retention_min
and
chemistry_overload is bounded
```

## Run

```bash
python scripts/engine_v34_1_methane_kuramoto_work_layer.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/methane_kuramoto_work_layer_summary.json
results/methane_kuramoto_work_layer_trials.json
journal/session_journal_v34_1.md
```

## Next Step

v34.2 — methane phase-lock/work calibration, or v35 — oxygen plasma.
