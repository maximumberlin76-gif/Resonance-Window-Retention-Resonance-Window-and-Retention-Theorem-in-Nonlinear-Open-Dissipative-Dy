#!/usr/bin/env python3
"""
v34.1 TRUE METHANE KURAMOTO / WORK-ACCUMULATION COUPLING LAYER

Purpose:
Add a Kuramoto phase-coherence layer to methane plasma and filter it through
positive structural work accumulated over completed periods.

System class:
nonlinear dissipative open dynamic systems

Important:
This is a computational sandbox, not a laboratory measurement.

Methane-specific risk:
- molecular dissociation
- recombination load
- chemistry loss inside D(t)
- possible R-lock without structural retention
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def order_parameter(phases):
    re = sum(math.cos(p) for p in phases) / len(phases)
    im = sum(math.sin(p) for p in phases) / len(phases)
    return math.sqrt(re * re + im * im), math.atan2(im, re)

def scenario_params(name, cfg):
    base = dict(cfg["kuramoto"]["base"])
    if name == "baseline":
        base.update({"F_ext": 0.0, "detune": 0.0, "pulse": False, "noise_mult": 1.0, "chem_mult": 1.0, "drive_off_at": None})
    elif name == "resonance":
        base.update({"F_ext": 0.30, "detune": 0.0, "pulse": False, "noise_mult": 1.0, "chem_mult": 1.0, "drive_off_at": None})
    elif name == "off_resonance":
        base.update({"F_ext": 0.30, "detune": 0.24, "pulse": False, "noise_mult": 1.0, "chem_mult": 1.2, "drive_off_at": None})
    elif name == "pulsed":
        base.update({"F_ext": 0.42, "detune": 0.0, "pulse": True, "duty": 0.36, "noise_mult": 1.0, "chem_mult": 1.0, "drive_off_at": None})
    elif name == "soft_pulsed":
        base.update({"F_ext": 0.34, "detune": 0.0, "pulse": True, "duty": 0.26, "noise_mult": 0.9, "chem_mult": 0.8, "drive_off_at": None})
    elif name == "chemistry_overload":
        base.update({"F_ext": 0.52, "detune": 0.08, "pulse": True, "duty": 0.55, "noise_mult": 1.4, "chem_mult": 2.0, "drive_off_at": None})
    elif name == "retention_off":
        base.update({"F_ext": 0.38, "detune": 0.0, "pulse": True, "duty": 0.34, "noise_mult": 1.0, "chem_mult": 1.0, "drive_off_at": int(cfg["simulation"]["steps"] * 0.62)})
    else:
        raise ValueError(name)
    return base

def simulate(seed, scenario, cfg):
    rng = random.Random(seed)

    N = cfg["kuramoto"]["N"]
    steps = cfg["simulation"]["steps"]
    dt = cfg["simulation"]["dt"]
    period_steps = cfg["simulation"]["period_steps"]

    p = scenario_params(scenario, cfg)

    omega0 = cfg["methane"]["acoustic_anchor_mhz"]
    omega_ext = omega0 * (1.0 + p.get("detune", 0.0))

    phases = [rng.uniform(-math.pi, math.pi) for _ in range(N)]
    natural = [rng.gauss(omega0, cfg["kuramoto"]["omega_sigma_mhz"]) for _ in range(N)]

    C = rng.uniform(0.28, 0.48)
    dissociation_fraction = rng.uniform(0.0, 0.02)
    recombination_load = 0.0

    theta_work = 0.0
    theta_balance = 0.0
    stable_work_periods = 0
    weak_work_periods = 0
    failed_periods = 0

    W_period = 0.0
    balance_period = 0.0
    period_R_values = []
    period_records = []
    sampled = []

    R_max = 0.0
    convergence_time = None
    R_post_off = None
    chemistry_overload_steps = 0

    for t in range(steps):
        time = t * dt

        drive_active = True
        if p.get("drive_off_at") is not None and t >= p["drive_off_at"]:
            drive_active = False

        pulse_gate = 1.0
        if p.get("pulse", False):
            pulse_gate = 1.0 if (t % period_steps) < int(period_steps * p.get("duty", 0.5)) else 0.0

        F = p["F_ext"] * pulse_gate * (1.0 if drive_active else 0.0)

        R_now, psi = order_parameter(phases)
        omega_time = 2 * math.pi * omega_ext * time

        new_phases = []
        for i, phi in enumerate(phases):
            coupling = p["K"] * R_now * math.sin(psi - phi)
            external = F * math.sin(omega_time - phi)
            noise = rng.gauss(0.0, cfg["kuramoto"]["noise"] * p.get("noise_mult", 1.0))
            drift = cfg["kuramoto"]["omega_drift"] * math.sin(2 * math.pi * t / max(1, steps))
            dphi = (natural[i] + drift + coupling + external) * dt + noise
            new_phases.append((phi + dphi + math.pi) % (2 * math.pi) - math.pi)

        phases = new_phases
        R, _ = order_parameter(phases)
        R_max = max(R_max, R)

        if convergence_time is None and R >= cfg["thresholds"]["R_lock"]:
            convergence_time = time
        if p.get("drive_off_at") is not None and t == p["drive_off_at"]:
            R_post_off = R

        # Methane chemistry proxy driven by strong forcing and phase disorder.
        disorder = max(0.0, 1.0 - R)
        dissociation_drive = F * (0.6 + disorder) * p.get("chem_mult", 1.0)

        dissociation_fraction = clamp(
            dissociation_fraction
            + cfg["chemistry"]["dissociation_gain"] * dissociation_drive
            - cfg["chemistry"]["recombination_gain"] * recombination_load,
            0.0,
            0.85
        )

        recombination_load = clamp(
            cfg["chemistry"]["recombination_memory"] * recombination_load
            + cfg["chemistry"]["recombination_from_dissociation"] * dissociation_fraction,
            0.0,
            1.0
        )

        chemistry_loss = (
            cfg["chemistry"]["chemistry_loss_base"]
            + cfg["chemistry"]["dissociation_loss_weight"] * dissociation_fraction
            + cfg["chemistry"]["recombination_loss_weight"] * recombination_load
        )

        if chemistry_loss > cfg["thresholds"]["chemistry_loss_limit"]:
            chemistry_overload_steps += 1

        det = abs(p.get("detune", 0.0))
        P = cfg["balance"]["P_base"] + cfg["balance"]["P_detune"] * det + cfg["balance"]["P_chem"] * dissociation_fraction
        D = cfg["balance"]["D_base"] + cfg["balance"]["D_noise"] * p.get("noise_mult", 1.0) + chemistry_loss

        useful_work_step = max(0.0, R - cfg["thresholds"]["R_work_floor"]) * F * cfg["balance"]["work_gain"]
        W_period += useful_work_step
        theta_work += useful_work_step

        # C grows from R only if chemistry loss remains bounded.
        chemistry_penalty = cfg["balance"]["C_chem_penalty"] * chemistry_loss
        C = clamp(C + cfg["balance"]["C_gain"] * (R - C) + useful_work_step - 0.010 * P - 0.012 * D - chemistry_penalty)

        delta = C - P - D
        if delta > 0:
            theta_balance += delta
            balance_period += delta

        period_R_values.append(R)

        if (t + 1) % period_steps == 0:
            period_mean_R = mean(period_R_values)
            period_R_min = min(period_R_values) if period_R_values else 0.0

            if (
                W_period >= cfg["thresholds"]["W_period_min"]
                and balance_period >= cfg["thresholds"]["balance_period_min"]
                and period_mean_R >= cfg["thresholds"]["R_period_mean_min"]
                and period_R_min >= cfg["thresholds"]["R_period_min_floor"]
                and chemistry_loss <= cfg["thresholds"]["chemistry_loss_limit"]
            ):
                stable_work_periods += 1
                label = "stable_positive_work_period"
            elif W_period > 0:
                weak_work_periods += 1
                label = "weak_positive_work_period"
            else:
                failed_periods += 1
                label = "failed_period"

            period_records.append({
                "period_index": len(period_records) + 1,
                "W_period": round(W_period, 8),
                "balance_period": round(balance_period, 8),
                "period_mean_R": round(period_mean_R, 6),
                "period_R_min": round(period_R_min, 6),
                "chemistry_loss": round(chemistry_loss, 8),
                "dissociation_fraction": round(dissociation_fraction, 8),
                "label": label
            })

            W_period = 0.0
            balance_period = 0.0
            period_R_values = []

        if t % cfg["simulation"]["sample_every"] == 0 or t == steps - 1:
            sampled.append({
                "step": t,
                "scenario": scenario,
                "R": round(R, 6),
                "C": round(C, 6),
                "theta_work": round(theta_work, 8),
                "theta_balance": round(theta_balance, 8),
                "chemistry_loss": round(chemistry_loss, 8),
                "dissociation_fraction": round(dissociation_fraction, 8),
                "F": round(F, 6),
                "delta": round(delta, 6),
                "drive_active": drive_active
            })

    tail = sampled[int(len(sampled) * 0.75):]
    retention_R_tail = mean([x["R"] for x in tail])
    R_final = sampled[-1]["R"]
    C_final = sampled[-1]["C"]
    chemistry_overload_rate = chemistry_overload_steps / steps

    if (
        R_final >= cfg["thresholds"]["R_lock"]
        and stable_work_periods >= cfg["thresholds"]["synthesis_min_periods"]
        and theta_work >= cfg["thresholds"]["Theta_work_crit"]
        and retention_R_tail >= cfg["thresholds"]["R_retention_min"]
        and chemistry_overload_rate < cfg["thresholds"]["chemistry_overload_rate_limit"]
    ):
        outcome = "methane_work_accumulation_resonance_window_candidate"
    elif chemistry_overload_rate >= cfg["thresholds"]["chemistry_overload_rate_limit"]:
        outcome = "methane_chemistry_overload"
    elif R_final >= cfg["thresholds"]["R_lock"] and theta_work < cfg["thresholds"]["Theta_work_crit"]:
        outcome = "false_phase_lock_without_work_accumulation"
    elif R_final >= cfg["thresholds"]["R_lock"]:
        outcome = "phase_lock_incomplete_work_accumulation"
    elif R_max >= cfg["thresholds"]["R_lock"] and retention_R_tail < cfg["thresholds"]["R_retention_min"]:
        outcome = "transient_lock_no_retention"
    elif stable_work_periods > 0:
        outcome = "positive_work_accumulation_without_phase_lock"
    else:
        outcome = "no_phase_lock"

    return {
        "seed": seed,
        "scenario": scenario,
        "R_final": R_final,
        "R_max": round(R_max, 6),
        "C_final": C_final,
        "theta_work": round(theta_work, 8),
        "theta_balance": round(theta_balance, 8),
        "stable_work_periods": stable_work_periods,
        "weak_work_periods": weak_work_periods,
        "failed_periods": failed_periods,
        "convergence_time": convergence_time,
        "R_post_off": R_post_off,
        "retention_R_tail": round(retention_R_tail, 6),
        "chemistry_overload_rate": round(chemistry_overload_rate, 6),
        "outcome": outcome,
        "period_records": period_records,
        "series_sampled": sampled
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    rows = []

    for sidx, scenario in enumerate(cfg["scenarios"]):
        for i in range(cfg["trials_per_scenario"]):
            rows.append(simulate(cfg["seed"] + sidx * 10000 + i * 100, scenario, cfg))

    outcomes = {}
    by_scenario = {}
    for r in rows:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1
        by_scenario.setdefault(r["scenario"], []).append(r)

    scenario_summary = {}
    for scenario, items in by_scenario.items():
        scenario_summary[scenario] = {
            "count": len(items),
            "mean_R_final": mean([x["R_final"] for x in items]),
            "mean_R_max": mean([x["R_max"] for x in items]),
            "mean_C_final": mean([x["C_final"] for x in items]),
            "mean_theta_work": mean([x["theta_work"] for x in items]),
            "mean_stable_work_periods": mean([x["stable_work_periods"] for x in items]),
            "mean_retention_R_tail": mean([x["retention_R_tail"] for x in items]),
            "mean_chemistry_overload_rate": mean([x["chemistry_overload_rate"] for x in items]),
            "outcomes": {k: sum(1 for x in items if x["outcome"] == k) for k in sorted(set(x["outcome"] for x in items))}
        }

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "methane_reference": {
            "molecule": "CH4",
            "acoustic_anchor_mhz": cfg["methane"]["acoustic_anchor_mhz"],
            "note": "Kuramoto/work-accumulation coupling sandbox, not laboratory measurement."
        },
        "trials": len(rows),
        "outcomes": outcomes,
        "scenario_summary": scenario_summary,
        "main_conclusion": "methane_phase_coherence_is_strongly_limited_by_chemistry_loss_and_work_retention",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"methane_kuramoto_work_layer_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"methane_kuramoto_work_layer_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": len(rows),
        "outcomes": outcomes,
        "scenario_summary": scenario_summary,
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
