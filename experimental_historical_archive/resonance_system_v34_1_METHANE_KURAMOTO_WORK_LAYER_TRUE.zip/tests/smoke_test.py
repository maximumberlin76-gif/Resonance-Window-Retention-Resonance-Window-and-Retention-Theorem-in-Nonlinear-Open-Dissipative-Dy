#!/usr/bin/env python3
from pathlib import Path
import json
required = [
    "scripts/engine_v34_1_methane_kuramoto_work_layer.py",
    "results/methane_kuramoto_work_layer_summary.json",
    "results/methane_kuramoto_work_layer_trials.json",
    "docs/README.md",
    "model/equations_v34_1.md",
    "journal/session_journal_v34_1.md"
]
for item in required:
    p = Path(item)
    assert p.exists(), f"missing {item}"
    assert p.stat().st_size > 100, f"too small {item}"
s = json.load(open("results/methane_kuramoto_work_layer_summary.json", "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "scenario_summary" in s
print("SMOKE_OK")
