# v34.1 Equations

## Kuramoto Layer

dφ_i/dt =
ω_i + K R sin(ψ - φ_i) + F_ext sin(ω_ext t - φ_i) + η_i(t)

## Work Accumulation

W_period(k) =
∫ max(0, R(t) - R_floor) · F_ext(t) dt

Θ_N =
Σ W_period(k)

## Methane Chemistry Loss

D(t) includes:
- base dissipation
- dissociation loss
- recombination load

## Candidate Rule

valid window if:

R_final >= R_lock
and
Θ_N >= Θ_work_crit
and
stable_work_periods >= threshold
and
retention holds
and
chemistry overload is bounded
