#!/usr/bin/env python3
# v29 calibration of Theta_crit and tau_min

import json, random, math
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def simulate(seed):
    rng = random.Random(seed)
    C, P, D = 0.5, 0.08, 0.06
    theta = 0.0
    tau = 0
    max_tau = 0

    for t in range(300):
        growth = 0.01*(1-C)
        noise = rng.uniform(-0.02,0.02)
        C = clamp(C + growth - P - D + noise)

        delta = C - P - D

        if delta > 0:
            theta += delta
            tau += 1
        else:
            max_tau = max(max_tau, tau)
            tau = 0

    max_tau = max(max_tau, tau)
    return theta, max_tau

def main():
    results = [simulate(100+i) for i in range(100)]
    thetas = [r[0] for r in results]
    taus = [r[1] for r in results]

    theta_crit = sorted(thetas)[int(0.8*len(thetas))]
    tau_min = sorted(taus)[int(0.8*len(taus))]

    summary = {
        "theta_crit_estimated": theta_crit,
        "tau_min_estimated": tau_min,
        "mean_theta": sum(thetas)/len(thetas),
        "mean_tau": sum(taus)/len(taus)
    }

    Path("results").mkdir(exist_ok=True)
    json.dump(summary, open("results/calibration_summary.json","w"), indent=2)
    print(summary)

if __name__ == "__main__":
    main()
