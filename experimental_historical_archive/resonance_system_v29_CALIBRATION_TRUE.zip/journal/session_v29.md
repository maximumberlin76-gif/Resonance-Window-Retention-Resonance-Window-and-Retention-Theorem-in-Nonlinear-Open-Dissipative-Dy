# v29 Journal

Goal:
Calibrate Theta_crit and tau_min.

Result:
Thresholds estimated statistically from simulations.
