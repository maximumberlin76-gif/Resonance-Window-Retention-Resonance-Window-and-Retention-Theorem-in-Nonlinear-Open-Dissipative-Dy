# v29 Calibration

## Abstract

This module estimates critical thresholds:

Theta_crit — accumulated coherence threshold  
tau_min — minimum dwell time  

These parameters define the boundary between:

accumulation vs synthesis
