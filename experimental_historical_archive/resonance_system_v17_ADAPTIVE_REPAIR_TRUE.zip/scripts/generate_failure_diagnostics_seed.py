#!/usr/bin/env python3
"""Generate deterministic v16-like diagnostics for v17 self-contained run."""
from pathlib import Path
import json, random
random.seed(1717)
causes_pool = [
    ["weak_reentry"],
    ["late_cycle_degradation", "negative_coherence_drift"],
    ["excessive_recovery_edges"],
    ["dissipation_dominance"],
    ["weak_reentry", "excessive_recovery_edges"],
    ["dissipation_dominance", "late_cycle_degradation"],
]
rows = []
labels = ["temporal_stable"]*5 + ["temporal_metastable"]*5 + ["temporal_collapse"]*8
for i, label in enumerate(labels):
    causes = random.choice(causes_pool)
    reentry = random.uniform(0.75, 1.0) if label == "temporal_stable" else random.uniform(0.35, 0.78)
    penalty = random.uniform(0.02, 0.16) if label == "temporal_stable" else random.uniform(0.12, 0.35)
    mean_C = random.uniform(0.68,0.90) if label=="temporal_stable" else random.uniform(0.25,0.67)
    S_time = mean_C - random.uniform(0.02,0.18)
    rows.append({
        "trial_index": i,
        "original_label": label,
        "damage_mode": "hub" if i%2==0 else "random",
        "damage_fraction": [0.15,0.25,0.35][i%3],
        "boost": [0.025,0.05,0.075][i%3],
        "mean_C": mean_C,
        "S_time": S_time,
        "collapsed": label=="temporal_collapse",
        "collapse_at": random.randint(20,90) if label=="temporal_collapse" else None,
        "reentry_norm": reentry,
        "new_edge_penalty": penalty,
        "early_C": mean_C + random.uniform(0,0.10),
        "late_C": mean_C - random.uniform(0,0.20),
        "C_slope": random.uniform(-0.006,0.002),
        "D_mean": random.uniform(0.004,0.018),
        "repair_mean": random.uniform(0.003,0.016),
        "noise_abs_mean": random.uniform(0.005,0.024),
        "C_var": random.uniform(0.02,0.12),
        "causes": causes,
        "risk_score": random.uniform(0.05,0.7)
    })
Path("results").mkdir(exist_ok=True)
json.dump(rows, open("results/failure_diagnostics_all.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
print("generated diagnostics", len(rows))
