#!/usr/bin/env python3
"""
Resonance System v17 TRUE ADAPTIVE REPAIR

v16 diagnosed failure causes.
v17 applies cause-specific repair policies and retests temporal stability.

Policies:
- weak_reentry -> boost initial reentry / reduce damage threshold
- excessive_recovery_edges -> prune weak recovered links
- dissipation_dominance -> increase repair gain / reduce D(t)
- negative_coherence_drift -> add phase correction
- late_cycle_degradation -> add late-cycle support
- noise_sensitive -> reduce noise impact / increase damping

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def apply_policy(diag, cfg):
    params = {
        "reentry_boost": 0.0,
        "edge_penalty_reduction": 0.0,
        "dissipation_reduction": 0.0,
        "repair_gain_boost": 0.0,
        "phase_correction": 0.0,
        "late_support": 0.0,
        "noise_damping": 0.0,
    }

    causes = set(diag["causes"])

    if "weak_reentry" in causes:
        params["reentry_boost"] += cfg["policy"]["reentry_boost"]

    if "excessive_recovery_edges" in causes:
        params["edge_penalty_reduction"] += cfg["policy"]["edge_penalty_reduction"]

    if "dissipation_dominance" in causes:
        params["dissipation_reduction"] += cfg["policy"]["dissipation_reduction"]
        params["repair_gain_boost"] += cfg["policy"]["repair_gain_boost"]

    if "negative_coherence_drift" in causes:
        params["phase_correction"] += cfg["policy"]["phase_correction"]

    if "late_cycle_degradation" in causes:
        params["late_support"] += cfg["policy"]["late_support"]

    if "noise_sensitive" in causes:
        params["noise_damping"] += cfg["policy"]["noise_damping"]

    return params

def simulate_repair(diag, policy, cfg, seed):
    rng = random.Random(seed)

    cycles = cfg["cycles"]
    C = clamp(
        diag["reentry_norm"]
        + policy["reentry_boost"]
        - max(0.0, diag["new_edge_penalty"] - policy["edge_penalty_reduction"])
    )

    base_d = cfg["dissipation_rate"] * (1.0 - policy["dissipation_reduction"])
    repair_gain = cfg["recovery_gain"] + policy["repair_gain_boost"]
    noise_level = cfg["noise"] * (1.0 - policy["noise_damping"])

    series = []
    collapsed = False
    collapse_at = None

    for t in range(cycles):
        D_t = base_d * (1.0 + 0.015*t)
        noise = rng.uniform(-noise_level, noise_level)
        repair = repair_gain * max(0.0, 1.0 - C)

        phase_term = policy["phase_correction"] * max(0.0, 0.75 - C)
        late_term = policy["late_support"] if t > cycles * 0.65 else 0.0

        C = clamp(C + repair + phase_term + late_term - D_t + noise)

        series.append({
            "t": t,
            "C": C,
            "D_t": D_t,
            "repair": repair,
            "phase_term": phase_term,
            "late_term": late_term,
            "noise": noise
        })

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

    mean_C = sum(x["C"] for x in series)/len(series)
    var_C = sum((x["C"]-mean_C)**2 for x in series)/len(series)
    S_time = mean_C - var_C

    if collapsed:
        label = "repair_failed"
    elif S_time >= cfg["thresholds"]["stable_S_time"] and mean_C >= cfg["thresholds"]["stable_mean_C"]:
        label = "repair_stable"
    elif S_time >= cfg["thresholds"]["metastable_S_time"]:
        label = "repair_metastable"
    else:
        label = "repair_weak"

    return {
        "mean_C": mean_C,
        "var_C": var_C,
        "S_time": S_time,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "label": label,
        "series": series
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="results/failure_diagnostics_all.json")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    diagnostics = json.load(open(args.input, "r", encoding="utf-8"))

    rows = []
    for idx, diag in enumerate(diagnostics):
        policy = apply_policy(diag, cfg)
        repaired = simulate_repair(diag, policy, cfg, cfg["seed"] + idx*100)
        improved = repaired["S_time"] - diag["S_time"]
        rows.append({
            "trial_index": diag["trial_index"],
            "before_label": diag["original_label"],
            "before_S_time": diag["S_time"],
            "before_mean_C": diag["mean_C"],
            "causes": diag["causes"],
            "policy": policy,
            "after_label": repaired["label"],
            "after_S_time": repaired["S_time"],
            "after_mean_C": repaired["mean_C"],
            "improvement_S_time": improved,
            "collapsed_after_repair": repaired["collapsed"],
            "collapse_at": repaired["collapse_at"],
            "series": repaired["series"]
        })

    stable = [r for r in rows if r["after_label"] == "repair_stable"]
    meta = [r for r in rows if r["after_label"] == "repair_metastable"]
    weak = [r for r in rows if r["after_label"] == "repair_weak"]
    failed = [r for r in rows if r["after_label"] == "repair_failed"]

    improved_count = sum(1 for r in rows if r["improvement_S_time"] > 0)
    mean_improvement = sum(r["improvement_S_time"] for r in rows)/len(rows)

    summary = {
        "trials": len(rows),
        "repair_stable": len(stable),
        "repair_metastable": len(meta),
        "repair_weak": len(weak),
        "repair_failed": len(failed),
        "improved_count": improved_count,
        "mean_improvement_S_time": mean_improvement,
        "label": "adaptive_repair_success" if len(stable)+len(meta) >= len(rows)*0.70 and failed == [] else ("partial_repair_success" if improved_count >= len(rows)*0.50 else "repair_insufficient"),
        "top_improvements": sorted(rows, key=lambda x: x["improvement_S_time"], reverse=True)[:10],
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"adaptive_repair_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"adaptive_repair_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({k: summary[k] for k in ["trials","repair_stable","repair_metastable","repair_weak","repair_failed","improved_count","mean_improvement_S_time","label"]}, indent=2))

if __name__ == "__main__":
    main()
