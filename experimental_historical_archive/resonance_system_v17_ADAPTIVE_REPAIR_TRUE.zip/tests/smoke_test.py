#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v17_adaptive_repair.py","results/adaptive_repair_summary.json","results/adaptive_repair_trials.json","docs/README.md"]:
    fp = Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s = json.load(open("results/adaptive_repair_summary.json","r",encoding="utf-8"))
assert "mean_improvement_S_time" in s and "all_trials" in s
print("SMOKE_OK")
