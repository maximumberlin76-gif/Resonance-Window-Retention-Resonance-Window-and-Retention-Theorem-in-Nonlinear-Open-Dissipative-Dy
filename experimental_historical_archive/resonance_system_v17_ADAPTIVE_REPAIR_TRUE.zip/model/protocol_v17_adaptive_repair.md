# v17 Adaptive Repair Protocol

1. Load v16 failure diagnostics.
2. Read cause labels for each trial.
3. Map causes to repair policies.
4. Re-run temporal simulation with repaired parameters.
5. Compare S_time before and after.
6. Classify repair result:
   - repair_stable
   - repair_metastable
   - repair_weak
   - repair_failed
7. Summarize improvement.
