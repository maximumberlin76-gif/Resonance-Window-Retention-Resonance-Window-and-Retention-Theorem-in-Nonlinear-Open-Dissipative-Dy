# v17 Repair Metrics

improvement_S_time = after_S_time - before_S_time

C0 =
reentry_norm
+ reentry_boost
- max(0, new_edge_penalty - edge_penalty_reduction)

D_repaired =
D_base * (1 - dissipation_reduction)

repair_gain_repaired =
repair_gain + repair_gain_boost
