# Resonance System v17 TRUE ADAPTIVE REPAIR

## Purpose

v16 identified why temporal regimes fail.  
v17 applies targeted repair policies to those specific failure causes.

The key shift:

```text
diagnosis -> cause-specific correction -> temporal retest
```

## Repair Policies

- weak_reentry:
  increase initial reentry strength

- excessive_recovery_edges:
  reduce effective penalty from weak recovered links

- dissipation_dominance:
  lower dissipation and increase repair gain

- negative_coherence_drift:
  add phase-correction support

- late_cycle_degradation:
  add late-cycle support

- noise_sensitive:
  apply damping against noise

## Run

```bash
python scripts/generate_failure_diagnostics_seed.py
python scripts/engine_v17_adaptive_repair.py --input results/failure_diagnostics_all.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/adaptive_repair_summary.json
results/adaptive_repair_trials.json
validation/triple_validation_summary.json
```

## Interpretation

- adaptive_repair_success:
  repair policies convert most trials into stable/metastable regimes.

- partial_repair_success:
  some improvement, but not enough for robust recovery.

- repair_insufficient:
  policies fail to reverse collapse patterns.

## Limitation

Computational sandbox only.
