#!/usr/bin/env python3
"""
Resonance System v20 TRUE SMOOTH PREDICTIVE CONTROL

v19 predicted the moving resonance window, but overshoot remained high.
v20 adds:
- exponential smoothing of predicted center
- adaptive lead reduction under overshoot
- jerk limit for f0 correction
- overshoot penalty tracking
- smooth lock score

Computational sandbox only.
"""
import argparse,json,random,math
from pathlib import Path

def clamp(x,lo=0,hi=1): return max(lo,min(hi,x))
def mean(xs): return sum(xs)/max(1,len(xs))

def simulate(trial,cfg,seed):
    rng=random.Random(seed); cycles=cfg["cycles"]
    fc=trial.get("f_center",rng.choice([76.4,150.0,458.4])); f0=fc
    C=clamp(trial["reentry_norm"]-trial["new_edge_penalty"])
    hist=[fc]; pred_smooth=fc; prev_delta=0.0
    lock_loss=0; overs=0; jerk_events=0; collapsed=False; collapse_at=None; series=[]
    lead=cfg["predictor"]["lead"]

    for t in range(cycles):
        fc += cfg["floating"]["drift_rate"]*math.sin(2*math.pi*t/cfg["floating"]["period"]) + rng.uniform(-cfg["floating"]["jitter"],cfg["floating"]["jitter"])
        hist.append(fc)
        h=hist[-cfg["predictor"]["history"]:]
        drift=(h[-1]-h[0])/max(1,len(h)-1) if len(h)>1 else 0.0

        raw_pred=fc+lead*drift
        alpha=cfg["smooth"]["alpha"]
        pred_smooth=alpha*raw_pred+(1-alpha)*pred_smooth

        delta=pred_smooth-f0
        max_delta=abs(fc)*cfg["smooth"]["max_delta_ratio"]
        if abs(delta)>max_delta:
            pred_smooth=f0+max_delta*(1 if delta>0 else -1); overs+=1
            lead=max(cfg["predictor"]["min_lead"], lead*cfg["smooth"]["lead_decay"])
        else:
            lead=min(cfg["predictor"]["max_lead"], lead+cfg["smooth"]["lead_recover"])

        delta=pred_smooth-f0
        jerk=delta-prev_delta
        max_jerk=abs(fc)*cfg["smooth"]["max_jerk_ratio"]
        if abs(jerk)>max_jerk:
            delta=prev_delta+max_jerk*(1 if jerk>0 else -1); jerk_events+=1
        prev_delta=delta

        f0 += cfg["floating"]["follow_gain"]*delta
        f1=2*f0; f2=0.5*f0

        terr=abs(fc-f0)/max(1,abs(fc))
        perr=abs(pred_smooth-fc)/max(1,abs(fc))
        corridor=cfg["floating"]["base_corridor"]+min(cfg["floating"]["max_extra_corridor"],abs(drift)/max(1,abs(fc))*cfg["floating"]["corridor_gain"])
        inside=terr<=corridor
        if not inside: lock_loss+=1

        D=cfg["dissipation_rate"]*(1+0.010*t); noise=rng.uniform(-cfg["noise"],cfg["noise"])
        smooth_support=cfg["smooth"]["smooth_support"]*(1-min(1,abs(jerk)/max(1e-9,max_jerk)))
        ps=cfg["predictor"]["predictive_support"]*(1-perr)
        ls=cfg["floating"]["lock_support"]*(1-terr) if inside else -cfg["floating"]["lock_penalty"]
        repair=cfg["recovery_gain"]*max(0,1-C)
        C=clamp(C+repair+ls+ps+smooth_support-D+noise)
        if C<cfg["collapse_threshold"] and not collapsed:
            collapsed=True; collapse_at=t

        series.append({"t":t,"window_center":fc,"raw_predicted_center":raw_pred,"smoothed_predicted_center":pred_smooth,"lead":lead,"f0":f0,"f1":f1,"f2":f2,"tracking_error":terr,"predictive_error":perr,"local_corridor":corridor,"in_corridor":inside,"overshoot":abs(delta)>max_delta,"jerk_limited":abs(jerk)>max_jerk,"C":C,"D_t":D,"repair":repair,"lock_support":ls,"predictive_support":ps,"smooth_support":smooth_support,"noise":noise})

    Cs=[x["C"] for x in series]; m=mean(Cs); var=mean([(x-m)**2 for x in Cs])
    mterr=mean([x["tracking_error"] for x in series]); mperr=mean([x["predictive_error"] for x in series])
    ll=lock_loss/cycles; orate=overs/cycles; jrate=jerk_events/cycles
    S=m-var-0.35*ll-0.45*mterr-0.30*mperr-0.25*orate-0.15*jrate
    if collapsed: label="smooth_collapse"
    elif S>=cfg["thresholds"]["smooth_stable"] and ll<=cfg["thresholds"]["max_lock_loss"] and orate<=cfg["thresholds"]["max_overshoot"]: label="smooth_stable"
    elif S>=cfg["thresholds"]["smooth_metastable"]: label="smooth_metastable"
    else: label="smooth_weak"
    return {"mean_C":m,"var_C":var,"mean_tracking_error":mterr,"mean_predictive_error":mperr,"lock_loss_rate":ll,"overshoot_rate":orate,"jerk_limit_rate":jrate,"S_smooth":S,"collapsed":collapsed,"collapse_at":collapse_at,"label":label,"series":series}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--input",default="results/predictive_drive_trials.json"); ap.add_argument("--outdir",default="results"); args=ap.parse_args()
    cfg=json.load(open("configs/config.json","r",encoding="utf-8")); trials=json.load(open(args.input,"r",encoding="utf-8"))
    rows=[]
    for i,t in enumerate(trials):
        base={"trial_index":t.get("trial_index",i),"previous_label":t.get("label","predictive_unknown"),"reentry_norm":t.get("reentry_norm",0.80),"new_edge_penalty":t.get("new_edge_penalty",0.10),"f_center":[76.4,150.0,458.4][i%3]}
        rows.append({**base,**simulate(base,cfg,cfg["seed"]+i*100)})
    stable=[r for r in rows if r["label"]=="smooth_stable"]; meta=[r for r in rows if r["label"]=="smooth_metastable"]; weak=[r for r in rows if r["label"]=="smooth_weak"]; col=[r for r in rows if r["label"]=="smooth_collapse"]
    summary={"trials":len(rows),"smooth_stable":len(stable),"smooth_metastable":len(meta),"smooth_weak":len(weak),"smooth_collapse":len(col),"mean_S_smooth":mean([r["S_smooth"] for r in rows]),"mean_tracking_error":mean([r["mean_tracking_error"] for r in rows]),"mean_predictive_error":mean([r["mean_predictive_error"] for r in rows]),"mean_lock_loss_rate":mean([r["lock_loss_rate"] for r in rows]),"mean_overshoot_rate":mean([r["overshoot_rate"] for r in rows]),"mean_jerk_limit_rate":mean([r["jerk_limit_rate"] for r in rows]),"label":"smooth_predictive_success" if len(stable)+len(meta)>=len(rows)*0.75 and len(col)==0 else "smooth_predictive_limited","top_trials":sorted(rows,key=lambda x:x["S_smooth"],reverse=True)[:10],"all_trials":rows}
    out=Path(args.outdir); out.mkdir(exist_ok=True)
    json.dump(summary,open(out/"smooth_predictive_summary.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    json.dump(rows,open(out/"smooth_predictive_trials.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    print(json.dumps({k:summary[k] for k in ["trials","smooth_stable","smooth_metastable","smooth_weak","smooth_collapse","mean_S_smooth","mean_overshoot_rate","mean_jerk_limit_rate","label"]},indent=2))
if __name__=="__main__": main()
