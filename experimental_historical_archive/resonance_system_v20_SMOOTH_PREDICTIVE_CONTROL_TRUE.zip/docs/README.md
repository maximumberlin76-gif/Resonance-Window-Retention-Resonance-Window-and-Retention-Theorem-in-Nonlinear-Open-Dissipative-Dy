# Resonance System v20 TRUE SMOOTH PREDICTIVE CONTROL

## Purpose

v19 improved floating-window tracking by predicting window drift, but overshoot remained high.  
v20 reduces overshoot while preserving lock.

## Adds

- exponential smoothing of predicted center
- adaptive lead reduction after overshoot
- jerk limit on f0 correction
- smooth support term
- overshoot-aware stability score

## Run

```bash
python scripts/generate_predictive_seed.py
python scripts/engine_v20_smooth_predictive_control.py --input results/predictive_drive_trials.json --outdir results
python tests/smoke_test.py
```

## Outputs

- results/smooth_predictive_summary.json
- results/smooth_predictive_trials.json
- validation/triple_validation_summary.json

## Limitation

Computational sandbox only.
