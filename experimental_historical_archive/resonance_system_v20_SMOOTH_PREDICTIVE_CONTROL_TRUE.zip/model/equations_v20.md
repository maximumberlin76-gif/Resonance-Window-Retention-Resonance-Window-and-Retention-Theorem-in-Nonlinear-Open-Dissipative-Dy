S_smooth = mean_C - var_C - 0.35*lock_loss - 0.45*tracking_error - 0.30*predictive_error - 0.25*overshoot - 0.15*jerk_rate
