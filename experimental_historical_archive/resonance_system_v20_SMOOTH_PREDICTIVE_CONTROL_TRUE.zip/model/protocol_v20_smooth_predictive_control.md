v20 protocol: smooth prediction -> adaptive lead -> overshoot cap -> jerk limit -> smooth lock classification.
