#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v20_smooth_predictive_control.py","results/smooth_predictive_summary.json","results/smooth_predictive_trials.json","docs/README.md"]:
    fp=Path(p); assert fp.exists() and fp.stat().st_size>100,p
s=json.load(open("results/smooth_predictive_summary.json","r",encoding="utf-8")); assert "mean_overshoot_rate" in s and "all_trials" in s
print("SMOKE_OK")
