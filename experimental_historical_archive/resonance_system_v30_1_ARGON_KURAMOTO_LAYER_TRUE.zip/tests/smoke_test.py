#!/usr/bin/env python3
from pathlib import Path
import json
required = [
    "scripts/engine_v30_1_argon_kuramoto.py",
    "results/argon_kuramoto_summary.json",
    "results/argon_kuramoto_trials.json",
    "docs/README.md",
    "model/equations_v30_1.md",
    "journal/session_journal_v30_1.md"
]
for item in required:
    p = Path(item)
    assert p.exists(), f"missing: {item}"
    assert p.stat().st_size > 100, f"too small: {item}"
s = json.load(open("results/argon_kuramoto_summary.json", "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "scenario_summary" in s
print("SMOKE_OK")
