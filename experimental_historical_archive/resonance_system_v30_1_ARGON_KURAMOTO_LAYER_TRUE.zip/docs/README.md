# v30.1 — Argon Plasma Kuramoto Coupling Layer

## Abstract

This module adds a Kuramoto phase-coherence layer to the argon plasma resonance-window framework.

The system is treated strictly as a nonlinear dissipative open dynamic system.

The purpose is to connect phase synchronization:

```text
R(t)
```

to structural coherence:

```text
C(t)
```

and then to useful coherent work:

```text
W_coh(τ)
```

This is a computational sandbox, not a laboratory measurement.

## Kuramoto Layer

The phase dynamics are modeled as:

```text
dφ_i/dt =
ω_i
+ (K/N) Σ sin(φ_j - φ_i)
+ F_ext sin(ω_ext t - φ_i)
+ η_i(t)
```

The order parameter is:

```text
R = |(1/N) Σ exp(i φ_j)|
```

Interpretation:

```text
R → 1 : phase lock
R → 0 : incoherence
```

## Argon Anchors

Old sandbox values included:

- electron density: n_e = 10^17 m^-3
- electron temperature: T_e = 10,000 K
- ion temperature: T_i = 1,000 K
- plasma-frequency proxy: ~2.85 GHz
- ion-acoustic anchor: ~5.76 MHz

## Scenarios

v30.1 tests:

- baseline
- resonance
- off_resonance
- pulsed
- noisy_drift
- retention_off

## Core Chain

```text
Kuramoto R(t)
→ phase coherence
→ C(t)
→ W_coh(τ)
→ resonance window Ω(t)
→ stabilization / synthesis candidate
```

## Important Caution

R > 0.7 is treated here as a phase-lock criterion in the sandbox model.

It is not by itself laboratory proof of plasma stabilization.

## Run

```bash
python scripts/engine_v30_1_argon_kuramoto.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/argon_kuramoto_summary.json
results/argon_kuramoto_trials.json
journal/session_journal_v30_1.md
```

## Next Step

v30.2 — combine spectrum scan from v30 with Kuramoto layer from v30.1.
