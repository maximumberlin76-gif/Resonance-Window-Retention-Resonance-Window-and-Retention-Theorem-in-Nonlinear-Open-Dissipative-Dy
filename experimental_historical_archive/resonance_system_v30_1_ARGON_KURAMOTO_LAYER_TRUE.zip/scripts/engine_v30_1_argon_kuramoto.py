#!/usr/bin/env python3
"""
v30.1 TRUE ARGON PLASMA KURAMOTO COUPLING LAYER

Purpose:
Add a Kuramoto phase-coherence layer to the argon plasma resonance-window model.

System class:
nonlinear dissipative open dynamic systems

Important:
This is a computational sandbox, not a laboratory result.

Added complexity:
- baseline / resonance / off_resonance / pulsed / noisy_drift / retention_off
- ion-acoustic anchor frequency
- plasma-frequency proxy
- frequency detuning
- stochastic phase noise
- drive switch-off retention
- R(t) -> C(t) -> W_coh(t)
- resonance-window classification

Kuramoto equation:

dφ_i/dt =
ω_i
+ (K/N) Σ sin(φ_j - φ_i)
+ F_ext sin(ω_ext t - φ_i)
+ η_i(t)

Order parameter:

R = |(1/N) Σ exp(i φ_j)|
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def order_parameter(phases):
    re = sum(math.cos(p) for p in phases) / len(phases)
    im = sum(math.sin(p) for p in phases) / len(phases)
    return math.sqrt(re*re + im*im)

def circular_spread(phases):
    R = order_parameter(phases)
    return 1.0 - R

def scenario_params(name, cfg):
    base = dict(cfg["kuramoto"]["base"])
    if name == "baseline":
        base.update({"F_ext": 0.0, "detune": 0.0, "pulse": False, "noise_mult": 1.0, "drive_off_at": None})
    elif name == "resonance":
        base.update({"F_ext": 0.20, "detune": 0.0, "pulse": False, "noise_mult": 1.0, "drive_off_at": None})
    elif name == "off_resonance":
        base.update({"F_ext": 0.20, "detune": 0.18, "pulse": False, "noise_mult": 1.0, "drive_off_at": None})
    elif name == "pulsed":
        base.update({"F_ext": 0.24, "detune": 0.0, "pulse": True, "duty": 0.40, "noise_mult": 1.0, "drive_off_at": None})
    elif name == "noisy_drift":
        base.update({"F_ext": 0.22, "detune": 0.08, "pulse": True, "duty": 0.45, "noise_mult": 2.2, "drift_mult": 2.0, "drive_off_at": None})
    elif name == "retention_off":
        base.update({"F_ext": 0.24, "detune": 0.0, "pulse": True, "duty": 0.50, "noise_mult": 1.0, "drive_off_at": int(cfg["simulation"]["steps"] * 0.55)})
    else:
        raise ValueError(name)
    return base

def simulate_scenario(seed, scenario, cfg):
    rng = random.Random(seed)
    N = cfg["kuramoto"]["N"]
    steps = cfg["simulation"]["steps"]
    dt = cfg["simulation"]["dt"]
    period_steps = cfg["simulation"]["period_steps"]

    p = scenario_params(scenario, cfg)

    # normalized frequency space around ion-acoustic anchor
    omega0 = cfg["argon"]["ion_acoustic_freq_mhz"]
    omega_ext = omega0 * (1.0 + p.get("detune", 0.0))

    phases = [rng.uniform(-math.pi, math.pi) for _ in range(N)]
    natural = [rng.gauss(omega0, cfg["kuramoto"]["omega_sigma_mhz"]) for _ in range(N)]

    C = rng.uniform(0.35, 0.50)
    W_coh = 0.0
    theta = 0.0
    stable_periods = 0
    period_work = 0.0
    period_theta = 0.0
    convergence_time = None
    R_max = 0.0
    R_post_off = None

    series = []

    for t in range(steps):
        time = t * dt
        drive_active = True
        if p.get("drive_off_at") is not None and t >= p["drive_off_at"]:
            drive_active = False

        pulse_gate = 1.0
        if p.get("pulse", False):
            pulse_gate = 1.0 if (t % period_steps) < int(period_steps * p.get("duty", 0.5)) else 0.0

        F = p["F_ext"] * pulse_gate * (1.0 if drive_active else 0.0)

        R_now = order_parameter(phases)
        psi = math.atan2(sum(math.sin(x) for x in phases), sum(math.cos(x) for x in phases))

        new_phases = []
        for i, phi in enumerate(phases):
            # mean-field Kuramoto coupling
            coupling = p["K"] * R_now * math.sin(psi - phi)
            external = F * math.sin(2 * math.pi * omega_ext * time - phi)
            noise = rng.gauss(0.0, cfg["kuramoto"]["noise"] * p.get("noise_mult", 1.0))
            drift = cfg["kuramoto"]["omega_drift"] * p.get("drift_mult", 1.0) * math.sin(2 * math.pi * t / max(1, steps))
            dphi = (natural[i] + drift + coupling + external) * dt + noise
            new_phases.append((phi + dphi + math.pi) % (2 * math.pi) - math.pi)

        phases = new_phases
        R = order_parameter(phases)
        R_max = max(R_max, R)

        if convergence_time is None and R >= cfg["thresholds"]["R_lock"]:
            convergence_time = time

        if p.get("drive_off_at") is not None and t == p["drive_off_at"]:
            R_post_off = R

        # Map phase order to coherence C.
        phase_coherence = R
        destructive_pressure = cfg["plasma_balance"]["P_base"] + cfg["plasma_balance"]["P_detune"] * abs(p.get("detune", 0.0))
        dissipation = cfg["plasma_balance"]["D_base"] + cfg["plasma_balance"]["D_noise"] * p.get("noise_mult", 1.0)

        useful_work_step = max(0.0, R - cfg["thresholds"]["R_work_floor"]) * F * cfg["plasma_balance"]["work_gain"]
        W_coh += useful_work_step

        C = clamp(
            C
            + cfg["plasma_balance"]["C_gain"] * (phase_coherence - C)
            + useful_work_step
            - destructive_pressure * 0.010
            - dissipation * 0.010
        )

        delta = C - destructive_pressure - dissipation
        if delta > 0:
            theta += delta
            period_theta += delta
            period_work += useful_work_step

        if (t + 1) % period_steps == 0:
            if period_theta >= cfg["thresholds"]["period_theta_min"] and period_work >= cfg["thresholds"]["period_work_min"]:
                stable_periods += 1
            period_theta = 0.0
            period_work = 0.0

        series.append({
            "step": t,
            "time": time,
            "scenario": scenario,
            "R": R,
            "C": C,
            "W_coh": W_coh,
            "theta": theta,
            "omega_ext_mhz": omega_ext,
            "ion_acoustic_anchor_mhz": omega0,
            "plasma_frequency_proxy_ghz": cfg["argon"]["plasma_frequency_proxy_ghz"],
            "F_ext_effective": F,
            "drive_active": drive_active,
            "phase_spread": circular_spread(phases),
            "P": destructive_pressure,
            "D": dissipation,
            "delta": delta
        })

    R_final = series[-1]["R"]
    C_final = series[-1]["C"]

    if scenario == "retention_off":
        tail = series[int(steps*0.75):]
        retention_R = mean([x["R"] for x in tail])
    else:
        retention_R = None

    if R_final >= cfg["thresholds"]["R_lock"] and stable_periods >= cfg["thresholds"]["synthesis_min_periods"]:
        outcome = "kuramoto_resonance_window_candidate"
    elif R_final >= cfg["thresholds"]["R_lock"]:
        outcome = "phase_locked_but_incomplete_accumulation"
    elif R_max >= cfg["thresholds"]["R_lock"] and R_final < cfg["thresholds"]["R_lock"]:
        outcome = "transient_lock_no_retention"
    else:
        outcome = "no_phase_lock"

    return {
        "seed": seed,
        "scenario": scenario,
        "R_final": R_final,
        "R_max": R_max,
        "C_final": C_final,
        "W_coh": W_coh,
        "theta": theta,
        "stable_periods": stable_periods,
        "convergence_time": convergence_time,
        "R_post_off": R_post_off,
        "retention_R_tail": retention_R,
        "outcome": outcome,
        "series": series
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    scenarios = cfg["scenarios"]

    rows = []
    for sidx, scenario in enumerate(scenarios):
        for i in range(cfg["trials_per_scenario"]):
            rows.append(simulate_scenario(cfg["seed"] + sidx * 10000 + i * 100, scenario, cfg))

    outcomes = {}
    scenario_summary = {}
    for r in rows:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1
        scenario_summary.setdefault(r["scenario"], []).append(r)

    compact_scenarios = {}
    for scenario, items in scenario_summary.items():
        compact_scenarios[scenario] = {
            "count": len(items),
            "mean_R_final": mean([x["R_final"] for x in items]),
            "mean_R_max": mean([x["R_max"] for x in items]),
            "mean_C_final": mean([x["C_final"] for x in items]),
            "mean_W_coh": mean([x["W_coh"] for x in items]),
            "mean_stable_periods": mean([x["stable_periods"] for x in items]),
            "mean_convergence_time": mean([x["convergence_time"] for x in items if x["convergence_time"] is not None]) if any(x["convergence_time"] is not None for x in items) else None,
            "mean_retention_R_tail": mean([x["retention_R_tail"] for x in items if x["retention_R_tail"] is not None]) if any(x["retention_R_tail"] is not None for x in items) else None,
            "outcomes": {k: sum(1 for x in items if x["outcome"] == k) for k in sorted(set(x["outcome"] for x in items))}
        }

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "argon_reference": {
            "electron_density_m3_old_experiment": 1e17,
            "electron_temperature_K_old_experiment": 10000,
            "ion_temperature_K_old_experiment": 1000,
            "plasma_frequency_proxy_ghz": cfg["argon"]["plasma_frequency_proxy_ghz"],
            "ion_acoustic_anchor_mhz": cfg["argon"]["ion_acoustic_freq_mhz"],
            "note": "Kuramoto phase model, not laboratory measurement."
        },
        "trials": len(rows),
        "outcomes": outcomes,
        "scenario_summary": compact_scenarios,
        "main_conclusion": "kuramoto_phase_coherence_can_feed_resonance_window_metrics_via_R_to_C_to_Wcoh",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"argon_kuramoto_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"argon_kuramoto_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "outcomes": outcomes,
        "scenario_summary": compact_scenarios,
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
