# Session Journal — v30.1

## Step

v30.1 — Argon Plasma Kuramoto Coupling Layer.

## Added

- Kuramoto phase model
- argon ion-acoustic anchor
- plasma-frequency proxy
- baseline/resonance/off-resonance/pulsed/noisy-drift/retention-off scenarios
- R(t) -> C(t) -> W_coh(τ)
- phase-lock criterion R > 0.7

## User-provided old sandbox data

Old experiment suggested:
- baseline convergence ~3.35
- resonance convergence ~1.42
- R_final improvement from 0.980 to 0.997
- ion-acoustic frequency ~5.76 MHz
- plasma-frequency proxy ~2.85 GHz

## Caution

This module treats those as sandbox anchors, not laboratory confirmation.

## Next Step

v30.2 — combine frequency spectrum scan and Kuramoto phase-layer.
