# v11 Equations

edge_score =
0.4*harmonic_score
+ 0.25*phase_compat
+ 0.25*retention_strength
+ 0.10*distance_penalty

global_coherence = mean(edge_score)

backbone = edges with score >= 0.68
