# v11 Network Protocol

1. Load invariant modes from v10.
2. Compute pairwise compatibility:
   - harmonic relation
   - phase compatibility
   - retention strength
   - frequency distance penalty
3. Build edges above threshold.
4. Extract backbone.
5. Run cascade stress by removing high-degree nodes.
6. Classify:
   - network_coherent
   - network_fragmented_but_viable
   - network_unstable
