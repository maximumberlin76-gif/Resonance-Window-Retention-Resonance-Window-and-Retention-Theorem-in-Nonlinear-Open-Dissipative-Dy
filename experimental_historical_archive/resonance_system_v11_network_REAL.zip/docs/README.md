# Resonance System v11 NETWORK REAL

v11 builds a network of invariant attractor modes.

Run:
python scripts/generate_v10_seed_modes.py
python scripts/engine_v11_network.py --input results/invariance_results_all.json --outdir results --threshold 0.55

Outputs:
- results/network_graph.json
- results/network_summary.json

Purpose:
single retained mode -> network of compatible attractors -> backbone -> cascade stress.
