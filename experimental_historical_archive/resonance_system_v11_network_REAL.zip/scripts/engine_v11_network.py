
#!/usr/bin/env python3
"""
Resonance System v11 NETWORK REAL

Layer after v10:
- takes invariant modes
- builds network graph of attractor compatibility
- computes edge coherence / phase-distance / frequency relation
- extracts backbone
- performs cascade stress test
- classifies network as coherent / fragmented / unstable

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math
from pathlib import Path
from itertools import combinations
from statistics import mean
import numpy as np

def load_modes(path):
    rows = json.load(open(path, "r", encoding="utf-8"))
    good = [r for r in rows if r["label"] in ("invariant_stable", "invariant_metastable")]
    return good

def freq_distance(a, b):
    pa, pb = a["params"], b["params"]
    da = abs(pa["f0"] - pb["f0"]) + abs(pa["f1"] - pb["f1"]) + abs(pa["f2"] - pb["f2"])
    return da / 3.0

def harmonic_score(a, b, eps=0.08):
    fa = [a["params"]["f0"], a["params"]["f1"], a["params"]["f2"]]
    fb = [b["params"]["f0"], b["params"]["f1"], b["params"]["f2"]]
    hits = 0
    total = 0
    for x in fa:
        for y in fb:
            if x == 0 or y == 0:
                continue
            r = max(x,y) / min(x,y)
            total += 1
            targets = [1,2,3,0.5,1/3,7,1/7]
            if any(abs(r-t)/t <= eps for t in targets):
                hits += 1
    return hits / max(1,total)

def phase_compat(a, b):
    pha = a["params"].get("phi", 0)
    phb = b["params"].get("phi", 0)
    return (1 + math.cos(pha - phb)) / 2

def retention_strength(x):
    checks = x.get("checks", {})
    return float(checks.get("env_mean", 0.0))

def edge_score(a, b):
    h = harmonic_score(a,b)
    ph = phase_compat(a,b)
    r = (retention_strength(a) + retention_strength(b))/2
    d = freq_distance(a,b)
    distance_penalty = 1/(1+d/300)
    return 0.4*h + 0.25*ph + 0.25*r + 0.10*distance_penalty

def build_edges(modes, threshold):
    edges = []
    for i,j in combinations(range(len(modes)),2):
        s = edge_score(modes[i], modes[j])
        if s >= threshold:
            edges.append({"i":i,"j":j,"score":s})
    return edges

def components(n, edges):
    parent=list(range(n))
    def find(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]]
            x=parent[x]
        return x
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb: parent[rb]=ra
    for e in edges:
        union(e["i"],e["j"])
    comps={}
    for i in range(n):
        comps.setdefault(find(i),[]).append(i)
    return list(comps.values())

def cascade_test(modes, edges, removal_fraction=0.2):
    n=len(modes)
    degree=[0]*n
    for e in edges:
        degree[e["i"]]+=1
        degree[e["j"]]+=1
    ranked=sorted(range(n), key=lambda x: degree[x], reverse=True)
    remove=set(ranked[:max(1,int(n*removal_fraction))])
    kept_edges=[e for e in edges if e["i"] not in remove and e["j"] not in remove]
    kept_nodes=[i for i in range(n) if i not in remove]
    comps=components(n, kept_edges)
    comps=[c for c in comps if any(x in kept_nodes for x in c)]
    largest=max((len([x for x in c if x in kept_nodes]) for c in comps), default=0)
    survival=largest / max(1,len(kept_nodes))
    return {"removed_nodes":sorted(remove), "largest_component_fraction":survival, "kept_edges":len(kept_edges)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input", default="results/invariance_results_all.json")
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--threshold", type=float, default=0.55)
    args=ap.parse_args()

    modes=load_modes(args.input)
    edges=build_edges(modes,args.threshold)
    comps=components(len(modes),edges)
    cascade=cascade_test(modes,edges,removal_fraction=0.2)

    degrees=[0]*len(modes)
    for e in edges:
        degrees[e["i"]]+=1
        degrees[e["j"]]+=1

    backbone=[e for e in edges if e["score"]>=max(args.threshold,0.68)]
    global_coherence=mean([e["score"] for e in edges]) if edges else 0

    if global_coherence>=0.65 and cascade["largest_component_fraction"]>=0.65:
        label="network_coherent"
    elif global_coherence>=0.50:
        label="network_fragmented_but_viable"
    else:
        label="network_unstable"

    out=Path(args.outdir); out.mkdir(exist_ok=True)
    graph={"nodes":modes,"edges":edges,"backbone":backbone}
    summary={
        "nodes":len(modes),
        "edges":len(edges),
        "backbone_edges":len(backbone),
        "components":len(comps),
        "component_sizes":sorted([len(c) for c in comps], reverse=True),
        "global_coherence":global_coherence,
        "cascade":cascade,
        "label":label,
        "top_degree_nodes":sorted(
            [{"idx":i,"degree":d,"params":modes[i]["params"],"label":modes[i]["label"]} for i,d in enumerate(degrees)],
            key=lambda x:x["degree"], reverse=True
        )[:10]
    }
    json.dump(graph,open(out/"network_graph.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    json.dump(summary,open(out/"network_summary.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=="__main__":
    main()
