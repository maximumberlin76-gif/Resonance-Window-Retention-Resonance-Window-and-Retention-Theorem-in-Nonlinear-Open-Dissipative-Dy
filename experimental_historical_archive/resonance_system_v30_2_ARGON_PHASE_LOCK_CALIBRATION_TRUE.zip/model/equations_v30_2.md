# v30.2 Equations

dφ_i/dt =
ω_i + K R sin(ψ - φ_i) + F_ext sin(ω_ext t - φ_i) + η_i(t)

R = |(1/N) Σ exp(i φ_j)|

W_coh(τ) =
∫ max(0, R(t) - R_floor) · F_ext(t) dt

candidate if:
R_final >= R_lock and stable_periods >= synthesis_min_periods
