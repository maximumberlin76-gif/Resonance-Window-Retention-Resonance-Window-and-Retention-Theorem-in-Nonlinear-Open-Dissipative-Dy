# Session Journal — v30.2

## Step

Argon phase-lock calibration.

## Reason

v30.1 was under-coupled: all runs stayed below R > 0.7.

## Added

- stronger K scan
- stronger but bounded F_ext scan
- reduced omega dispersion
- ion-acoustic anchor vs 27.12 MHz candidate
- off-drive retention marker

## Core Principle

Phase lock requires sufficient coupling and reduced dispersion. Force alone is not enough.
