#!/usr/bin/env python3
from pathlib import Path
import json
for item in ["scripts/engine_v30_2_argon_phase_lock_calibration.py","results/argon_phase_lock_calibration_summary.json","results/argon_phase_lock_calibration_trials.json","docs/README.md","model/equations_v30_2.md","journal/session_journal_v30_2.md"]:
    p=Path(item)
    assert p.exists(), f"missing {item}"
    assert p.stat().st_size > 100, f"too small {item}"
s=json.load(open("results/argon_phase_lock_calibration_summary.json","r",encoding="utf-8"))
assert s["system_class"]=="nonlinear dissipative open dynamic systems"
print("SMOKE_OK")
