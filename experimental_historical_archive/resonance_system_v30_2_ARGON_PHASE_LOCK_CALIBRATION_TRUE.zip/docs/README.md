# v30.2 — Argon Phase-Lock Calibration

## Abstract

v30.1 showed that the Argon Kuramoto layer did not reach phase lock.  
v30.2 calibrates the phase-lock conditions for argon plasma modeled as a nonlinear dissipative open dynamic system.

The calibration scans:

- coupling K,
- external forcing F_ext,
- natural frequency dispersion omega_sigma,
- ion-acoustic anchor 5.76 MHz,
- spectral candidate 27.12 MHz from v30.

This is a computational sandbox, not laboratory evidence.

## Core Criterion

```text
R = |(1/N) Σ exp(i φ_j)|
```

Phase lock candidate:

```text
R >= 0.7
```

Resonance-window candidate:

```text
R_final >= 0.7
and
stable_periods >= synthesis_min_periods
```

## System Class

```text
nonlinear dissipative open dynamic systems
```

## Run

```bash
python scripts/engine_v30_2_argon_phase_lock_calibration.py --outdir results
python tests/smoke_test.py
```

## Next Step

v30.3 — combine best phase-lock profile with v30 spectral window and test off-drive retention more aggressively.
