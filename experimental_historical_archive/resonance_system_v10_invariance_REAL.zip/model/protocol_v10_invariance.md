# v10 Invariance Protocol

v9 = survival.
v10 = invariance.

A mode is invariant_stable only if it survives:
1. cross-environment test
2. long OFF
3. phase inversion
4. f1/f2 swap
5. energy hysteresis memory

This reduces model comfort and tests structural stability.
