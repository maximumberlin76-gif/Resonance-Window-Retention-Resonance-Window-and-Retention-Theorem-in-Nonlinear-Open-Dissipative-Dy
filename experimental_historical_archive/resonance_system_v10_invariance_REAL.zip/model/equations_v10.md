# v10 Metrics

env_mean = mean(R_off across environments)
env_std = std(R_off across environments)

score = env_mean - env_std + 0.1*passed_checks + 0.1*long_R_off + 0.05*R_memory

Classification:
5/5 checks -> invariant_stable
3-4/5 checks -> invariant_metastable
<3 -> reject
