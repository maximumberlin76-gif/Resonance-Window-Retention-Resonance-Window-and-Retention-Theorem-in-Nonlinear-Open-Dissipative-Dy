# Resonance System v10 INVARIANCE REAL

v10 tests whether v9-stable modes are invariant across:
- different N and K environments
- long-time retention
- phase inversion
- f1/f2 swap
- energy hysteresis

Run:
python scripts/engine_v10_invariance.py --config configs/config.json --outdir results
python scripts/build_invariance_attractor_map.py
