
#!/usr/bin/env python3
import json,csv
from pathlib import Path
rows=json.load(open("results/invariance_results_all.json","r",encoding="utf-8"))
groups={}
for r in rows:
    key=tuple(r["bucket"])
    groups.setdefault(key,[]).append(r)
out=[]
for key,items in groups.items():
    labels=[x["label"] for x in items]
    kind="invariant_stable_attractor" if "invariant_stable" in labels else ("invariant_metastable_cloud" if "invariant_metastable" in labels else "noise_or_false_peak")
    out.append({"bucket":key,"count":len(items),"stable":labels.count("invariant_stable"),"metastable":labels.count("invariant_metastable"),"reject":labels.count("reject"),"mean_score":sum(x["score"] for x in items)/len(items),"kind":kind,"samples":items[:3]})
out.sort(key=lambda x:(x["kind"]!="invariant_stable_attractor",x["kind"]!="invariant_metastable_cloud",-x["mean_score"]))
Path("results").mkdir(exist_ok=True); Path("logs").mkdir(exist_ok=True)
json.dump(out,open("results/invariance_attractor_map.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
summary={"total_buckets":len(out),"invariant_stable_attractors":sum(1 for x in out if x["kind"]=="invariant_stable_attractor"),"invariant_metastable_clouds":sum(1 for x in out if x["kind"]=="invariant_metastable_cloud"),"noise_or_false_peak":sum(1 for x in out if x["kind"]=="noise_or_false_peak"),"top_10":out[:10]}
json.dump(summary,open("results/invariance_attractor_summary.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
with open("logs/invariance_attractor_map.csv","w",newline="",encoding="utf-8") as f:
    w=csv.writer(f); w.writerow(["bucket","kind","count","mean_score"])
    for a in out: w.writerow([a["bucket"],a["kind"],a["count"],a["mean_score"]])
print(json.dumps(summary,indent=2,ensure_ascii=False))
