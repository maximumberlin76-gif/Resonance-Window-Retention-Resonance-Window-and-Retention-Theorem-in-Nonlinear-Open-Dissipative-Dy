
#!/usr/bin/env python3
"""
Resonance System v10 INVARIANCE REAL

Built on v9 stress logic, adds:
- cross-environment test (N, K)
- long-time retention
- inversion test (phi sign, f1/f2 swap)
- energy hysteresis test (A high -> A low)
- attractor bucket consistency

This is a computational sandbox/protocol engine, not physical validation.
"""

from __future__ import annotations
import argparse, json, math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Any, List
import numpy as np

@dataclass
class ModeParams:
    f0: float
    f1: float
    f2: float
    A: float
    phi: float
    duty: float
    noise: float

class System:
    def __init__(self, n=24, K=0.7, seed=1, drift=0.06):
        self.n=n; self.K=K; self.rng=np.random.default_rng(seed); self.drift=drift
        self.theta=self.rng.uniform(0,2*np.pi,n)
        self.omega=self.rng.uniform(0.92,1.08,n)
        self.shift=0.0
    def R(self):
        return float(np.abs(np.mean(np.exp(1j*self.theta))))
    def step(self,p:ModeParams,dt=0.05):
        self.shift += float(self.rng.uniform(-self.drift,self.drift))
        mult = 1.0 + self.shift*0.01
        f0,f1,f2 = p.f0*mult, p.f1*mult, p.f2*mult
        drive = p.A*(math.sin(2*math.pi*f0*dt+p.phi)+math.sin(2*math.pi*f1*dt)+math.sin(2*math.pi*f2*dt))*p.duty
        new=self.theta.copy()
        for i in range(self.n):
            coupling=np.sum(np.sin(self.theta-self.theta[i]))/self.n
            new[i] += (self.omega[i]+self.K*coupling+drive+p.noise*self.rng.normal())*dt
        self.theta=np.mod(new,2*np.pi)
    def run(self,p,steps):
        vals=[]
        for _ in range(steps):
            self.step(p); vals.append(self.R())
        return float(np.mean(vals)), float(np.std(vals))

def zero(p, noise_mult):
    return ModeParams(0,0,0,0,0,0,p.noise*noise_mult)

def shifted(p, shift, noise_mult):
    return ModeParams(p.f0*(1+shift), p.f1*(1-shift), p.f2*(1+shift/2), p.A, p.phi, p.duty, p.noise*noise_mult)

def inverted_phi(p):
    return ModeParams(p.f0,p.f1,p.f2,p.A,-p.phi,p.duty,p.noise)

def swapped(p):
    return ModeParams(p.f0,p.f2,p.f1,p.A,p.phi,p.duty,p.noise)

def high_low(p, high=1.25, low=0.65):
    ph = ModeParams(p.f0,p.f1,p.f2,min(1.0,p.A*high),p.phi,p.duty,p.noise)
    pl = ModeParams(p.f0,p.f1,p.f2,max(0.02,p.A*low),p.phi,p.duty,p.noise)
    return ph, pl

def bucket(p, width=25.0):
    return (round(p.f0/width)*width, round(p.f1/width)*width, round(p.f2/width)*width)

def eval_basic(p, cfg, seed, n, K, off_steps=None):
    off_steps = off_steps or cfg["off_steps"]
    s=System(n=n,K=K,seed=seed,drift=cfg["drift_strength"])
    R_on,_=s.run(p,cfg["on_steps"])
    R_off,off_std=s.run(zero(p,cfg["noise_multiplier"]),off_steps)
    R_shift,_=s.run(shifted(p,cfg["param_shift"],cfg["noise_multiplier"]),cfg["shift_steps"])
    return {"R_on":R_on,"R_off":R_off,"R_off_std":off_std,"R_shift":R_shift}

def eval_invariance(p, cfg, seed):
    env_results=[]
    for ei, env in enumerate(cfg["environments"]):
        env_results.append(eval_basic(p,cfg,seed+ei*1000,env["N"],env["K"]))
    long_res=eval_basic(p,cfg,seed+7777,cfg["environments"][0]["N"],cfg["environments"][0]["K"],off_steps=cfg["long_off_steps"])
    inv_phi=eval_basic(inverted_phi(p),cfg,seed+8888,cfg["environments"][0]["N"],cfg["environments"][0]["K"])
    swap_res=eval_basic(swapped(p),cfg,seed+9999,cfg["environments"][0]["N"],cfg["environments"][0]["K"])
    ph,pl=high_low(p,cfg["hysteresis"]["high"],cfg["hysteresis"]["low"])
    s=System(n=cfg["environments"][0]["N"],K=cfg["environments"][0]["K"],seed=seed+1111,drift=cfg["drift_strength"])
    Rh,_=s.run(ph,cfg["hysteresis"]["steps"])
    Rl,_=s.run(pl,cfg["hysteresis"]["steps"])
    Rmem,_=s.run(zero(p,cfg["noise_multiplier"]),cfg["off_steps"])
    return {
        "env_results":env_results,
        "long":long_res,
        "inverted_phi":inv_phi,
        "swapped":swap_res,
        "hysteresis":{"R_high":Rh,"R_low":Rl,"R_memory":Rmem},
    }

def classify(inv,cfg):
    th=cfg["thresholds"]
    env_off=[x["R_off"] for x in inv["env_results"]]
    env_std=float(np.std(env_off))
    env_mean=float(np.mean(env_off))
    long_ok=inv["long"]["R_off"]>=th["long_R_off_min"]
    inv_ok=inv["inverted_phi"]["R_off"]>=th["inversion_R_off_min"]
    swap_ok=inv["swapped"]["R_off"]>=th["swap_R_off_min"]
    mem_ok=inv["hysteresis"]["R_memory"]>=th["memory_R_min"]
    env_ok=env_mean>=th["env_R_off_min"] and env_std<=th["env_R_off_std_max"]
    passed = sum([long_ok,inv_ok,swap_ok,mem_ok,env_ok])
    if passed==5:
        label="invariant_stable"
    elif passed>=3:
        label="invariant_metastable"
    else:
        label="reject"
    score=env_mean-env_std+0.1*passed+0.1*inv["long"]["R_off"]+0.05*inv["hysteresis"]["R_memory"]
    return label,score,{"env_mean":env_mean,"env_std":env_std,"long_ok":long_ok,"inv_ok":inv_ok,"swap_ok":swap_ok,"mem_ok":mem_ok,"env_ok":env_ok,"passed":passed}

def candidates(cfg):
    out=[]
    for f0 in cfg["freqs"]:
        for f1 in cfg["freqs"]:
            for f2 in cfg["freqs"]:
                out.append(ModeParams(float(f0),float(f1),float(f2),cfg["A"],cfg["phi"],cfg["duty"],cfg["noise"]))
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config",default="configs/config.json")
    ap.add_argument("--outdir",default="results")
    args=ap.parse_args()
    cfg=json.load(open(args.config,"r",encoding="utf-8"))
    out=Path(args.outdir); out.mkdir(exist_ok=True)
    rows=[]
    for idx,p in enumerate(candidates(cfg)):
        inv=eval_invariance(p,cfg,cfg["seed"]+idx*10000)
        label,score,checks=classify(inv,cfg)
        rows.append({"params":asdict(p),"bucket":bucket(p),"label":label,"score":score,"checks":checks,"invariance":inv})
    rows.sort(key=lambda x:x["score"], reverse=True)
    stable=[r for r in rows if r["label"]=="invariant_stable"]
    meta=[r for r in rows if r["label"]=="invariant_metastable"]
    rej=[r for r in rows if r["label"]=="reject"]
    def dump(n,obj): json.dump(obj,open(out/n,"w",encoding="utf-8"),indent=2,ensure_ascii=False)
    dump("invariance_results_all.json",rows)
    dump("invariant_stable_modes.json",stable)
    dump("invariant_metastable_modes.json",meta)
    dump("invariant_rejected_modes.json",rej)
    summary={"total_modes":len(rows),"invariant_stable":len(stable),"invariant_metastable":len(meta),"reject":len(rej),"best_score":rows[0]["score"] if rows else None,"best_label":rows[0]["label"] if rows else None,"criteria":cfg["thresholds"]}
    dump("invariance_summary.json",summary)
    print(json.dumps(summary,indent=2,ensure_ascii=False))
if __name__=="__main__":
    main()
