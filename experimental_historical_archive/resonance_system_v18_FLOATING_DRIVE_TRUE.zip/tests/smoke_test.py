#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v18_floating_drive.py","results/floating_drive_summary.json","results/floating_drive_trials.json","docs/README.md"]:
    fp=Path(p); assert fp.exists() and fp.stat().st_size>100, p
s=json.load(open("results/floating_drive_summary.json","r",encoding="utf-8"))
assert "mean_tracking_error" in s and "all_trials" in s
print("SMOKE_OK")
