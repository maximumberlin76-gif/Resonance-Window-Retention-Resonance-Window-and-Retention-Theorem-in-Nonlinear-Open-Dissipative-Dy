# v18 Equations

window_center(t+1) =
window_center(t) + drift + jitter

f0(t+1) =
f0(t) + follow_gain * (window_center(t) - f0(t))

tracking_error =
abs(window_center - f0) / abs(window_center)

S_float =
mean_C - var_C - 0.35*lock_loss_rate - 0.50*mean_tracking_error
