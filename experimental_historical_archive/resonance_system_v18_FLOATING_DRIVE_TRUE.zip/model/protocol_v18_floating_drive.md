# v18 Floating Drive Protocol

1. Load repaired trials from v17.
2. Convert each repaired mode into a floating-window trial.
3. Simulate window_center(t) drift.
4. Update f0 using feedback:
   f0(t+1) = f0(t) + follow_gain * (window_center - f0)
5. Set:
   f1 = 2*f0
   f2 = 0.5*f0
6. Track:
   tracking_error
   lock_loss_rate
   C(t)
7. Classify floating stability.
