# Resonance System v18 TRUE FLOATING DRIVE

## Purpose

v17 repaired modes under mostly fixed-window assumptions.  
v18 treats the resonance window as floating.

The drive is no longer fixed:

```text
f0, f1, f2 follow window_center(t)
```

## Core Idea

A floating window is valid only if:

- the window can drift,
- the drive tracks it,
- tracking error stays inside corridor,
- coherence C(t) remains above collapse threshold,
- lock-loss rate stays low.

## New Concepts

- window_center(t)
- tracking_error
- lock_loss_rate
- floating corridor
- adaptive follow gain
- S_float

## Run

```bash
python scripts/generate_adaptive_repair_seed.py
python scripts/engine_v18_floating_drive.py --input results/adaptive_repair_trials.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/floating_drive_summary.json
results/floating_drive_trials.json
validation/triple_validation_summary.json
```

## Interpretation

- floating_stable:
  drive follows the moving window and maintains coherence.

- floating_metastable:
  partial tracking; useful but fragile.

- floating_collapse:
  tracking fails or coherence falls below threshold.

## Limitation

Computational sandbox only.
