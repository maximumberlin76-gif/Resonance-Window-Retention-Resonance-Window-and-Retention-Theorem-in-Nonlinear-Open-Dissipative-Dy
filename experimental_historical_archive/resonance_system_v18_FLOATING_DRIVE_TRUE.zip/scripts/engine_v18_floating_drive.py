#!/usr/bin/env python3
"""
Resonance System v18 TRUE FLOATING DRIVE

v17 applied adaptive repair but assumed mostly fixed windows.
v18 treats the resonance window as floating.

Core:
- window_center(t)
- drive_f0/f1/f2 follow window drift
- feedback uses tracking error
- lock is valid only if the drive stays inside the moving window corridor

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, random, math
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def simulate_floating_trial(trial, cfg, seed):
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    # Initial floating window center and drive.
    f_center = trial.get("f_center", rng.choice([76.4, 150.0, 458.4]))
    f0 = f_center
    f1 = f_center * 2.0
    f2 = f_center / 2.0

    C = clamp(trial["reentry_norm"] - trial["new_edge_penalty"])
    drift_rate = cfg["floating"]["drift_rate"]
    jitter = cfg["floating"]["jitter"]
    follow_gain = cfg["floating"]["follow_gain"]
    corridor = cfg["floating"]["corridor"]

    series = []
    lock_loss_count = 0
    collapsed = False
    collapse_at = None

    for t in range(cycles):
        # Moving resonance window.
        f_center += drift_rate * math.sin(2 * math.pi * t / cfg["floating"]["period"]) + rng.uniform(-jitter, jitter)

        # Current drive estimate should follow the floating center.
        err = f_center - f0
        f0 += follow_gain * err
        f1 = 2.0 * f0
        f2 = 0.5 * f0

        tracking_error = abs(f_center - f0) / max(1.0, abs(f_center))
        in_corridor = tracking_error <= corridor

        if not in_corridor:
            lock_loss_count += 1

        D_t = cfg["dissipation_rate"] * (1.0 + 0.012 * t)
        noise = rng.uniform(-cfg["noise"], cfg["noise"])

        # Floating lock support exists only when drive tracks the window.
        lock_support = cfg["floating"]["lock_support"] * (1.0 - tracking_error) if in_corridor else -cfg["floating"]["lock_penalty"]
        repair = cfg["recovery_gain"] * max(0.0, 1.0 - C)

        C = clamp(C + repair + lock_support - D_t + noise)

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

        series.append({
            "t": t,
            "window_center": f_center,
            "f0": f0,
            "f1": f1,
            "f2": f2,
            "tracking_error": tracking_error,
            "in_corridor": in_corridor,
            "C": C,
            "D_t": D_t,
            "repair": repair,
            "lock_support": lock_support,
            "noise": noise
        })

    mean_C = sum(x["C"] for x in series) / len(series)
    var_C = sum((x["C"] - mean_C)**2 for x in series) / len(series)
    mean_tracking_error = sum(x["tracking_error"] for x in series) / len(series)
    lock_loss_rate = lock_loss_count / cycles
    S_float = mean_C - var_C - lock_loss_rate * 0.35 - mean_tracking_error * 0.50

    if collapsed:
        label = "floating_collapse"
    elif S_float >= cfg["thresholds"]["floating_stable"] and lock_loss_rate <= cfg["thresholds"]["max_lock_loss"]:
        label = "floating_stable"
    elif S_float >= cfg["thresholds"]["floating_metastable"]:
        label = "floating_metastable"
    else:
        label = "floating_weak"

    return {
        "mean_C": mean_C,
        "var_C": var_C,
        "mean_tracking_error": mean_tracking_error,
        "lock_loss_rate": lock_loss_rate,
        "S_float": S_float,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "label": label,
        "series": series
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="results/adaptive_repair_trials.json")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    trials = json.load(open(args.input, "r", encoding="utf-8"))

    rows = []
    for idx, trial in enumerate(trials):
        base = {
            "trial_index": trial["trial_index"],
            "before_label": trial.get("before_label"),
            "after_label": trial.get("after_label"),
            "reentry_norm": min(1.0, max(0.0, 0.55 + trial.get("after_mean_C", 0.5) * 0.45)),
            "new_edge_penalty": max(0.02, min(0.35, 0.20 - trial.get("improvement_S_time", 0) * 0.15)),
            "f_center": [76.4, 150.0, 458.4][idx % 3]
        }
        sim = simulate_floating_trial(base, cfg, cfg["seed"] + idx * 100)
        rows.append({**base, **sim})

    stable = [r for r in rows if r["label"] == "floating_stable"]
    meta = [r for r in rows if r["label"] == "floating_metastable"]
    weak = [r for r in rows if r["label"] == "floating_weak"]
    collapse = [r for r in rows if r["label"] == "floating_collapse"]

    summary = {
        "trials": len(rows),
        "floating_stable": len(stable),
        "floating_metastable": len(meta),
        "floating_weak": len(weak),
        "floating_collapse": len(collapse),
        "mean_S_float": sum(r["S_float"] for r in rows)/len(rows),
        "mean_tracking_error": sum(r["mean_tracking_error"] for r in rows)/len(rows),
        "mean_lock_loss_rate": sum(r["lock_loss_rate"] for r in rows)/len(rows),
        "label": "floating_drive_success" if len(stable)+len(meta) >= len(rows)*0.70 and len(collapse) <= len(rows)*0.20 else "floating_drive_limited",
        "top_trials": sorted(rows, key=lambda x: x["S_float"], reverse=True)[:10],
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"floating_drive_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"floating_drive_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({k: summary[k] for k in ["trials","floating_stable","floating_metastable","floating_weak","floating_collapse","mean_S_float","mean_tracking_error","mean_lock_loss_rate","label"]}, indent=2))

if __name__ == "__main__":
    main()
