#!/usr/bin/env python3
from pathlib import Path
import json
required = [
    "scripts/engine_v15_temporal_stability.py",
    "results/temporal_stability_summary.json",
    "results/temporal_stability_trials.json",
    "docs/README.md",
]
for p in required:
    fp = Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s = json.load(open("results/temporal_stability_summary.json","r",encoding="utf-8"))
assert "mean_S_time" in s and "all_trials" in s
print("SMOKE_OK")
