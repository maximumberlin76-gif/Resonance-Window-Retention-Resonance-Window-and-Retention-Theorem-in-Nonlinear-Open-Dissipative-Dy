# Resonance System v15 TRUE TEMPORAL STABILITY

## Purpose

v14 showed recovery after damage.  
v15 checks whether recovery remains stable over time.

The key question:

```text
Does the recovered regime persist,
or does it collapse after several cycles of dissipation and noise?
```

## What v15 Adds

1. Normalized reentry score  
   Reentry is capped at 1.0 to prevent overestimating recovery.

2. Penalty for excessive new edges  
   A network that “recovers” only by adding too many weak links is penalized.

3. Dissipation over time  
   D(t) slowly rises during the cycle.

4. Coherence loop  
   C(t) is updated across N cycles using:
   - repair
   - dissipation
   - stochastic noise

5. Collapse detection  
   If C(t) falls below threshold, the mode is marked as temporal_collapse.

## Run

```bash
python scripts/generate_recovery_seed.py
python scripts/engine_v15_temporal_stability.py --input results/recovery_summary.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/temporal_stability_summary.json
results/temporal_stability_trials.json
validation/triple_validation_summary.json
```

## Interpretation

- time_stable_recovery:
  recovery is not just immediate; it holds through time.

- limited_temporal_stability:
  some regimes hold, others decay.

- temporal_unstable:
  recovery is mostly a transient artifact.

## Limitation

This remains a computational sandbox.  
It validates temporal stability logic, not physical implementation.
