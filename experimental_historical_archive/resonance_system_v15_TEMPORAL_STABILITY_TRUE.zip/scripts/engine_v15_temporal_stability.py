#!/usr/bin/env python3
"""
Resonance System v15 TRUE TEMPORAL STABILITY

v14 checked recovery after damage.
v15 checks whether recovery remains stable over time.

Adds:
- normalized reentry score
- penalty for excessive new edges
- dissipation over time D(t)
- coherence decay/noise loop
- temporal stability score S_time
- collapse detection over N cycles

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def simulate_temporal_run(trial, cycles, noise, dissipation_rate, recovery_gain, seed):
    rng = random.Random(seed)

    base = max(1, trial["base_largest"])
    damaged = trial["damaged_largest"]
    recovered = trial["recovered_largest"]
    new_edges = trial["recovered_new_edges"]
    total_edges = max(1, trial["recovered_edges"])

    raw_reentry = (recovered - damaged) / max(1, base - damaged)
    reentry_norm = clamp(raw_reentry, 0.0, 1.0)

    new_edge_penalty = min(0.35, new_edges / total_edges)
    C = clamp(reentry_norm - new_edge_penalty, 0.0, 1.0)

    series = []
    collapsed = False
    collapse_at = None

    for t in range(cycles):
        D_t = dissipation_rate * (1.0 + 0.015 * t)
        stochastic = rng.uniform(-noise, noise)
        repair = recovery_gain * max(0.0, 1.0 - C)

        C = clamp(C + repair - D_t + stochastic, 0.0, 1.0)

        series.append({
            "t": t,
            "C": C,
            "D_t": D_t,
            "repair": repair,
            "noise": stochastic
        })

        if C < 0.35 and not collapsed:
            collapsed = True
            collapse_at = t

    mean_C = sum(x["C"] for x in series) / len(series)
    var_C = sum((x["C"] - mean_C) ** 2 for x in series) / len(series)
    S_time = mean_C - var_C

    return {
        "raw_reentry": raw_reentry,
        "reentry_norm": reentry_norm,
        "new_edge_penalty": new_edge_penalty,
        "mean_C": mean_C,
        "var_C": var_C,
        "S_time": S_time,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "series": series
    }

def classify(run, thresholds):
    if run["collapsed"]:
        return "temporal_collapse"
    if run["S_time"] >= thresholds["stable_S_time"] and run["mean_C"] >= thresholds["stable_mean_C"]:
        return "temporal_stable"
    if run["S_time"] >= thresholds["metastable_S_time"]:
        return "temporal_metastable"
    return "temporal_weak"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="results/recovery_summary.json")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    recovery = json.load(open(args.input, "r", encoding="utf-8"))
    trials = recovery["all_trials"]

    outdir = Path(args.outdir)
    outdir.mkdir(exist_ok=True)

    rows = []
    for idx, trial in enumerate(trials):
        run = simulate_temporal_run(
            trial=trial,
            cycles=cfg["cycles"],
            noise=cfg["noise"],
            dissipation_rate=cfg["dissipation_rate"],
            recovery_gain=cfg["recovery_gain"],
            seed=cfg["seed"] + idx * 100
        )
        label = classify(run, cfg["thresholds"])
        rows.append({
            "trial_index": idx,
            "trial_label": trial["label"],
            "damage_mode": trial["damage_mode"],
            "damage_fraction": trial["damage_fraction"],
            "boost": trial["boost"],
            "label": label,
            **{k: v for k, v in run.items() if k != "series"},
            "series": run["series"]
        })

    stable = [r for r in rows if r["label"] == "temporal_stable"]
    meta = [r for r in rows if r["label"] == "temporal_metastable"]
    weak = [r for r in rows if r["label"] == "temporal_weak"]
    collapse = [r for r in rows if r["label"] == "temporal_collapse"]

    mean_S = sum(r["S_time"] for r in rows) / max(1, len(rows))
    mean_C = sum(r["mean_C"] for r in rows) / max(1, len(rows))

    summary = {
        "trials": len(rows),
        "temporal_stable": len(stable),
        "temporal_metastable": len(meta),
        "temporal_weak": len(weak),
        "temporal_collapse": len(collapse),
        "mean_S_time": mean_S,
        "mean_C": mean_C,
        "label": "time_stable_recovery" if len(stable) >= len(rows)*0.5 and len(collapse) == 0 else ("limited_temporal_stability" if len(stable)+len(meta) > len(collapse) else "temporal_unstable"),
        "top_trials": sorted(rows, key=lambda x: x["S_time"], reverse=True)[:10],
        "all_trials": rows
    }

    json.dump(summary, open(outdir/"temporal_stability_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(outdir/"temporal_stability_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({k: summary[k] for k in ["trials","temporal_stable","temporal_metastable","temporal_weak","temporal_collapse","mean_S_time","mean_C","label"]}, indent=2))

if __name__ == "__main__":
    main()
