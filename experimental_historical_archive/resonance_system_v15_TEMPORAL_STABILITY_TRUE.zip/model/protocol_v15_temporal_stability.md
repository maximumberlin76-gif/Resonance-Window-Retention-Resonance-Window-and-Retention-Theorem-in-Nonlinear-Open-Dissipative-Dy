# v15 Temporal Stability Protocol

1. Load recovery trials from v14.
2. Normalize reentry score:
   reentry_norm = min(1, raw_reentry)
3. Apply penalty for new recovery edges.
4. Simulate C(t) over N cycles:
   C(t+1) = C(t) + repair - D(t) + noise
5. Detect collapse if C(t) < threshold.
6. Compute:
   mean_C
   var_C
   S_time = mean_C - var_C
7. Classify:
   - temporal_stable
   - temporal_metastable
   - temporal_weak
   - temporal_collapse
