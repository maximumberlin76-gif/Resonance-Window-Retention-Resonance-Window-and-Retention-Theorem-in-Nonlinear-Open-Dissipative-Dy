# v15 Equations

reentry_norm = min(1, raw_reentry)

C0 = reentry_norm - new_edge_penalty

D(t) = dissipation_rate * (1 + 0.015*t)

C(t+1) = C(t) + repair - D(t) + noise

S_time = mean(C(t)) - var(C(t))

Collapse:
C(t) < 0.35
