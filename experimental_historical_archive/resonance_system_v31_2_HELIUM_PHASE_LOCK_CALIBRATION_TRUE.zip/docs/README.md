# v31.2 — Helium Phase-Lock Calibration

## Abstract

v31.1 showed that the base helium Kuramoto layer did not reach phase lock.

This module calibrates phase-lock conditions for helium plasma modeled as a nonlinear dissipative open dynamic system.

The calibration scans:

- coupling K,
- external drive F_ext,
- frequency dispersion omega_sigma,
- frequency candidates,
- retention after drive-off.

This is a computational sandbox, not laboratory evidence.

## Core Criterion

```text
R = |(1/N) Σ exp(i φ_j)|
```

Phase lock candidate:

```text
R >= 0.7
```

Resonance-window candidate:

```text
R_final >= 0.7
and
stable_periods >= synthesis_min_periods
```

## Frequency Candidates

- 6.78 MHz
- 9.20 MHz
- 13.56 MHz
- 18.40 MHz
- 27.12 MHz

## System Class

```text
nonlinear dissipative open dynamic systems
```

## Run

```bash
python scripts/engine_v31_2_helium_phase_lock_calibration.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/helium_phase_lock_calibration_summary.json
results/helium_phase_lock_calibration_trials.json
journal/session_journal_v31_2.md
```

## Next Step

v32 — Argon vs Helium comparison.
