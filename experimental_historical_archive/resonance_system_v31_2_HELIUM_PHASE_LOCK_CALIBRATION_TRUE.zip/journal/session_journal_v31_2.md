# Session Journal — v31.2

## Step

v31.2 — Helium Phase-Lock Calibration.

## Reason

v31.1 produced no phase lock across all scenarios.
The helium Kuramoto layer was under-coupled and too dispersed.

## Added

- K scan
- F_ext scan
- omega_sigma scan
- frequency candidate comparison
- retention/off-drive marker

## Core Principle

Helium requires stronger coupling and tighter dispersion control than the base layer.
