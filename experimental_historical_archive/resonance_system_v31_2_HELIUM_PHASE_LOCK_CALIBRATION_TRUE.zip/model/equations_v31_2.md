# v31.2 Equations

## Order Parameter

R =
|(1/N) Σ exp(i φ_j)|

## Kuramoto Layer

dφ_i/dt =
ω_i
+ K R sin(ψ - φ_i)
+ F_ext sin(ω_ext t - φ_i)
+ η_i(t)

## Useful Coherent Work

W_coh(τ) =
∫ max(0, R(t) - R_floor) · F_ext(t) dt

## Candidate Rule

helium_phase_lock_resonance_window_candidate if:

R_final >= R_lock
and
stable_periods >= synthesis_min_periods
