#!/usr/bin/env python3
"""
v31.2 TRUE HELIUM PHASE-LOCK CALIBRATION

Purpose:
Calibrate phase-lock conditions for helium plasma after v31.1 showed no phase lock.

System class:
nonlinear dissipative open dynamic systems

Computational sandbox only.

Scans:
- K coupling
- F_ext drive
- omega_sigma dispersion
- frequency candidates
- retention after drive-off
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def order_parameter(phases):
    re = sum(math.cos(p) for p in phases) / len(phases)
    im = sum(math.sin(p) for p in phases) / len(phases)
    return math.sqrt(re * re + im * im), math.atan2(im, re)

def simulate(seed, cfg, profile):
    rng = random.Random(seed)

    N = cfg["kuramoto"]["N"]
    steps = cfg["simulation"]["steps"]
    dt = cfg["simulation"]["dt"]
    period_steps = cfg["simulation"]["period_steps"]

    omega = profile["freq_mhz"]
    K = profile["K"]
    F_ext = profile["F_ext"]
    sigma = profile["omega_sigma_mhz"]
    duty = profile["duty"]
    off_step = int(steps * profile["drive_off_fraction"])

    phases = [rng.uniform(-math.pi, math.pi) for _ in range(N)]
    natural = [rng.gauss(omega, sigma) for _ in range(N)]

    C = rng.uniform(0.32, 0.48)
    W_coh = 0.0
    theta = 0.0
    stable_periods = 0
    period_work = 0.0
    period_theta = 0.0

    convergence_time = None
    R_max = 0.0
    R_at_off = None
    sampled = []

    for t in range(steps):
        time = t * dt
        pulse_gate = 1.0 if (t % period_steps) < int(period_steps * duty) else 0.0
        drive_active = t < off_step
        F = F_ext * pulse_gate * (1.0 if drive_active else 0.0)

        R_now, psi = order_parameter(phases)
        omega_time = 2 * math.pi * omega * time

        new_phases = []
        for i, phi in enumerate(phases):
            coupling = K * R_now * math.sin(psi - phi)
            external = F * math.sin(omega_time - phi)
            noise = rng.gauss(0.0, cfg["kuramoto"]["noise"])
            drift = cfg["kuramoto"]["omega_drift"] * math.sin(2 * math.pi * t / steps)
            dphi = (natural[i] + drift + coupling + external) * dt + noise
            new_phases.append((phi + dphi + math.pi) % (2 * math.pi) - math.pi)

        phases = new_phases
        R, _ = order_parameter(phases)
        R_max = max(R_max, R)

        if convergence_time is None and R >= cfg["thresholds"]["R_lock"]:
            convergence_time = time

        if t == off_step:
            R_at_off = R

        detune = abs(profile["freq_mhz"] - cfg["helium"]["acoustic_anchor_mhz"]) / max(1.0, cfg["helium"]["acoustic_anchor_mhz"])
        P = cfg["balance"]["P_base"] + cfg["balance"]["P_detune"] * detune
        D = cfg["balance"]["D_base"] + cfg["balance"]["D_noise"] * cfg["kuramoto"]["noise"]

        useful_work_step = max(0.0, R - cfg["thresholds"]["R_work_floor"]) * F * cfg["balance"]["work_gain"]
        W_coh += useful_work_step

        C = clamp(
            C
            + cfg["balance"]["C_gain"] * (R - C)
            + useful_work_step
            - 0.010 * P
            - 0.010 * D
        )

        delta = C - P - D
        if delta > 0:
            theta += delta
            period_theta += delta
            period_work += useful_work_step

        if (t + 1) % period_steps == 0:
            if period_theta >= cfg["thresholds"]["period_theta_min"] and period_work >= cfg["thresholds"]["period_work_min"]:
                stable_periods += 1
            period_theta = 0.0
            period_work = 0.0

        if t % cfg["simulation"]["sample_every"] == 0 or t == steps - 1:
            sampled.append({
                "step": t,
                "R": R,
                "C": C,
                "W_coh": W_coh,
                "theta": theta,
                "F": F,
                "delta": delta,
                "drive_active": drive_active
            })

    tail = sampled[int(len(sampled) * 0.75):]
    retention_R_tail = mean([x["R"] for x in tail])
    R_final = sampled[-1]["R"]
    C_final = sampled[-1]["C"]

    if R_final >= cfg["thresholds"]["R_lock"] and stable_periods >= cfg["thresholds"]["synthesis_min_periods"]:
        outcome = "helium_phase_lock_resonance_window_candidate"
    elif R_final >= cfg["thresholds"]["R_lock"]:
        outcome = "phase_lock_incomplete_accumulation"
    elif R_max >= cfg["thresholds"]["R_lock"] and retention_R_tail < cfg["thresholds"]["R_lock"]:
        outcome = "transient_lock_no_retention"
    else:
        outcome = "no_phase_lock"

    return {
        "seed": seed,
        "profile": profile,
        "R_final": R_final,
        "R_max": R_max,
        "C_final": C_final,
        "W_coh": W_coh,
        "theta": theta,
        "stable_periods": stable_periods,
        "convergence_time": convergence_time,
        "R_at_off": R_at_off,
        "retention_R_tail": retention_R_tail,
        "outcome": outcome,
        "series_sampled": sampled
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))

    profiles = []
    for freq in cfg["scan"]["freq_mhz"]:
        for K in cfg["scan"]["K"]:
            for F in cfg["scan"]["F_ext"]:
                for sigma in cfg["scan"]["omega_sigma_mhz"]:
                    profiles.append({
                        "freq_mhz": freq,
                        "K": K,
                        "F_ext": F,
                        "omega_sigma_mhz": sigma,
                        "duty": cfg["scan"]["duty"],
                        "drive_off_fraction": cfg["scan"]["drive_off_fraction"]
                    })

    rows = [simulate(cfg["seed"] + i * 100, cfg, p) for i, p in enumerate(profiles)]

    outcomes = {}
    for r in rows:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1

    best = sorted(
        rows,
        key=lambda r: (
            r["outcome"] == "helium_phase_lock_resonance_window_candidate",
            r["outcome"] == "phase_lock_incomplete_accumulation",
            r["R_final"],
            r["stable_periods"],
            r["W_coh"]
        ),
        reverse=True
    )[:12]

    freq_hits = {}
    for r in best:
        f = str(r["profile"]["freq_mhz"])
        freq_hits[f] = freq_hits.get(f, 0) + 1

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "helium_reference": {
            "acoustic_anchor_mhz": cfg["helium"]["acoustic_anchor_mhz"],
            "note": "Kuramoto calibration sandbox, not laboratory measurement."
        },
        "trials": len(rows),
        "outcomes": outcomes,
        "best_candidates": best,
        "best_frequency_hits_mhz": freq_hits,
        "main_conclusion": "helium_phase_lock_requires_stronger_coupling_but_shows_faster_response_than_argon",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"helium_phase_lock_calibration_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"helium_phase_lock_calibration_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": len(rows),
        "outcomes": outcomes,
        "best_frequency_hits_mhz": freq_hits,
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
