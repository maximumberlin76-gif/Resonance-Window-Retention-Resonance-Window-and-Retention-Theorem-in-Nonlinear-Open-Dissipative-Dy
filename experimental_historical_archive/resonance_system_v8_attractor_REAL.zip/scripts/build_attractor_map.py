
#!/usr/bin/env python3
import json, csv
from pathlib import Path
from collections import defaultdict

def load_results():
    for p in [Path("results/results_all.json"), Path("results/results_sample.json")]:
        if p.exists():
            return json.load(open(p, "r", encoding="utf-8")), str(p)
    raise FileNotFoundError("No results file found")

def bucket(f, width=25.0):
    return str(round(float(f) / width) * width)

def main():
    rows, source = load_results()
    groups = defaultdict(list)

    for r in rows:
        key = (bucket(r.get("f0", 0)), bucket(r.get("f1", 0)), bucket(r.get("f2", 0)))
        groups[key].append(r)

    attractors = []
    for key, items in groups.items():
        scores = [float(x.get("score", 0)) for x in items]
        roff = [float(x.get("R_off_mean", x.get("R_off", 0))) for x in items]
        labels = [x.get("label", x.get("class", "unknown")) for x in items]
        stable = labels.count("stable")
        meta = labels.count("metastable")
        mean_score = sum(scores) / max(1, len(scores))
        mean_retention = sum(roff) / max(1, len(roff))

        if stable > 0 and mean_retention >= 0.70:
            kind = "stable_attractor"
        elif meta > 0 and mean_retention >= 0.45:
            kind = "metastable_cloud"
        else:
            kind = "noise_or_false_peak"

        attractors.append({
            "bucket_f0": key[0],
            "bucket_f1": key[1],
            "bucket_f2": key[2],
            "count": len(items),
            "stable_count": stable,
            "metastable_count": meta,
            "mean_score": mean_score,
            "mean_retention": mean_retention,
            "kind": kind,
            "samples": items[:3]
        })

    attractors.sort(key=lambda x: (x["kind"] != "stable_attractor", -x["mean_score"]))

    Path("results").mkdir(exist_ok=True)
    Path("logs").mkdir(exist_ok=True)
    json.dump(attractors, open("results/attractor_map.json", "w", encoding="utf-8"), indent=2)

    summary = {
        "source": source,
        "total_buckets": len(attractors),
        "stable_attractors": sum(1 for x in attractors if x["kind"] == "stable_attractor"),
        "metastable_clouds": sum(1 for x in attractors if x["kind"] == "metastable_cloud"),
        "noise_or_false_peak": sum(1 for x in attractors if x["kind"] == "noise_or_false_peak"),
        "top_10": attractors[:10]
    }
    json.dump(summary, open("results/attractor_summary.json", "w", encoding="utf-8"), indent=2)

    with open("logs/attractor_map.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["bucket_f0","bucket_f1","bucket_f2","count","kind","mean_score","mean_retention"])
        for a in attractors:
            w.writerow([a["bucket_f0"], a["bucket_f1"], a["bucket_f2"], a["count"], a["kind"], a["mean_score"], a["mean_retention"]])

    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
