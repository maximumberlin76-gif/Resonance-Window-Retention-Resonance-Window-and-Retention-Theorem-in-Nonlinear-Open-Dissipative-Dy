# v8 Attractor Map Layer

Adds grouping of retained modes into attractor regions.

A real window is treated as a cloud/region, not a single peak.

Outputs:
- results/attractor_map.json
- results/attractor_summary.json
- logs/attractor_map.csv
