# Experiment 03 — Retention After Forcing OFF

## Goal

Test whether the coherent regime remains after external forcing is removed.

## Change from Experiment 02

- longer forcing before OFF
- coupling scan K = 0.40 → 0.60
- focused around omega_ext = 0.86–0.92

## Retained candidate

```text
R_post_off >= 0.7
retention_time >= 1.5
```

Meaning:

the system is not merely being forced;
it has entered a retained coherent regime.
