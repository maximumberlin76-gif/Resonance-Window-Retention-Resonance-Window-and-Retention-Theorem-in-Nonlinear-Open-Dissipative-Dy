#!/usr/bin/env python3
import numpy as np, json, csv
from pathlib import Path

def simulate(
    N=160, T=9.0, dt=0.01,
    omega_mean=1.0, omega_std=0.10,
    K=0.40,
    F_ext=0.18, omega_ext=0.88, phase_ext=0.7853981633974483,
    duty_cycle=0.5,
    noise=0.02,
    forcing_off_time=6.0,
    seed=1,
    R_threshold=0.7,
):
    rng = np.random.default_rng(seed)
    steps = int(T / dt)
    t = np.arange(steps) * dt
    phi = rng.uniform(0, 2*np.pi, size=N)
    omega = rng.normal(omega_mean, omega_std, size=N)

    R_values = np.zeros(steps)
    forcing_values = np.zeros(steps)
    period = 2*np.pi / omega_ext if omega_ext != 0 else T

    for k, tk in enumerate(t):
        z = np.mean(np.exp(1j * phi))
        R = np.abs(z)
        psi = np.angle(z)
        R_values[k] = R

        active = F_ext
        if tk >= forcing_off_time:
            active = 0.0
        if duty_cycle < 1.0 and ((tk % period) / period) > duty_cycle:
            active = 0.0
        forcing_values[k] = active

        phi += dt * (
            omega
            + K * R * np.sin(psi - phi)
            + active * np.sin(omega_ext * tk + phase_ext - phi)
            + noise * rng.normal(0, 1, size=N)
        )

    above = np.where(R_values >= R_threshold)[0]
    t_conv = float(t[above[0]]) if len(above) else None

    off_idx = np.searchsorted(t, forcing_off_time)
    after = R_values[off_idx:]
    below = np.where(after < R_threshold)[0]
    retention_time = float(t[off_idx + below[0]] - forcing_off_time) if len(below) else float(T - forcing_off_time)

    R_pre_off = float(np.mean(R_values[max(0, off_idx-80):off_idx]))
    R_post_off = float(np.mean(R_values[off_idx:min(len(R_values), off_idx+80)]))
    R_last = float(np.mean(R_values[int(0.9*steps):]))
    D_proxy = float(np.var(np.diff(R_values[int(0.5*steps):])))
    P_in = float(np.mean(forcing_values**2))
    R_net = P_in * R_last - D_proxy

    return {
        "R_final": float(R_values[-1]),
        "R_max": float(np.max(R_values)),
        "R_mean_last_10pct": R_last,
        "R_pre_off": R_pre_off,
        "R_post_off": R_post_off,
        "t_conv": t_conv,
        "retention_time": retention_time,
        "D_proxy": D_proxy,
        "P_in": P_in,
        "R_net": R_net,
    }

def main():
    out = Path("results")
    out.mkdir(exist_ok=True)

    rows = []
    run_id = 0

    K_values = [0.40, 0.45, 0.50, 0.55, 0.60]
    forcing_off_values = [5.0, 6.0, 7.0]
    omega_values = [0.86, 0.88, 0.90, 0.92]
    amp_values = [0.14, 0.18, 0.22]
    duty_values = [0.5, 0.75, 1.0]
    phase_values = [0.0, 0.7853981633974483]

    for K in K_values:
        for forcing_off_time in forcing_off_values:
            for omega_ext in omega_values:
                for F_ext in amp_values:
                    for duty_cycle in duty_values:
                        for phase_ext in phase_values:
                            run_id += 1
                            m = simulate(
                                K=K,
                                forcing_off_time=forcing_off_time,
                                omega_ext=omega_ext,
                                F_ext=F_ext,
                                duty_cycle=duty_cycle,
                                phase_ext=phase_ext,
                                seed=3000+run_id,
                            )
                            rows.append({
                                "run_id": run_id,
                                "K": K,
                                "forcing_off_time": forcing_off_time,
                                "omega_ext": omega_ext,
                                "F_ext": F_ext,
                                "duty_cycle": duty_cycle,
                                "phase_ext": phase_ext,
                                **m
                            })

    retained = [r for r in rows if r["R_post_off"] >= 0.7 and r["retention_time"] >= 1.5]
    retained_sorted = sorted(retained, key=lambda x: (x["F_ext"], x["P_in"], -x["R_post_off"]))
    best = sorted(rows, key=lambda x: (x["retention_time"], x["R_post_off"], x["R_final"]), reverse=True)

    def write_csv(name, data):
        if not data:
            return
        with (out / name).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(data[0].keys()))
            writer.writeheader()
            writer.writerows(data)

    write_csv("all_results.csv", rows)
    write_csv("retained_candidates.csv", retained_sorted[:50])
    write_csv("best_retention.csv", best[:50])

    (out / "retained_candidates.json").write_text(json.dumps(retained_sorted[:50], indent=2), encoding="utf-8")
    (out / "best_retention.json").write_text(json.dumps(best[:50], indent=2), encoding="utf-8")

    print("RETAINED TOP 10")
    print(json.dumps(retained_sorted[:10], indent=2))
    print("BEST RETENTION TOP 10")
    print(json.dumps(best[:10], indent=2))

if __name__ == "__main__":
    main()
