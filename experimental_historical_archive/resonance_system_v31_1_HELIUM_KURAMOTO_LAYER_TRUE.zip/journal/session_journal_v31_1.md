# Session Journal — v31.1

## Step

v31.1 — Helium Kuramoto Coupling Layer.

## Reason

After v31 helium plasma profile, we add a phase-coherence layer to test whether helium can reach Kuramoto phase lock.

## Added

- helium acoustic anchor
- baseline/resonance/off-resonance/pulsed/noisy-drift/retention-off scenarios
- R(t) to C(t) to W_coh chain
- retention after drive removal

## Core Principle

Helium has faster response but stronger drift sensitivity than argon.
