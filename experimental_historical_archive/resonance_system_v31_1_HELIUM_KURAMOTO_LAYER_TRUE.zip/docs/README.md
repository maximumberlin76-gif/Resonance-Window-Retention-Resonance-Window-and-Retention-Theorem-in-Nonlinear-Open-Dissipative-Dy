# v31.1 — Helium Kuramoto Coupling Layer

## Abstract

This module adds a Kuramoto phase-coherence layer to the helium plasma resonance-window profile.

The system is treated strictly as a nonlinear dissipative open dynamic system.

Helium is expected to respond faster than argon but also to show stronger drift sensitivity and weaker retention after drive removal.

This is a computational sandbox, not laboratory evidence.

## Core Chain

```text
Kuramoto R(t)
→ phase coherence
→ C(t)
→ W_coh(τ)
→ resonance window Ω(t)
```

## Kuramoto Order Parameter

```text
R = |(1/N) Σ exp(i φ_j)|
```

## Tested Scenarios

- baseline
- resonance
- off_resonance
- pulsed
- noisy_drift
- retention_off

## Run

```bash
python scripts/engine_v31_1_helium_kuramoto.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/helium_kuramoto_summary.json
results/helium_kuramoto_trials.json
journal/session_journal_v31_1.md
```

## Next Step

v31.2 — Helium phase-lock calibration.
