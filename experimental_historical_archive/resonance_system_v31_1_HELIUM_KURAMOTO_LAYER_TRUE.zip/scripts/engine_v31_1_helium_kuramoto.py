#!/usr/bin/env python3
"""
v31.1 TRUE HELIUM KURAMOTO COUPLING LAYER

Purpose:
Add a Kuramoto phase-coherence layer to the helium plasma resonance-window profile.

System class:
nonlinear dissipative open dynamic systems

Important:
This is a computational sandbox, not a laboratory measurement.

Core chain:
Kuramoto R(t) -> phase coherence -> C(t) -> W_coh(τ) -> resonance window Ω(t)

Helium expectation:
- faster phase response than argon
- stronger drift sensitivity
- weaker retention after drive removal
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def order_parameter(phases):
    re = sum(math.cos(p) for p in phases) / len(phases)
    im = sum(math.sin(p) for p in phases) / len(phases)
    return math.sqrt(re * re + im * im), math.atan2(im, re)

def scenario_params(name, cfg):
    base = dict(cfg["kuramoto"]["base"])

    if name == "baseline":
        base.update({"F_ext": 0.0, "detune": 0.0, "pulse": False, "noise_mult": 1.0, "drive_off_at": None})
    elif name == "resonance":
        base.update({"F_ext": 0.24, "detune": 0.0, "pulse": False, "noise_mult": 1.0, "drive_off_at": None})
    elif name == "off_resonance":
        base.update({"F_ext": 0.24, "detune": 0.22, "pulse": False, "noise_mult": 1.0, "drive_off_at": None})
    elif name == "pulsed":
        base.update({"F_ext": 0.30, "detune": 0.0, "pulse": True, "duty": 0.38, "noise_mult": 1.0, "drive_off_at": None})
    elif name == "noisy_drift":
        base.update({"F_ext": 0.28, "detune": 0.10, "pulse": True, "duty": 0.40, "noise_mult": 2.4, "drift_mult": 2.5, "drive_off_at": None})
    elif name == "retention_off":
        base.update({"F_ext": 0.30, "detune": 0.0, "pulse": True, "duty": 0.45, "noise_mult": 1.0, "drive_off_at": int(cfg["simulation"]["steps"] * 0.55)})
    else:
        raise ValueError(name)

    return base

def simulate(seed, scenario, cfg):
    rng = random.Random(seed)

    N = cfg["kuramoto"]["N"]
    steps = cfg["simulation"]["steps"]
    dt = cfg["simulation"]["dt"]
    period_steps = cfg["simulation"]["period_steps"]

    p = scenario_params(scenario, cfg)

    omega0 = cfg["helium"]["acoustic_anchor_mhz"]
    omega_ext = omega0 * (1.0 + p.get("detune", 0.0))

    phases = [rng.uniform(-math.pi, math.pi) for _ in range(N)]
    natural = [rng.gauss(omega0, cfg["kuramoto"]["omega_sigma_mhz"]) for _ in range(N)]

    C = rng.uniform(0.32, 0.48)
    W_coh = 0.0
    theta = 0.0
    stable_periods = 0
    period_work = 0.0
    period_theta = 0.0
    convergence_time = None
    R_max = 0.0
    R_post_off = None
    sampled = []

    for t in range(steps):
        time = t * dt

        drive_active = True
        if p.get("drive_off_at") is not None and t >= p["drive_off_at"]:
            drive_active = False

        pulse_gate = 1.0
        if p.get("pulse", False):
            pulse_gate = 1.0 if (t % period_steps) < int(period_steps * p.get("duty", 0.5)) else 0.0

        F = p["F_ext"] * pulse_gate * (1.0 if drive_active else 0.0)

        R_now, psi = order_parameter(phases)
        omega_time = 2 * math.pi * omega_ext * time

        new_phases = []
        for i, phi in enumerate(phases):
            coupling = p["K"] * R_now * math.sin(psi - phi)
            external = F * math.sin(omega_time - phi)
            noise = rng.gauss(0.0, cfg["kuramoto"]["noise"] * p.get("noise_mult", 1.0))
            drift = cfg["kuramoto"]["omega_drift"] * p.get("drift_mult", 1.0) * math.sin(2 * math.pi * t / max(1, steps))
            dphi = (natural[i] + drift + coupling + external) * dt + noise
            new_phases.append((phi + dphi + math.pi) % (2 * math.pi) - math.pi)

        phases = new_phases

        R, _ = order_parameter(phases)
        R_max = max(R_max, R)

        if convergence_time is None and R >= cfg["thresholds"]["R_lock"]:
            convergence_time = time

        if p.get("drive_off_at") is not None and t == p["drive_off_at"]:
            R_post_off = R

        det = abs(p.get("detune", 0.0))
        P = cfg["balance"]["P_base"] + cfg["balance"]["P_detune"] * det
        D = cfg["balance"]["D_base"] + cfg["balance"]["D_noise"] * p.get("noise_mult", 1.0)

        useful_work_step = max(0.0, R - cfg["thresholds"]["R_work_floor"]) * F * cfg["balance"]["work_gain"]
        W_coh += useful_work_step

        C = clamp(C + cfg["balance"]["C_gain"] * (R - C) + useful_work_step - 0.010 * P - 0.010 * D)

        delta = C - P - D

        if delta > 0:
            theta += delta
            period_theta += delta
            period_work += useful_work_step

        if (t + 1) % period_steps == 0:
            if period_theta >= cfg["thresholds"]["period_theta_min"] and period_work >= cfg["thresholds"]["period_work_min"]:
                stable_periods += 1
            period_theta = 0.0
            period_work = 0.0

        if t % cfg["simulation"]["sample_every"] == 0 or t == steps - 1:
            sampled.append({
                "step": t,
                "time": time,
                "scenario": scenario,
                "R": R,
                "C": C,
                "W_coh": W_coh,
                "theta": theta,
                "F_effective": F,
                "drive_active": drive_active,
                "P": P,
                "D": D,
                "delta": delta
            })

    tail = sampled[int(len(sampled) * 0.75):]
    retention_R_tail = mean([x["R"] for x in tail])
    R_final = sampled[-1]["R"]
    C_final = sampled[-1]["C"]

    if R_final >= cfg["thresholds"]["R_lock"] and stable_periods >= cfg["thresholds"]["synthesis_min_periods"]:
        outcome = "helium_kuramoto_resonance_window_candidate"
    elif R_final >= cfg["thresholds"]["R_lock"]:
        outcome = "phase_locked_but_incomplete_accumulation"
    elif R_max >= cfg["thresholds"]["R_lock"] and retention_R_tail < cfg["thresholds"]["R_lock"]:
        outcome = "transient_lock_no_retention"
    else:
        outcome = "no_phase_lock"

    return {
        "seed": seed,
        "scenario": scenario,
        "R_final": R_final,
        "R_max": R_max,
        "C_final": C_final,
        "W_coh": W_coh,
        "theta": theta,
        "stable_periods": stable_periods,
        "convergence_time": convergence_time,
        "R_post_off": R_post_off,
        "retention_R_tail": retention_R_tail,
        "outcome": outcome,
        "series_sampled": sampled
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    rows = []

    for sidx, scenario in enumerate(cfg["scenarios"]):
        for i in range(cfg["trials_per_scenario"]):
            rows.append(simulate(cfg["seed"] + sidx * 10000 + i * 100, scenario, cfg))

    outcomes = {}
    by_scenario = {}
    for r in rows:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1
        by_scenario.setdefault(r["scenario"], []).append(r)

    scenario_summary = {}
    for scenario, items in by_scenario.items():
        scenario_summary[scenario] = {
            "count": len(items),
            "mean_R_final": mean([x["R_final"] for x in items]),
            "mean_R_max": mean([x["R_max"] for x in items]),
            "mean_C_final": mean([x["C_final"] for x in items]),
            "mean_W_coh": mean([x["W_coh"] for x in items]),
            "mean_stable_periods": mean([x["stable_periods"] for x in items]),
            "mean_convergence_time": mean([x["convergence_time"] for x in items if x["convergence_time"] is not None]) if any(x["convergence_time"] is not None for x in items) else None,
            "mean_retention_R_tail": mean([x["retention_R_tail"] for x in items if x["retention_R_tail"] is not None]) if any(x["retention_R_tail"] is not None for x in items) else None,
            "outcomes": {k: sum(1 for x in items if x["outcome"] == k) for k in sorted(set(x["outcome"] for x in items))}
        }

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "helium_reference": {
            "acoustic_anchor_mhz": cfg["helium"]["acoustic_anchor_mhz"],
            "note": "Kuramoto phase model, not laboratory measurement."
        },
        "trials": len(rows),
        "outcomes": outcomes,
        "scenario_summary": scenario_summary,
        "main_conclusion": "helium_kuramoto_layer_tests_fast_phase_response_and_drift_sensitivity",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"helium_kuramoto_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"helium_kuramoto_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": len(rows),
        "outcomes": outcomes,
        "scenario_summary": scenario_summary,
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
