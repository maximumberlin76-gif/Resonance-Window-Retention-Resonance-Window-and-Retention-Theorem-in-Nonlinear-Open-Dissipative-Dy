# Session Journal — v30.3

## Step

v30.3 — Argon Work-Accumulation Recheck.

## Reason

After v33.2, all gases must use the same strict criterion:
phase lock + accumulated positive structural work over completed periods + retention.

## Added

- W_period
- theta_work
- stable positive work periods
- false lock rejection
- retention_R_tail criterion

## Core Principle

Argon was expected to remain relatively clean because its heavier structure gives stronger retention.
