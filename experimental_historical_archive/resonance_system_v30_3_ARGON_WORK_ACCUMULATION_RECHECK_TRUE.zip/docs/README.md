# v30.3 — Argon Work-Accumulation Recheck

## Abstract

This module rechecks argon phase-lock calibration using the stricter work-accumulation criterion introduced after v33.2.

The system is treated strictly as a nonlinear dissipative open dynamic system.

The key correction is:

```text
R > 0.7 alone is not a resonance window.
```

A resonance window requires positive structural coherent work accumulated over completed periods.

This is a computational sandbox, not laboratory evidence.

## Core Formula

```text
W_period(k) =
∫ over period k max(0, R(t) - R_floor) · F_ext(t) dt
```

Accumulated work:

```text
Θ_N = Σ W_period(k)
```

## Candidate Rule

```text
R_final >= R_lock
and
stable_work_periods >= synthesis_min_periods
and
Θ_N >= Θ_work_crit
and
retention_R_tail >= R_retention_min
```

## System Class

```text
nonlinear dissipative open dynamic systems
```

## Run

```bash
python scripts/engine_v30_3_argon_work_accumulation_recheck.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/argon_work_accumulation_recheck_summary.json
results/argon_work_accumulation_recheck_trials.json
journal/session_journal_v30_3.md
```

## Next Step

v31.3 — Helium work-accumulation recheck.
