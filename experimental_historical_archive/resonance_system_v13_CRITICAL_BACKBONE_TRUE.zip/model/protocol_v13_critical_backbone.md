# v13 Critical Backbone Protocol

## Objective

Find the minimal viable backbone of the resonance-mode network.

## Procedure

1. Load invariant modes from the previous layer.
2. Build all pairwise mode compatibility edges.
3. Compute edge score.
4. Sweep thresholds:
   0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.825, 0.85, 0.875, 0.90, 0.925, 0.95, 0.975.
5. Detect the critical threshold:
   highest threshold where largest_component_fraction >= 0.5.
6. Build the graph at this threshold.
7. Prune weakest edges until the giant component drops below survival threshold.
8. Calculate fragility index.
9. Remove nodes one by one and measure critical-node impact.
10. Export JSON and CSV logs.

## Rule

If there is no giant component at strict thresholds, the network is not structurally mature.
