# v13 Equations

## Edge Score

edge_score =
0.55 * harmonic_score
+ 0.15 * phase_compatibility
+ 0.20 * retention_strength
+ 0.10 * frequency_distance_penalty

## Giant Component Fraction

largest_fraction = largest_component_size / node_count

## Critical Threshold

critical_threshold =
max(threshold) where largest_fraction >= 0.5

## Fragility Index

fragility_index =
removed_edges_before_break / total_critical_edges

## Critical Node Drop

drop_i =
base_largest_component - largest_component_after_removing_node_i
