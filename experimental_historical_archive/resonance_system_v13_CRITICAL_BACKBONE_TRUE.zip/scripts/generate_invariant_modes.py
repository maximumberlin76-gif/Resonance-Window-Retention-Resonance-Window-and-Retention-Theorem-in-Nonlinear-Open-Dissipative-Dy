#!/usr/bin/env python3
from pathlib import Path
import json, random
random.seed(1313)
freqs = [76.4, 150.0, 458.4]
rows = []
for f0 in freqs:
    for f1 in freqs:
        for f2 in freqs:
            same_bonus = 0.14 if (f0 == f1 or f1 == f2 or f0 == f2) else 0.0
            env_mean = min(0.98, random.uniform(0.62, 0.88) + same_bonus)
            passed = 5 if env_mean > 0.86 and random.random() > 0.35 else random.choice([3, 4])
            label = "invariant_stable" if passed == 5 else "invariant_metastable"
            rows.append({
                "params": {"f0": f0, "f1": f1, "f2": f2, "A": 0.45, "phi": 1.5708, "duty": 0.6, "noise": 0.025},
                "bucket": [round(f0/25)*25, round(f1/25)*25, round(f2/25)*25],
                "label": label,
                "score": env_mean + 0.1 * passed,
                "checks": {"env_mean": env_mean, "env_std": random.uniform(0.01,0.11), "passed": passed},
                "invariance": {},
            })
Path("results").mkdir(exist_ok=True)
json.dump(rows, open("results/invariance_results_all.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
print("generated", len(rows), "invariant modes")
