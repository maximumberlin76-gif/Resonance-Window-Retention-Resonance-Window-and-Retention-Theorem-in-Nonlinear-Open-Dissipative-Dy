#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, math
from pathlib import Path
from itertools import combinations
from collections import deque

TARGET_RATIOS = [1.0, 2.0, 3.0, 0.5, 1.0/3.0, 7.0, 1.0/7.0]

def load_modes(path):
    rows = json.load(open(path, "r", encoding="utf-8"))
    return [r for r in rows if r.get("label") in ("invariant_stable", "invariant_metastable")]

def retention_strength(mode):
    return float(mode.get("checks", {}).get("env_mean", 0.0))

def phase_compatibility(a, b):
    pa = float(a["params"].get("phi", 0.0))
    pb = float(b["params"].get("phi", 0.0))
    return (1.0 + math.cos(pa - pb)) / 2.0

def harmonic_score(a, b, eps=0.045):
    fa = [float(a["params"]["f0"]), float(a["params"]["f1"]), float(a["params"]["f2"])]
    fb = [float(b["params"]["f0"]), float(b["params"]["f1"]), float(b["params"]["f2"])]
    hits = 0
    total = 0
    for x in fa:
        for y in fb:
            if x <= 0 or y <= 0:
                continue
            ratio = max(x, y) / min(x, y)
            total += 1
            if any(abs(ratio - t) / t <= eps for t in TARGET_RATIOS):
                hits += 1
    return hits / max(1, total)

def frequency_distance_penalty(a, b):
    pa, pb = a["params"], b["params"]
    d = (abs(float(pa["f0"])-float(pb["f0"])) + abs(float(pa["f1"])-float(pb["f1"])) + abs(float(pa["f2"])-float(pb["f2"]))) / 3.0
    return 1.0 / (1.0 + d / 150.0)

def edge_score(a, b):
    h = harmonic_score(a, b)
    ph = phase_compatibility(a, b)
    r = (retention_strength(a) + retention_strength(b)) / 2.0
    d = frequency_distance_penalty(a, b)
    score = 0.55*h + 0.15*ph + 0.20*r + 0.10*d
    return {"score": score, "harmonic": h, "phase": ph, "retention": r, "distance_penalty": d}

def build_all_edges(modes):
    edges = []
    for i, j in combinations(range(len(modes)), 2):
        s = edge_score(modes[i], modes[j])
        edges.append({"i": i, "j": j, **s})
    edges.sort(key=lambda e: e["score"], reverse=True)
    return edges

def filter_edges(edges, threshold):
    return [e for e in edges if float(e["score"]) >= threshold]

def build_adj(n, edges, removed_nodes=None, removed_edges=None):
    removed_nodes = removed_nodes or set()
    removed_edges = removed_edges or set()
    g = [set() for _ in range(n)]
    for idx, e in enumerate(edges):
        if idx in removed_edges:
            continue
        i, j = int(e["i"]), int(e["j"])
        if i in removed_nodes or j in removed_nodes:
            continue
        g[i].add(j)
        g[j].add(i)
    return g

def component_sizes(n, edges, removed_nodes=None, removed_edges=None):
    removed_nodes = removed_nodes or set()
    g = build_adj(n, edges, removed_nodes, removed_edges)
    seen = set()
    sizes = []
    for start in range(n):
        if start in removed_nodes or start in seen:
            continue
        q = deque([start])
        seen.add(start)
        size = 0
        while q:
            x = q.popleft()
            size += 1
            for y in g[x]:
                if y not in seen:
                    seen.add(y)
                    q.append(y)
        sizes.append(size)
    return sorted(sizes, reverse=True)

def degrees(n, edges):
    deg = [0] * n
    for e in edges:
        deg[int(e["i"])] += 1
        deg[int(e["j"])] += 1
    return deg

def threshold_scan(n, all_edges, thresholds):
    rows = []
    for th in thresholds:
        edges = filter_edges(all_edges, th)
        comps = component_sizes(n, edges)
        largest = comps[0] if comps else 0
        deg = degrees(n, edges)
        rows.append({
            "threshold": th,
            "edges": len(edges),
            "mean_degree": sum(deg)/max(1,n),
            "largest_component": largest,
            "largest_fraction": largest/max(1,n),
            "components": len(comps),
            "component_sizes": comps,
            "mean_edge_score": sum(e["score"] for e in edges)/max(1,len(edges)),
        })
    return rows

def find_critical_threshold(scan_rows, min_fraction):
    viable = [r for r in scan_rows if float(r["largest_fraction"]) >= min_fraction]
    return viable[-1] if viable else None

def edge_prune_to_break(n, edges, min_fraction):
    ranked = sorted(list(enumerate(edges)), key=lambda x: x[1]["score"])
    removed = set()
    trace = []
    for idx, edge in ranked:
        removed.add(idx)
        comps = component_sizes(n, edges, removed_edges=removed)
        largest = comps[0] if comps else 0
        frac = largest / max(1, n)
        trace.append({
            "removed_edges": len(removed),
            "removed_edge_index": idx,
            "removed_edge": edge,
            "largest_component": largest,
            "largest_fraction": frac,
            "component_sizes": comps,
        })
        if frac < min_fraction:
            break
    return trace

def critical_node_report(n, edges, modes):
    base_largest = component_sizes(n, edges)[0] if edges else 0
    deg = degrees(n, edges)
    out = []
    for node in range(n):
        comps = component_sizes(n, edges, removed_nodes={node})
        largest_after = comps[0] if comps else 0
        out.append({
            "node": node,
            "degree": deg[node],
            "drop": base_largest - largest_after,
            "largest_after_removal": largest_after,
            "label": modes[node].get("label"),
            "params": modes[node].get("params"),
        })
    return sorted(out, key=lambda x: (x["drop"], x["degree"]), reverse=True)

def targeted_attack_report(n, edges, fraction=0.25):
    deg = degrees(n, edges)
    count = max(1, int(n*fraction))
    removed = set(sorted(range(n), key=lambda i: deg[i], reverse=True)[:count])
    comps = component_sizes(n, edges, removed_nodes=removed)
    largest = comps[0] if comps else 0
    return {"removed_nodes": sorted(removed), "removed_fraction": fraction, "largest_component": largest, "largest_fraction_of_remaining": largest/max(1,n-len(removed)), "component_sizes": comps}

def save_csv(path, rows, fieldnames):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k) for k in fieldnames})

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="results/invariance_results_all.json")
    parser.add_argument("--outdir", default="results")
    parser.add_argument("--min-fraction", type=float, default=0.50)
    args = parser.parse_args()

    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    Path("logs").mkdir(parents=True, exist_ok=True)

    modes = load_modes(args.input)
    n = len(modes)
    all_edges = build_all_edges(modes)
    thresholds = [0.55,0.60,0.65,0.70,0.75,0.80,0.825,0.85,0.875,0.90,0.925,0.95,0.975]
    scan = threshold_scan(n, all_edges, thresholds)
    critical = find_critical_threshold(scan, args.min_fraction)
    crit_edges = filter_edges(all_edges, critical["threshold"]) if critical else []

    prune_trace = edge_prune_to_break(n, crit_edges, args.min_fraction) if crit_edges else []
    critical_nodes = critical_node_report(n, crit_edges, modes) if crit_edges else []
    targeted_attack = targeted_attack_report(n, crit_edges) if crit_edges else None

    fragility_index = prune_trace[-1]["removed_edges"] / max(1, len(crit_edges)) if prune_trace and crit_edges else None

    graph = {
        "nodes": modes,
        "all_edges_count": len(all_edges),
        "critical_threshold": critical["threshold"] if critical else None,
        "critical_edges": crit_edges,
    }
    summary = {
        "nodes": n,
        "all_edges": len(all_edges),
        "threshold_scan": scan,
        "critical_threshold": critical["threshold"] if critical else None,
        "critical_edges": len(crit_edges),
        "critical_largest_fraction": critical["largest_fraction"] if critical else None,
        "fragility_index": fragility_index,
        "edge_prune_break_trace": prune_trace,
        "critical_nodes_top10": critical_nodes[:10],
        "targeted_attack": targeted_attack,
        "label": "critical_backbone_found" if critical else "no_viable_backbone",
    }
    json.dump(graph, open(out/"critical_backbone_graph.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(summary, open(out/"critical_backbone_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    save_csv(Path("logs")/"threshold_scan.csv", scan, ["threshold","edges","mean_degree","largest_component","largest_fraction","components","mean_edge_score"])
    node_rows = [{"node": x["node"], "degree": x["degree"], "drop": x["drop"], "largest_after_removal": x["largest_after_removal"], "label": x["label"], "f0": x["params"]["f0"], "f1": x["params"]["f1"], "f2": x["params"]["f2"]} for x in critical_nodes]
    save_csv(Path("logs")/"critical_nodes.csv", node_rows, ["node","degree","drop","largest_after_removal","label","f0","f1","f2"])

    print(json.dumps({"critical_threshold": summary["critical_threshold"], "critical_edges": summary["critical_edges"], "fragility_index": summary["fragility_index"], "label": summary["label"]}, indent=2))

if __name__ == "__main__":
    main()
