# Resonance System v13 TRUE CRITICAL BACKBONE

## Purpose

This package contains the full v13 critical-backbone layer.

This is not a one-line placeholder and not a reduced top-mode summary.  
It stores the real backbone machinery:

- compatibility graph construction
- full threshold scan
- critical threshold detection
- edge-prune-to-break trace
- fragility index
- critical node report
- graph JSON
- summary JSON
- CSV logs
- checksums and validation report

## Conceptual Meaning

v11 showed that a network of invariant modes can exist.  
v12 showed that a sparse network can remain resilient.  
v13 asks the harder question:

```text
Where is the last viable backbone before structural collapse?
```

The useful engineering boundary is not the strongest graph.  
It is the weakest graph that still lives.

## Method

1. Generate or load invariant modes.
2. Build all pairwise compatibility edges.
3. Score each edge using:
   - harmonic relation
   - phase compatibility
   - retention strength
   - frequency-distance penalty
4. Scan thresholds from 0.55 to 0.975.
5. Find the highest threshold where the giant component is still at least 50%.
6. At that critical threshold:
   - remove weakest edges until collapse
   - calculate fragility index
   - identify critical nodes
   - export critical graph and summary

## Run

```bash
python scripts/generate_invariant_modes.py
python scripts/engine_v13_critical_backbone.py --input results/invariance_results_all.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/invariance_results_all.json
results/critical_backbone_graph.json
results/critical_backbone_summary.json
logs/threshold_scan.csv
logs/critical_nodes.csv
checksums/sha256_manifest.txt
validation/triple_validation_summary.json
```

## Interpretation

- `critical_backbone_found`: a viable critical backbone exists.
- `critical_threshold`: highest edge threshold where the network still keeps a giant component.
- `fragility_index`: fraction of critical edges that can be removed before the giant component breaks.
- `critical_nodes_top10`: nodes whose removal causes the largest structural drop.

## Limitation

This remains a computational sandbox.  
It validates topology and protocol logic, not physical transmutation or material synthesis.
