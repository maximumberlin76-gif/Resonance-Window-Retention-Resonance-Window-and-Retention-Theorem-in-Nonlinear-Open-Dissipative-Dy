#!/usr/bin/env python3
from pathlib import Path
import json
required = [
    "scripts/engine_v13_critical_backbone.py",
    "scripts/generate_invariant_modes.py",
    "results/critical_backbone_graph.json",
    "results/critical_backbone_summary.json",
    "results/invariance_results_all.json",
    "docs/README.md",
    "model/protocol_v13_critical_backbone.md",
    "model/equations_v13.md",
]
for item in required:
    p = Path(item)
    assert p.exists(), f"missing: {item}"
    assert p.stat().st_size > 100, f"too small: {item}"
summary = json.load(open("results/critical_backbone_summary.json", "r", encoding="utf-8"))
for k in ["threshold_scan", "critical_threshold", "edge_prune_break_trace", "fragility_index"]:
    assert k in summary, f"missing key: {k}"
print("SMOKE_OK")
