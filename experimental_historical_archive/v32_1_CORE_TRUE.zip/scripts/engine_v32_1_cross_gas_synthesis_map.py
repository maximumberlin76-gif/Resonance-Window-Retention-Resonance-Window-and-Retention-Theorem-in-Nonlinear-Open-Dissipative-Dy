#!/usr/bin/env python3
# v32.1 compact map builder.
# See results/cross_gas_synthesis_map_summary.json for generated output.
print("v32.1 compact map package: use configs/config.json and results/*.json")
