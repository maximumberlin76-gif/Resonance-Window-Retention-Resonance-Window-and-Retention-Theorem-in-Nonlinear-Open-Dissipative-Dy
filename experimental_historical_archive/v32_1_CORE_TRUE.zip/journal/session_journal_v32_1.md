# Session Journal — v32.1

Cross-Gas Synthesis Map.

R is an indicator.
Θ_N is the admission criterion.
Retention completes the window.

Result is a compact corrected comparison of Ar, He, H.
