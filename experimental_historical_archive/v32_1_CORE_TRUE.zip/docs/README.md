# v32.1 — Cross-Gas Synthesis Map

## Abstract

Cross-gas synthesis map for argon, helium, and hydrogen using the strict work-accumulation criterion.

System class:

```text
nonlinear dissipative open dynamic systems
```

Corrected inputs:

- v30.3 — Argon Work-Accumulation Recheck
- v31.3 — Helium Work-Accumulation Recheck
- v33.2 — Hydrogen Work-Accumulation Calibration

## Core Principle

```text
R is an indicator.
Θ_N is the admission criterion.
```

A valid resonance-window candidate requires accumulated positive structural work over completed periods, positive C−P balance, and retention after external drive removal.

## Method

```text
f_norm = f / f_anchor
```

Full overlap means possible class-level Ω*.  
Partial/no overlap means Ω(t) must include medium parameter μ_env.
