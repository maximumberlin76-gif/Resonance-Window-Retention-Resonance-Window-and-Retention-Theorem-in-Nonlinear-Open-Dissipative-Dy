# v32.1 Equations

f_norm = f / f_anchor

valid_window =
Θ_N >= Θ_crit
and
(C - P)_periodic > 0
and
retention holds

Partial/no overlap:
Ω(t) must include medium parameter μ_env.
