#!/usr/bin/env python3
from pathlib import Path
import json
p=Path("results/cross_gas_synthesis_map_summary.json")
assert p.exists() and p.stat().st_size > 100
s=json.load(open(p,"r",encoding="utf-8"))
assert s["system_class"]=="nonlinear dissipative open dynamic systems"
print("SMOKE_OK")
