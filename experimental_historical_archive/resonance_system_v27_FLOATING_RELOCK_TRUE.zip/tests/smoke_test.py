#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v27_floating_relock.py","results/floating_relock_summary.json","results/floating_relock_trials.json","docs/README.md"]:
    fp=Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s=json.load(open("results/floating_relock_summary.json","r",encoding="utf-8"))
assert "mean_strong_drift_ratio" in s and "all_trials" in s
print("SMOKE_OK")
