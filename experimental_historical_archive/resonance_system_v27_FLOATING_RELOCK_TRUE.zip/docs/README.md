# Resonance System v27 TRUE FLOATING RE-LOCK COMPENSATION

## Purpose

A resonance window in a nonlinear dissipative dynamic structure is never fully stationary.

It is either:

```text
quasi-stationary
```

or

```text
strong-drift
```

v27 therefore adds a window-type classifier and two different re-lock strategies.

## Key Correction

```text
If the window floats, re-lock must float.
If drift is strong, re-lock must follow drift aggressively.
If drift is quasi-stationary, re-lock must remain narrow and gentle.
```

## Added

- window type classifier
- quasi-stationary re-lock profile
- strong-drift re-lock profile
- anchor(t)
- drift-following freeze
- drift-compensated spiral
- moving corridor confirmation

## Run

```bash
python scripts/engine_v27_floating_relock.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/floating_relock_summary.json
results/floating_relock_trials.json
validation/triple_validation_summary.json
journal/session_journal_v27.md
```

## Limitation

Computational sandbox only.
