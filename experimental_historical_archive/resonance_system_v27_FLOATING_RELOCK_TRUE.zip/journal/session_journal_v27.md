# Session Journal — v27

## Step

v27 — Floating Re-lock Compensation with window-type classification.

## User correction

There are no fully stationary resonance windows in a nonlinear dissipative dynamic structure.
Only quasi-stationary windows and windows with pronounced drift.

## Added

- quasi_stationary / strong_drift classifier
- separate re-lock profiles
- drift-following anchor(t)
- drift-compensated spiral
- moving corridor confirmation

## Core Principle

Re-lock must match the window type.

## Next Candidate Step

v28 — compare quasi vs strong-drift profile performance separately and tune each profile.
