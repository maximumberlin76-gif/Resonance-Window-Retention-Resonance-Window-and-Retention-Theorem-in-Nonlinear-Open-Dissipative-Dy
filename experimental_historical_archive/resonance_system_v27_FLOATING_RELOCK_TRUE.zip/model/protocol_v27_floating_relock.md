# v27 Floating Re-lock Protocol

1. Simulate adversarial floating window.
2. Estimate drift.
3. Classify window:
   - quasi_stationary
   - strong_drift
4. Select matching re-lock profile.
5. Enter re-lock:
   - freeze prediction only
   - update anchor(t)
   - spiral with drift compensation
   - confirm within moving corridor
   - return gradually
6. Measure stability and collapse.
