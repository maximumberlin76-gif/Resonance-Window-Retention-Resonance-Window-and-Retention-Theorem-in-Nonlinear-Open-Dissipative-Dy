# v27 Equations

window_type =
strong_drift if |drift_est| / |center| >= threshold
else quasi_stationary

anchor(t+1) =
(1-alpha)*anchor(t) + alpha*(observed + lead*drift_est)

corridor(t) =
base + min(extra, |drift_est| / |center| * gain)

S_floating_relock =
mean_C
- var_C
- 0.45*tracking_error
- 0.35*lock_loss
- 0.25*damage_per_cycle
+ 0.18*relock_success_rate
+ 0.10*shock_recovery_rate
+ 0.06*strong_drift_ratio
