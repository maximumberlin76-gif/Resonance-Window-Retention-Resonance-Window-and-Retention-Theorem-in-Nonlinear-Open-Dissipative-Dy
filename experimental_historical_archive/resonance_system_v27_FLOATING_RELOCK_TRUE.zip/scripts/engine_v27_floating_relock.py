#!/usr/bin/env python3
"""
Resonance System v27 TRUE FLOATING RE-LOCK COMPENSATION

Core correction:
A resonance window in a nonlinear dissipative dynamic structure is never fully stationary.
It is either:
- quasi-stationary: low drift, corridor can remain narrow
- strong-drift: clear temporal drift, corridor/re-lock must follow actively

v27 implements:
- window type classifier
- quasi-stationary re-lock profile
- strong-drift re-lock profile
- anchor(t)
- drift-following freeze
- drift-compensated spiral
- moving corridor confirmation

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def heavy_noise(rng, base, p, scale):
    return rng.uniform(-base*scale, base*scale) if rng.random() < p else rng.uniform(-base, base)

def classify_window(drift_est, center, cfg):
    rel = abs(drift_est) / max(1.0, abs(center))
    if rel >= cfg["window_type"]["strong_drift_threshold"]:
        return "strong_drift"
    return "quasi_stationary"

def detect_relock(tracking, confidence, false_damage_step, fallback_streak, rp):
    return (
        tracking > rp["tracking_enter"]
        or confidence < rp["confidence_enter"]
        or false_damage_step > rp["false_damage_enter"]
        or fallback_streak >= rp["fallback_streak_enter"]
    )

def update_floating_anchor(state, observed, drift_est, rp):
    target = observed + rp["anchor_drift_lead"] * drift_est
    state["anchor"] = (1.0 - rp["anchor_alpha"]) * state["anchor"] + rp["anchor_alpha"] * target

def floating_corridor(cfg, drift_est, center, wtype):
    base = cfg["floating"]["base_corridor"]
    if wtype == "strong_drift":
        extra = cfg["floating"]["strong_extra_corridor"]
        gain = cfg["floating"]["strong_corridor_gain"]
    else:
        extra = cfg["floating"]["quasi_extra_corridor"]
        gain = cfg["floating"]["quasi_corridor_gain"]
    return base + min(extra, abs(drift_est)/max(1.0, abs(center))*gain)

def relock_control(state, true_center, observed, drift_est, cfg, rp, wtype):
    phase = state["phase"]
    f0 = state["f0"]

    update_floating_anchor(state, observed, drift_est, rp)
    anchor = state["anchor"]
    corridor = floating_corridor(cfg, drift_est, anchor, wtype)

    if phase == "freeze":
        # Freeze prediction only, not movement. Still weakly follows anchor.
        control = rp["freeze_drift_gain"] * (anchor - f0)
        state["ticks"] += 1
        if state["ticks"] >= rp["freeze_steps"]:
            state["phase"] = "anchor"
            state["ticks"] = 0

    elif phase == "anchor":
        control = rp["anchor_gain"] * (anchor - f0)
        state["ticks"] += 1
        if abs(anchor - f0)/max(1.0,abs(anchor)) < rp["anchor_tolerance"] or state["ticks"] >= rp["anchor_max_steps"]:
            state["phase"] = "spiral"
            state["ticks"] = 0

    elif phase == "spiral":
        dither = rp["dither_amp"] * math.sin(state["ticks"] * rp["dither_rate"])
        moving_target = anchor + rp["spiral_drift_gain"] * drift_est
        control = rp["spiral_gain"] * (moving_target - f0) + dither
        state["ticks"] += 1
        predicted_tracking = abs(true_center - (f0 + control)) / max(1.0, abs(true_center))
        if predicted_tracking < max(rp["lock_candidate_error"], corridor):
            state["phase"] = "confirm"
            state["ticks"] = 0
            state["confirm"] = 1

    elif phase == "confirm":
        moving_target = anchor + rp["confirm_drift_gain"] * drift_est
        control = rp["confirm_gain"] * (moving_target - f0)
        predicted_tracking = abs(true_center - (f0 + control)) / max(1.0, abs(true_center))
        if predicted_tracking < max(rp["confirm_error"], corridor):
            state["confirm"] += 1
        else:
            state["confirm"] = 0
            state["phase"] = "spiral"
            state["ticks"] = 0
        if state["confirm"] >= rp["confirm_steps"]:
            state["phase"] = "return"
            state["ticks"] = 0

    else:
        moving_target = anchor + rp["return_drift_gain"] * drift_est
        control = rp["return_gain"] * (moving_target - f0)
        state["ticks"] += 1
        if state["ticks"] >= rp["return_steps"]:
            state["mode"] = "model"
            state["phase"] = None
            state["ticks"] = 0
            state["confirm"] = 0

    max_control = abs(true_center) * rp["max_control_ratio"]
    return clamp(control, -max_control, max_control), corridor

def model_control(f0, predicted, confidence, cfg, force_fallback=False):
    err = predicted - f0
    if force_fallback or confidence < cfg["model"]["min_confidence"]:
        ratio = cfg["fallback"]["max_delta_ratio"]
        kp = cfg["fallback"]["kp"]
    else:
        ratio = cfg["model"]["max_control_ratio"]
        kp = cfg["model"]["kp"]
    max_control = abs(predicted) * ratio
    return clamp(kp*err, -max_control, max_control)

def run_trial(seed, cfg):
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    true_center = rng.choice([76.4,150.0,458.4])
    f0 = true_center
    C = rng.uniform(0.70,0.92)

    history = [true_center]
    latency = [true_center] * cfg["adversarial"]["latency_steps"]

    state = {"mode":"model","phase":None,"ticks":0,"confirm":0,"anchor":true_center,"f0":f0}
    fallback_streak = 0
    relock_entries = 0
    relock_success = 0
    relock_times = []
    relock_start = None

    lock_loss = 0
    false_damage = 0.0
    shock_events = 0
    shock_recovered = 0
    shock_start = None
    collapsed = False
    collapse_at = None
    type_counts = {"quasi_stationary":0, "strong_drift":0}
    series = []

    for t in range(cycles):
        drift = cfg["floating"]["drift_rate"] * math.sin(2*math.pi*t/cfg["floating"]["period"])
        noise = heavy_noise(rng, cfg["noise"], cfg["adversarial"]["heavy_tail_prob"], cfg["adversarial"]["tail_scale"])
        true_center += drift + noise

        jump = 0.0
        if rng.random() < cfg["adversarial"]["jump_prob"]:
            jump = rng.choice([-1,1]) * rng.uniform(cfg["adversarial"]["jump_min"], cfg["adversarial"]["jump_max"])
            true_center += jump
            shock_events += 1
            shock_start = t

        latency.append(true_center)
        observed = latency.pop(0)
        history.append(observed)
        h = history[-cfg["predictor"]["history"]:]
        drift_est = (h[-1]-h[0])/max(1,len(h)-1) if len(h)>1 else 0.0
        wtype = classify_window(drift_est, observed, cfg)
        type_counts[wtype] += 1
        rp = cfg["relock_profiles"][wtype]

        fake = 0.0
        fake_signal = False
        if rng.random() < cfg["adversarial"]["fake_drift_prob"]:
            fake = rng.choice([-1,1]) * rng.uniform(cfg["adversarial"]["fake_drift_min"], cfg["adversarial"]["fake_drift_max"])
            fake_signal = True

        confidence_bias = cfg["adversarial"]["confidence_trap_bias"] if rng.random() < cfg["adversarial"]["confidence_trap_prob"] else 0.0
        predicted = observed + cfg["predictor"]["lead"]*(drift_est+fake)
        confidence = clamp(1.0 - abs(fake)/max(1.0,abs(observed))*cfg["predictor"]["uncertainty_gain"] + confidence_bias)

        tracking_before = abs(true_center-f0)/max(1.0,abs(true_center))
        predicted_tracking = abs(predicted-f0)/max(1.0,abs(predicted))
        false_step = 0.0
        if fake_signal and tracking_before > predicted_tracking:
            false_step = tracking_before - predicted_tracking
            false_damage += false_step

        force_fallback = tracking_before > cfg["fallback"]["force_tracking_error"] or confidence < cfg["model"]["min_confidence"]

        used_relock = False
        relock_corridor = None
        if state["mode"] == "model" and detect_relock(tracking_before, confidence, false_step, fallback_streak, rp):
            state.update({"mode":"relock","phase":"freeze","ticks":0,"confirm":0,"anchor":observed})
            relock_entries += 1
            relock_start = t

        if state["mode"] == "relock":
            state["f0"] = f0
            control, relock_corridor = relock_control(state, true_center, observed, drift_est, cfg, rp, wtype)
            used_relock = True
            fallback_streak = 0
            if state["mode"] == "model" and relock_start is not None:
                relock_success += 1
                relock_times.append(t-relock_start)
                relock_start = None
        else:
            control = model_control(f0, predicted, confidence, cfg, force_fallback)
            fallback_streak = fallback_streak + 1 if force_fallback else 0

        max_control = abs(true_center)*cfg["model"]["absolute_max_control_ratio"]
        control = clamp(control, -max_control, max_control)
        f0 += control
        f1 = 2*f0
        f2 = 0.5*f0

        tracking = abs(true_center-f0)/max(1.0,abs(true_center))
        dyn_corridor = floating_corridor(cfg, drift_est, true_center, wtype)
        corridor = relock_corridor if relock_corridor is not None else dyn_corridor
        in_corridor = tracking <= corridor

        if not in_corridor:
            lock_loss += 1
        if shock_start is not None and in_corridor:
            shock_recovered += 1
            shock_start = None

        D = cfg["dissipation_rate"]*(1+0.010*t)
        repair = cfg["recovery_gain"]*max(0.0,1.0-C)
        lock_support = cfg["floating"]["lock_support"]*(1-tracking) if in_corridor else -cfg["floating"]["lock_penalty"]
        relock_support = rp["support"] if used_relock else 0.0
        drift_support = cfg["window_type"]["strong_drift_support"] if wtype == "strong_drift" else cfg["window_type"]["quasi_support"]
        damage_penalty = cfg["adversarial"]["false_damage_penalty"]*false_step
        C = clamp(C + repair + lock_support + relock_support + drift_support - D - damage_penalty + rng.uniform(-cfg["noise"],cfg["noise"]))

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

        series.append({"t":t,"window_type":wtype,"true_center":true_center,"observed":observed,"predicted":predicted,"drift_est":drift_est,"confidence":confidence,"mode":state["mode"],"phase":state["phase"],"anchor":state["anchor"],"jump":jump,"fake_signal":fake_signal,"f0":f0,"f1":f1,"f2":f2,"tracking_error":tracking,"corridor":corridor,"in_corridor":in_corridor,"false_step":false_step,"C":C,"control":control})

    Cs=[x["C"] for x in series]
    mean_C=mean(Cs)
    var_C=mean([(x-mean_C)**2 for x in Cs])
    mean_tracking=mean([x["tracking_error"] for x in series])
    lock_loss_rate=lock_loss/cycles
    relock_success_rate=relock_success/max(1,relock_entries)
    mean_relock_time=mean(relock_times) if relock_times else None
    shock_recovery_rate=shock_recovered/max(1,shock_events)
    damage_per_cycle=false_damage/cycles
    strong_ratio=type_counts["strong_drift"]/cycles

    S=mean_C-var_C-0.45*mean_tracking-0.35*lock_loss_rate-0.25*damage_per_cycle+0.18*relock_success_rate+0.10*shock_recovery_rate+0.06*strong_ratio

    if collapsed:
        label="floating_relock_collapse"
    elif S>=cfg["thresholds"]["stable"] and relock_success_rate>=cfg["thresholds"]["min_relock_success"]:
        label="floating_relock_stable"
    elif S>=cfg["thresholds"]["metastable"]:
        label="floating_relock_metastable"
    else:
        label="floating_relock_weak"

    return {"seed":seed,"mean_C":mean_C,"var_C":var_C,"mean_tracking_error":mean_tracking,"lock_loss_rate":lock_loss_rate,"relock_entries":relock_entries,"relock_success":relock_success,"relock_success_rate":relock_success_rate,"mean_relock_time":mean_relock_time,"shock_events":shock_events,"shock_recovery_rate":shock_recovery_rate,"false_prediction_damage":false_damage,"damage_per_cycle":damage_per_cycle,"window_type_counts":type_counts,"strong_drift_ratio":strong_ratio,"S_floating_relock":S,"collapsed":collapsed,"collapse_at":collapse_at,"label":label,"series":series}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args=ap.parse_args()
    cfg=json.load(open("configs/config.json","r",encoding="utf-8"))
    rows=[run_trial(cfg["seed"]+i*100,cfg) for i in range(cfg["trials"])]

    stable=[r for r in rows if r["label"]=="floating_relock_stable"]
    meta=[r for r in rows if r["label"]=="floating_relock_metastable"]
    weak=[r for r in rows if r["label"]=="floating_relock_weak"]
    col=[r for r in rows if r["label"]=="floating_relock_collapse"]

    summary={"trials":len(rows),"floating_relock_stable":len(stable),"floating_relock_metastable":len(meta),"floating_relock_weak":len(weak),"floating_relock_collapse":len(col),"mean_S_floating_relock":mean([r["S_floating_relock"] for r in rows]),"mean_tracking_error":mean([r["mean_tracking_error"] for r in rows]),"mean_lock_loss_rate":mean([r["lock_loss_rate"] for r in rows]),"mean_relock_success_rate":mean([r["relock_success_rate"] for r in rows]),"mean_false_prediction_damage":mean([r["false_prediction_damage"] for r in rows]),"mean_damage_per_cycle":mean([r["damage_per_cycle"] for r in rows]),"mean_shock_recovery_rate":mean([r["shock_recovery_rate"] for r in rows]),"mean_strong_drift_ratio":mean([r["strong_drift_ratio"] for r in rows]),"label":"floating_relock_success" if len(stable)+len(meta)>=len(rows)*0.70 and len(col)==0 else "floating_relock_limited","top_trials":sorted(rows,key=lambda x:x["S_floating_relock"],reverse=True)[:10],"all_trials":rows}
    out=Path(args.outdir); out.mkdir(exist_ok=True)
    json.dump(summary,open(out/"floating_relock_summary.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    json.dump(rows,open(out/"floating_relock_trials.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    print(json.dumps({k:summary[k] for k in ["trials","floating_relock_stable","floating_relock_metastable","floating_relock_weak","floating_relock_collapse","mean_S_floating_relock","mean_relock_success_rate","mean_false_prediction_damage","mean_strong_drift_ratio","label"]},indent=2))

if __name__=="__main__":
    main()
