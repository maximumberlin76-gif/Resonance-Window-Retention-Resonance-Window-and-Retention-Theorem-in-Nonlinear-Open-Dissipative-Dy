# Session Journal v28.3

Added:
- instability point definition
- release mechanism clarification

Key:
Synthesis begins when accumulation stops being stable.
