# v28.3 Instability → Release

Core idea:
Synthesis starts when accumulation saturates.

Chain:
accumulation → saturation → instability → release → window → synthesis

This module formalizes instability point.
