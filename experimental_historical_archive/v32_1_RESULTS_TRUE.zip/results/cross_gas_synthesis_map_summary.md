# Cross-Gas Synthesis Map — Summary

Main conclusion: `cross_gas_overlap_exists_for_all_three_gases`

## Gas summary
- argon: valid=23/72 ratio=0.319444, incomplete=0.569444, score=9.8
- helium: valid=27/90 ratio=0.3, incomplete=0.566667, score=1.8
- hydrogen: valid=29/90 ratio=0.322222, incomplete=0.6, score=13.2

## Universal candidates
- f_norm 1.0: {'argon': 2, 'helium': 2, 'hydrogen': 4}

## Top partial candidates
- f_norm 2.0: {'helium': 5, 'hydrogen': 2}