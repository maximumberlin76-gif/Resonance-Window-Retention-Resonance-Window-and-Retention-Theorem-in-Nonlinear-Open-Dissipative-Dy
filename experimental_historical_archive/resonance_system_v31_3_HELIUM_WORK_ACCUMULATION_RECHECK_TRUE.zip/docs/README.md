# v31.3 — Helium Work-Accumulation Recheck

## Abstract

This module rechecks helium phase-lock calibration using the stricter work-accumulation criterion.

The system is treated strictly as a nonlinear dissipative open dynamic system.

The key correction is:

```text
R > 0.7 alone is not a resonance window.
```

A resonance window requires positive structural coherent work accumulated over completed periods.

This is a computational sandbox, not laboratory evidence.

## Core Formula

```text
W_period(k) =
∫ over period k max(0, R(t) - R_floor) · F_ext(t) dt
```

Accumulated work:

```text
Θ_N = Σ W_period(k)
```

## Candidate Rule

```text
R_final >= R_lock
and
stable_work_periods >= synthesis_min_periods
and
Θ_N >= Θ_work_crit
and
retention_R_tail >= R_retention_min
```

## Why Helium Matters

Helium responds faster than argon but has a narrower retention corridor.

Therefore it is a strong test for whether phase lock becomes real synthesis or remains incomplete accumulation.

## System Class

```text
nonlinear dissipative open dynamic systems
```

## Run

```bash
python scripts/engine_v31_3_helium_work_accumulation_recheck.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/helium_work_accumulation_recheck_summary.json
results/helium_work_accumulation_recheck_trials.json
journal/session_journal_v31_3.md
```

## Next Step

v34 — Oxygen plasma profile, or v32.1 — corrected Ar/He/H comparison using Θ_N criterion.
