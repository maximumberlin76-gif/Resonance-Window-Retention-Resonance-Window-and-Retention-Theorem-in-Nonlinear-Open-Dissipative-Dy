# v31.3 Equations

## Period Work

W_period(k) =
∫_{kT}^{(k+1)T} max(0, R(t) - R_floor) · F_ext(t) dt

## Accumulated Positive Work

Θ_N =
Σ W_period(k)

## Core Rule

R > 0.7 without Θ_N >= Θ_crit is not a resonance window.

## Candidate Rule

helium_work_accumulation_resonance_window_candidate if:

R_final >= R_lock
and
stable_work_periods >= synthesis_min_periods
and
theta_work >= Theta_work_crit
and
retention_R_tail >= R_retention_min
