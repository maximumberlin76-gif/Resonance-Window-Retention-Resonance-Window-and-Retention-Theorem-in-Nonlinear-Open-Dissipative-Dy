# Session Journal — v31.3

## Step

v31.3 — Helium Work-Accumulation Recheck.

## Reason

After v33.2, helium must be rechecked with the same strict criterion:
phase lock + accumulated positive structural work over completed periods + retention.

## Added

- W_period
- theta_work
- stable positive work periods
- false lock rejection
- retention_R_tail criterion
- helium drift-sensitive penalty

## Core Principle

Helium can phase-lock quickly, but a real window requires accumulated positive work and retention.
