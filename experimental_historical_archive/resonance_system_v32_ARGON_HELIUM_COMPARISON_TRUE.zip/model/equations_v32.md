# v32 Comparison Logic

## System Class

nonlinear dissipative open dynamic systems

## Model Score

score =
2.0 * synthesis_candidates
+ 1.5 * phase_lock_candidates
- 1.0 * no_stable_window
- 0.5 * no_phase_lock
- 0.4 * incomplete_accumulation

## Interpretation

Argon:
retention-dominant profile

Helium:
response-dominant profile with higher drift sensitivity
