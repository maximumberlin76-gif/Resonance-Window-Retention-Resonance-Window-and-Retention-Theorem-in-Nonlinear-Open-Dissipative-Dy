#!/usr/bin/env python3
from pathlib import Path
import json

required = [
    "scripts/engine_v32_argon_helium_comparison.py",
    "results/argon_helium_comparison_summary.json",
    "docs/README.md",
    "model/equations_v32.md",
    "journal/session_journal_v32.md"
]
for item in required:
    p = Path(item)
    assert p.exists(), f"missing {item}"
    assert p.stat().st_size > 100, f"too small {item}"

s = json.load(open("results/argon_helium_comparison_summary.json", "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "gases" in s
print("SMOKE_OK")
