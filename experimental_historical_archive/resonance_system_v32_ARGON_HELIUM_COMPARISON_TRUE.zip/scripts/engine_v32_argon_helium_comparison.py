#!/usr/bin/env python3
"""
v32 TRUE ARGON vs HELIUM COMPARISON

Purpose:
Compare argon and helium resonance-window behavior after full cycles:
- plasma profile
- Kuramoto layer
- phase-lock calibration

System class:
nonlinear dissipative open dynamic systems

This is a synthetic comparison built from the model outputs and compact summary anchors.
It is not a laboratory comparison.

Core comparison:
Argon:
- heavier gas
- stronger inertial retention
- slower response
- wider holding corridor
- phase lock after calibration

Helium:
- lighter gas
- faster response
- higher drift sensitivity
- narrower holding corridor
- phase lock after stronger calibration, but more incomplete accumulation
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def mean(xs):
    return sum(xs) / max(1, len(xs))

def score_gas(g):
    # Utility score: synthesis candidates + phase-lock candidates - penalties
    plasma = g["plasma_profile"]
    phase = g["phase_lock_calibration"]
    return (
        2.0 * plasma["synthesis_candidates"]
        + 1.5 * phase["phase_lock_candidates"]
        - 1.0 * plasma["no_stable_window"]
        - 0.5 * phase["no_phase_lock"]
        - 0.4 * phase["incomplete_accumulation"]
    )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))

    gases = cfg["gases"]
    comparison = {}

    for gas_name, g in gases.items():
        comparison[gas_name] = {
            "mass_amu": g["mass_amu"],
            "ionization_energy_eV": g["ionization_energy_eV"],
            "expected_response": g["expected_response"],
            "expected_retention": g["expected_retention"],
            "expected_drift_sensitivity": g["expected_drift_sensitivity"],
            "plasma_profile": g["plasma_profile"],
            "phase_lock_calibration": g["phase_lock_calibration"],
            "dominant_frequency_hits_mhz": g["dominant_frequency_hits_mhz"],
            "model_score": score_gas(g)
        }

    # pairwise interpretation
    argon = comparison["argon"]
    helium = comparison["helium"]

    findings = []

    if helium["expected_response"] > argon["expected_response"]:
        findings.append("helium_response_faster_than_argon")
    if argon["expected_retention"] > helium["expected_retention"]:
        findings.append("argon_retention_stronger_than_helium")
    if helium["expected_drift_sensitivity"] > argon["expected_drift_sensitivity"]:
        findings.append("helium_drift_sensitivity_higher")
    if helium["phase_lock_calibration"]["incomplete_accumulation"] > argon["phase_lock_calibration"]["incomplete_accumulation"]:
        findings.append("helium_more_often_phase_locked_but_incomplete")
    if argon["phase_lock_calibration"]["phase_lock_candidates"] >= helium["phase_lock_calibration"]["phase_lock_candidates"]:
        findings.append("argon_phase_lock_more_retentive_or_equal")
    else:
        findings.append("helium_phase_lock_candidates_more_frequent_after_calibration")

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "comparison_type": "computational_model_comparison_not_laboratory_measurement",
        "gases": comparison,
        "findings": findings,
        "main_conclusion": "argon_is_better_for_retention_helium_is_better_for_fast_response_but_needs_tighter_period_control",
        "next_candidates": {
            "hydrogen": {
                "reason": "lightest gas, fastest response, strong quantum/ion-acoustic interest, but highest drift/noise risk",
                "risk": "more difficult to stabilize; may produce many incomplete or chaotic candidates"
            },
            "oxygen": {
                "reason": "molecular plasma, chemically active, tests dissociation/recombination and nonlinear chemistry",
                "risk": "not noble gas; reactions add extra channels P(t), D(t), and loss terms"
            }
        }
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"argon_helium_comparison_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "main_conclusion": summary["main_conclusion"],
        "findings": findings,
        "argon_score": comparison["argon"]["model_score"],
        "helium_score": comparison["helium"]["model_score"],
        "recommended_next": "hydrogen_first_if_testing_speed; oxygen_first_if_testing_chemistry"
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
