# Session Journal — v32

## Step

v32 — Argon vs Helium Comparison.

## Reason

After completing full argon and helium cycles, we compare whether the resonance-window framework transfers across gases.

## Result

Argon behaves as retention-dominant.
Helium behaves as response-dominant but drift-sensitive.

## Next Step

Choose next plasma:
- Hydrogen for speed/lightness stress test.
- Oxygen for molecular/chemical plasma test.
