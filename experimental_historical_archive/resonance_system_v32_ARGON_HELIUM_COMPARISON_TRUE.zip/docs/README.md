# v32 — Argon vs Helium Comparison

## Abstract

This module compares argon and helium plasma behavior inside the resonance-window framework.

The system class remains:

```text
nonlinear dissipative open dynamic systems
```

This comparison is computational and model-based. It is not a laboratory measurement.

## Compared Cycles

Argon:

- v30 — plasma resonance-window profile
- v30.1 — Kuramoto layer
- v30.2 — phase-lock calibration

Helium:

- v31 — plasma resonance-window profile
- v31.1 — Kuramoto layer
- v31.2 — phase-lock calibration

## Main Difference

Argon is heavier and more inertial.

Therefore it tends to show:

- stronger retention,
- slower response,
- broader holding corridor.

Helium is lighter and faster.

Therefore it tends to show:

- faster phase response,
- higher drift sensitivity,
- more incomplete accumulation,
- narrower retention corridor.

## Key Result

```text
Argon → better retention
Helium → faster response, but requires tighter period control
```

## Interpretation

The model did not simply copy argon behavior into helium.

The helium run produced a different profile:

- fewer synthesis-window candidates in the plasma profile,
- many phase-lock incomplete accumulation cases after calibration,
- stronger sensitivity to period retention.

## Next Candidate Gas

Hydrogen:

- best for testing speed and extreme lightness,
- highest drift/noise risk.

Oxygen:

- best for testing molecular plasma and chemistry,
- adds dissociation/recombination channels.

## Run

```bash
python scripts/engine_v32_argon_helium_comparison.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/argon_helium_comparison_summary.json
journal/session_journal_v32.md
```
