#!/usr/bin/env python3
from pathlib import Path
import json

required = [
    "scripts/engine_v33_2_hydrogen_work_accumulation_calibration.py",
    "results/hydrogen_work_accumulation_calibration_summary.json",
    "results/hydrogen_work_accumulation_calibration_trials.json",
    "docs/README.md",
    "model/equations_v33_2.md",
    "journal/session_journal_v33_2.md"
]
for item in required:
    p = Path(item)
    assert p.exists(), f"missing {item}"
    assert p.stat().st_size > 100, f"too small {item}"

s = json.load(open("results/hydrogen_work_accumulation_calibration_summary.json", "r", encoding="utf-8"))
assert s["system_class"] == "nonlinear dissipative open dynamic systems"
assert "best_frequency_hits_mhz" in s
print("SMOKE_OK")
