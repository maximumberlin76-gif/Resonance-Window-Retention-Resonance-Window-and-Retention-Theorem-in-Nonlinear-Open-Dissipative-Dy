# Session Journal — v33.2

## Step

v33.2 — Hydrogen Work-Accumulation Phase-Lock Calibration.

## User correction

The main indicator is not R alone.
The key is accumulated positive structural work over completed periods.

## Added

- W_period
- Theta_N / theta_work
- stable positive work periods
- false lock rejection
- retention_R_tail criterion

## Core Principle

Phase drift toward resonance-window conditions occurs only when accumulated positive structural work exceeds the holding threshold over time.
