# Experiment Chain

## Purpose

The experimental chain demonstrates sequence, reproducibility, and variability.

## Core Packages

```text
v35   — Hybrid Multi-Gas Regime Matrix
v35.1 — Ar-He-H Hybrid Acoustic + EM Retention
v35.2 — Ar-He-H Deep Hybrid Tests
v35.3 — Hybrid Retention Theorem Package
```

## Supporting Packages

```text
v30.3 — Argon Work-Accumulation Recheck
v31.3 — Helium Work-Accumulation Recheck
v33.2 — Hydrogen Work-Accumulation Calibration
v34   — Methane Plasma Profile
v34.1 — Methane Kuramoto / Work Layer
v32.1 — Cross-Gas Synthesis Map
```

## Proof Logic

```text
1. Atomic gases validate the normalized corridor.
2. Work accumulation filters false phase locks.
3. Hybrid control separates entry and retention.
4. Molecular gases introduce μ_env and χ_mix.
5. Deep hybrid tests validate failure modes.
```
