# Resonance Window Theorem / Hybrid Plasma Retention

## Abstract

This package contains the formal publication core for the Resonance Window Theorem and Hybrid Plasma Retention framework.

System class:

```text
nonlinear dissipative open dynamic systems
```

The work formalizes resonance not as simple amplification, but as a dynamic selection process that allows a system to enter, accumulate, and retain stable self-organized states.

## Core Thesis

```text
R is an indicator.
Θ_N is the admission criterion.
Retention completes the window.
```

Phase coherence alone is insufficient.

A real self-organized state requires accumulated positive structural work over completed periods, positive balance C(t) − P(t), retention inside Ω_ret, and stability after external drive reduction.

## Proof Chain

```text
Resonance as process
→ Resonance Window Theorem
→ Hybrid Retention Theorem
→ experimental validation
→ multi-gas variability
→ reproducibility archive
```

## Two Core Invariants

```text
Invariant 1:
Θ_N = Σ W_period(k) ≥ Θ_crit

Invariant 2:
∫(C(t) − P(t)) dt > 0 over completed periods
```

## Final Interpretation

The resonance window does not give arbitrary control over matter.

It defines the admissible state-space region in which matter can remain organized over time.

Hybrid control does not “hold plasma” directly.

It holds the conditions under which plasma remains self-organized.
