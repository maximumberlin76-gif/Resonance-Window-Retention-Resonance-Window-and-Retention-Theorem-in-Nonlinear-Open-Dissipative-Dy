# Resonance as a Process

## Definition

Resonance is not merely amplification.

In nonlinear dissipative open systems, resonance is a dynamic selection process that separates unstable dispersion from stable structural formation.

## Process Chain

```text
entry → accumulation → selection → retention → stability
```

## Properties

```text
1. Temporal accumulation
2. Periodic structure
3. Positive balance C − P
4. Retention domain Ω_ret
5. Forward invariance
6. Lyapunov stability
7. Non-zero basin of attraction
```

## Operational Reading

Resonance does not impose arbitrary form.

It opens a bounded corridor of possible states.

The system retains only those states that satisfy the work-accumulation and retention criteria.
