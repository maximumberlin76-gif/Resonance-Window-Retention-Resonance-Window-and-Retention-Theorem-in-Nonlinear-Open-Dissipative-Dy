# Zenodo Description

This archive provides the formal theorem package for the Resonance Window Theorem and Hybrid Plasma Retention framework.

The work defines resonance as a dynamic selection process rather than simple amplification.

The central claim is:

```text
R is an indicator.
Θ_N is the admission criterion.
Retention completes the window.
```

The archive includes:

```text
- Resonance Window Theorem
- Hybrid Retention Theorem
- two core invariants
- resonance process formalization
- experiment chain index
- reproducibility matrix
- GitHub upload order
- Zenodo metadata draft
```

The experimental validation layer is provided through separate versioned packages in the repository.
