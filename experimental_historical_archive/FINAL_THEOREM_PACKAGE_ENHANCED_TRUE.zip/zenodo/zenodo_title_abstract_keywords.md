# Zenodo Metadata Draft

## Title

Resonance Window Theorem and Hybrid Plasma Retention in Nonlinear Dissipative Open Systems

## Subtitle

Formalization of resonance as a process, work-accumulation invariants, and hybrid acoustic/electromagnetic plasma retention.

## Keywords

```text
resonance window theorem
hybrid plasma retention
nonlinear dissipative open systems
self-organization
work accumulation
Theta_N
Lyapunov stability
forward invariance
plasma stabilization
acoustic resonance
electromagnetic retention
```

## Short Abstract

This work introduces the Resonance Window Theorem and Hybrid Retention Theorem for nonlinear dissipative open systems. Resonance is formalized as a process of entry, accumulated positive work, state selection, retention, and stability. The framework is supported by reproducible computational experiments across atomic and molecular plasma models, including hybrid acoustic/electromagnetic retention regimes.
