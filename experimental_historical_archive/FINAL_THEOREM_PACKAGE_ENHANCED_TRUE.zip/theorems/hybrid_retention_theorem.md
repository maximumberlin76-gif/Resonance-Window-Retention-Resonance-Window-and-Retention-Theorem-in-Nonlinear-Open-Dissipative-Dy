# Hybrid Retention Theorem

## System Class

```text
nonlinear dissipative open dynamic systems
```

## Core Statement

Hybrid control separates entry and retention mechanisms, enabling temporal stability of self-organized plasma states.

## Control Architecture

```text
F_total(t) = F_acoustic(t) + F_EM(t)
```

with separated roles:

```text
F_acoustic → drives entry into Ω(t) and initiates Θ_N accumulation
F_EM       → stabilizes Ω_ret and enforces retention
```

## Retention Condition

A plasma remains in a self-organized state if:

```text
Θ_N ≥ Θ_crit
```

and

```text
∫(C(t) − P(t)) dt > 0
```

over completed periods,

and

```text
x(t) ∈ Ω_ret for t ≥ t₀ + τ
```

after reduction of the acoustic drive.

## Four-Phase Mechanism

```text
1. Acoustic Entry
   → rapid entry into Ω(t)
   → initial Θ_N accumulation

2. Hybrid Overlap
   → acoustic drive continues
   → EM assists phase stabilization

3. EM Retention
   → acoustic drive is reduced
   → EM stabilizes Ω_ret

4. Drive Reduction Test
   → acoustic → 0
   → EM reduced
   → either retention persists or the state collapses
```

## Experimental Anchor

v35.2 deep hybrid tests:

```text
total trials: 720

valid_hybrid_resonance_window: 242
accumulation_without_retention: 466
phase_alignment_without_work: 10
no_window: 2
```

## Critical Insight

```text
R ≠ stability
```

Only accumulated positive work over time combined with retention defines a real self-organized plasma state.

## Final Statement

Hybrid regime does not control plasma directly.

It stabilizes the conditions under which plasma remains self-organized in time.
