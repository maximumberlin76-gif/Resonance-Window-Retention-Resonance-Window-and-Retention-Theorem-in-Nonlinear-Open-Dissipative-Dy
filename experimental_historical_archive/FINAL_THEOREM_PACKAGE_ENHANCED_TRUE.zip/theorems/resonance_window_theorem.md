# Resonance Window Theorem

## System Class

```text
nonlinear dissipative open dynamic systems
```

## Theorem Statement

Synthesis is defined as the selection of a state x ∈ Ω(t), such that:

```text
∃ N ∈ ℕ such that:
Θ_N = Σ_{k=0}^{N−1} W_period(k) ≥ Θ_crit
```

where

```text
W_period(k) = ∫_{t₀ + kT}^{t₀ + (k+1)T}
max(0, R(t) − R_floor) · F_ext(t) dt
```

represents the accumulated driven coherence contribution over one period,

and

```text
∃ K ∈ ℕ such that for k = 0 … K−1:
∫_{t₀ + kT}^{t₀ + (k+1)T} (C(t) − P(t)) dt > 0
```

and

```text
∃ τ > 0 such that ∀ t ≥ t₀ + τ:
x(t) ∈ Ω_ret ⊆ Ω(t)
```

under the condition:

```text
∃ τ_d ≥ 0 such that ∀ t ≥ t₀ + τ_d:
F_ext(t) = 0
```

with

```text
∃ T > 0
```

defining the period length,

and

```text
Ω_ret is forward-invariant
```

and

```text
x(t) is Lyapunov-stable within Ω_ret under bounded perturbations
```

and

```text
Ω_ret possesses a basin of attraction of non-zero measure.
```

## Short Form

```text
Synthesis =
x ∈ Ω(t)
+ Θ_N ≥ Θ_crit
+ positive C−P over periods
+ retention in Ω_ret
+ forward invariance
+ Lyapunov stability
+ non-zero basin of attraction
```
