# Unified Theorem Frame

## One Framework, Two Theorems

```text
1. Resonance Window Theorem
2. Hybrid Retention Theorem
```

## Shared Invariants

```text
Invariant 1:
Θ_N = Σ W_period(k) ≥ Θ_crit

Invariant 2:
∫(C(t) − P(t)) dt > 0 over completed periods
```

## Functional Difference

```text
Resonance Window Theorem:
defines admissible state selection.

Hybrid Retention Theorem:
defines channel-separated stabilization of the selected state.
```

## Unified Core

```text
Resonance is the process.
Ω(t) is the admissible state corridor.
Θ_N is the admission criterion.
Ω_ret is the retained domain.
Hybrid control is the engineering pathway.
```

## Hybrid Extension

```text
Ω(t) → Ω(t, μ_env, χ_mix)
```

where:

```text
μ_env  = medium/environment parameter
χ_mix  = mixture composition vector
```
