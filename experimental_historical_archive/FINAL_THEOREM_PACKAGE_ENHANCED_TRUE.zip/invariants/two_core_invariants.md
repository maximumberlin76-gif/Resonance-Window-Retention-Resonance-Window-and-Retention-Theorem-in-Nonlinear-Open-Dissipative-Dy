# Two Core Invariants

## Invariant 1 — Accumulated Positive Structural Work

```text
Θ_N = Σ_{k=0}^{N−1} W_period(k) ≥ Θ_crit
```

This prevents false classification of transient phase alignment as synthesis.

## Invariant 2 — Positive Balance Over Completed Periods

```text
∫_{t₀ + kT}^{t₀ + (k+1)T} (C(t) − P(t)) dt > 0
```

This prevents short-lived spikes from being treated as stable self-organization.

## Meaning

```text
R is an indicator.
Θ_N is the admission criterion.
Retention completes the window.
```

## Failure Filters

```text
R without Θ_N → false lock
Θ_N without retention → accumulation without synthesis
C−P without periods → transient spike
retention without stability → fragile state
```
