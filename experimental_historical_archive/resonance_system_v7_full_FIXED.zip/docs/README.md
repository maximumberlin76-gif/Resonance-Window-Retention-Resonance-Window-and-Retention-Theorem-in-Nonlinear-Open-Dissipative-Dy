
# Resonance System v7 FULL (Operational Package)

## Overview
This package implements a full-cycle resonance control system:

search → stabilization → retention → adaptation → evolution

## Core Concept
System stability is defined by:
R_net = P_in * η - D

A mode is valid ONLY if:
- it survives after external drive OFF (retention)
- it is reproducible
- it resists noise and drift

## Architecture
- Multi-drive: f0 + f1 + f2
- Feedback loop: ΔΦ → correction
- Adaptive search: mutation + selection
- Classification: stable / metastable / reject

## How to Run
python scripts/engine_v7.py

## Output
- results/results.json → detected modes
- logs/feedback_history.json → feedback behavior
- logs/metrics.csv → run metrics

## Important
Do NOT trust peaks without retention.
Only stable attractor modes are valid.

## Status
System ready for:
- simulation scaling
- parameter tuning
- experimental mapping
