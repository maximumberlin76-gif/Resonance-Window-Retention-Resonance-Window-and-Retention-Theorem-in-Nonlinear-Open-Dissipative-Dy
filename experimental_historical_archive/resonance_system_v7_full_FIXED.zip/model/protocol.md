
# Protocol Summary

1. Scan parameter space
2. Apply multi-drive excitation
3. Measure coherence (R)
4. Turn OFF drive
5. Check retention
6. Classify mode
7. Store only stable ones
8. Mutate around successful regions

Loop until convergence.
