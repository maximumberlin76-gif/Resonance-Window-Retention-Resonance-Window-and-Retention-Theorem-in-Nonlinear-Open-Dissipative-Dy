#!/usr/bin/env python3
"""
v34 TRUE METHANE PLASMA RESONANCE WINDOW PROFILE

Purpose:
Map the resonance-window framework onto a simplified methane plasma profile.

System class:
nonlinear dissipative open dynamic systems

Important:
This is a computational resonance-window sandbox, not a laboratory measurement.

Methane expectation:
- molecular gas, not noble gas
- more internal degrees of freedom
- dissociation/recombination channels increase D(t)
- slower response than H/He
- possible stronger period accumulation if dissipation remains bounded
- resonance window should be narrower and more chemistry-sensitive

Core premise:
Synthesis requires accumulated positive structural coherent work over completed periods,
not phase response alone.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def gaussian(x, mu, sigma):
    return math.exp(-0.5 * ((x - mu) / max(1e-12, sigma)) ** 2)

def spectrum_score(freq_mhz, duty, pressure_mTorr, cfg):
    m = cfg["methane"]
    anchor = m["acoustic_anchor_mhz"]

    anchor_component = gaussian(freq_mhz, anchor, 2.6)
    harmonic_component = 0.55 * gaussian(freq_mhz, anchor * 2.0, 5.2)
    rf_component = 0.50 * gaussian(freq_mhz, m["rf_reference_mhz"], 3.4)
    carbon_branch = 0.35 * gaussian(freq_mhz, m["carbon_branch_mhz"], 6.5)

    pressure_component = gaussian(pressure_mTorr, m["pressure_center_mTorr"], m["pressure_sigma_mTorr"])
    duty_component = gaussian(duty, m["duty_center"], m["duty_sigma"])

    return clamp((anchor_component + harmonic_component + rf_component + carbon_branch) * pressure_component * duty_component)

def simulate(seed, drive, cfg):
    rng = random.Random(seed)
    steps = cfg["simulation"]["steps"]
    period_steps = cfg["simulation"]["period_steps"]
    m = cfg["methane"]

    Te = rng.uniform(2.5, 6.5)
    ne = rng.uniform(5e8, 4e10)
    ion_frac = rng.uniform(1e-7, 1e-4)
    dissociation_fraction = rng.uniform(0.0, 0.02)
    recombination_load = 0.0
    C = rng.uniform(0.28, 0.50)

    W_coh = 0.0
    theta_balance = 0.0
    stable_periods = 0
    weak_periods = 0
    failed_periods = 0

    W_period = 0.0
    balance_period = 0.0
    period_C_values = []
    period_records = []

    chaos_events = 0
    chemistry_overload_events = 0
    sample = []

    spec = spectrum_score(drive["freq_mhz"], drive["duty"], drive["pressure_mTorr"], cfg)

    for t in range(steps):
        phase = 2 * math.pi * (t % period_steps) / period_steps
        pulse = 1.0 if (t % period_steps) < int(period_steps * drive["duty"]) else 0.0
        modulation = 1.0 + 0.16 * math.sin(phase)

        heating = drive["power_norm"] * spec * pulse * modulation
        collision_rate = drive["pressure_mTorr"] / 420.0

        # Molecular chemistry channels.
        dissociation_drive = gaussian(Te, m["Te_dissociation_eff_eV"], m["Te_dissociation_sigma_eV"]) * heating
        dissociation_fraction = clamp(
            dissociation_fraction
            + 0.006 * dissociation_drive
            - 0.002 * recombination_load
            - 0.001 * collision_rate * dissociation_fraction,
            0.0,
            0.80
        )

        recombination_load = clamp(
            0.65 * recombination_load
            + 0.015 * dissociation_fraction * collision_rate,
            0.0,
            1.0
        )

        chemistry_loss = (
            m["chemistry_loss_base"]
            + m["dissociation_loss_weight"] * dissociation_fraction
            + m["recombination_loss_weight"] * recombination_load
        )

        dissipation = (
            m["base_dissipation"]
            + 0.075 * collision_rate
            + 0.040 * abs(Te - m["Te_target_eV"])
            + chemistry_loss
        )

        destructive = (
            m["base_pressure"]
            + 0.065 * max(0.0, Te - m["Te_upper_soft_eV"])
            + 0.035 * max(0.0, collision_rate - 1.0)
        )

        useful_alignment = spec * pulse * gaussian(Te, m["Te_target_eV"], m["Te_sigma_eV"])
        useful_work_step = useful_alignment * drive["power_norm"] * cfg["simulation"]["work_gain"]

        # Methane: slower thermal response than H/He, stronger chemistry damping.
        Te += (
            0.045 * heating
            - 0.026 * (Te - m["Te_relax_eV"])
            - 0.010 * collision_rate
            - 0.020 * chemistry_loss
            + rng.uniform(-0.018, 0.018)
        )
        Te = max(0.1, min(28.0, Te))

        ion_drive = gaussian(Te, m["Te_ionization_eff_eV"], m["Te_ionization_sigma_eV"]) * heating
        ion_frac = clamp(
            ion_frac
            + 7e-4 * ion_drive
            - 3e-4 * collision_rate * ion_frac
            - 2e-4 * chemistry_loss * ion_frac,
            0.0,
            0.08
        )

        ne = max(
            1e6,
            ne * (
                1.0
                + 0.010 * ion_drive
                - 0.003 * collision_rate
                - 0.004 * chemistry_loss
                + rng.uniform(-0.004, 0.004)
            )
        )

        P = destructive
        D = dissipation
        C_prev = C

        C = clamp(
            C
            + 0.026 * useful_alignment * (1.0 - C)
            + 0.010 * max(0.0, 0.25 - abs(dissociation_fraction - m["dissociation_target"]))
            - 0.012 * P
            - 0.013 * D
            + rng.uniform(-cfg["simulation"]["noise"], cfg["simulation"]["noise"])
        )

        if abs(C - C_prev) > cfg["simulation"]["safe_dC_limit"]:
            chaos_events += 1
        if chemistry_loss > cfg["thresholds"]["chemistry_loss_limit"]:
            chemistry_overload_events += 1

        delta = C - P - D

        W_period += useful_work_step
        W_coh += useful_work_step

        if delta > 0:
            theta_balance += delta
            balance_period += delta

        period_C_values.append(C)

        if (t + 1) % period_steps == 0:
            period_mean_C = mean(period_C_values)
            period_min_C = min(period_C_values) if period_C_values else 0.0

            if (
                W_period >= cfg["thresholds"]["W_period_min"]
                and balance_period >= cfg["thresholds"]["balance_period_min"]
                and period_mean_C >= cfg["thresholds"]["C_period_mean_min"]
                and period_min_C >= cfg["thresholds"]["C_period_min_floor"]
            ):
                stable_periods += 1
                label = "stable_positive_work_period"
            elif W_period > 0:
                weak_periods += 1
                label = "weak_positive_work_period"
            else:
                failed_periods += 1
                label = "failed_period"

            period_records.append({
                "period_index": len(period_records) + 1,
                "W_period": round(W_period, 8),
                "balance_period": round(balance_period, 8),
                "period_mean_C": round(period_mean_C, 6),
                "period_min_C": round(period_min_C, 6),
                "label": label
            })

            W_period = 0.0
            balance_period = 0.0
            period_C_values = []

        if t % cfg["simulation"]["sample_every"] == 0 or t == steps - 1:
            sample.append({
                "step": t,
                "Te_eV": round(Te, 6),
                "ne_cm3": round(ne, 3),
                "ionization_fraction_proxy": round(ion_frac, 8),
                "dissociation_fraction": round(dissociation_fraction, 8),
                "recombination_load": round(recombination_load, 8),
                "chemistry_loss": round(chemistry_loss, 8),
                "C": round(C, 6),
                "P": round(P, 6),
                "D": round(D, 6),
                "delta": round(delta, 6),
                "W_coh": round(W_coh, 8),
                "theta_balance": round(theta_balance, 8)
            })

    chaos_rate = chaos_events / steps
    chemistry_overload_rate = chemistry_overload_events / steps

    if chaos_rate >= cfg["thresholds"]["chaos_rate_limit"]:
        outcome = "methane_chaotic_overdrive"
    elif chemistry_overload_rate >= cfg["thresholds"]["chemistry_overload_rate_limit"]:
        outcome = "methane_chemistry_overload"
    elif stable_periods >= cfg["thresholds"]["closed_structure_periods"]:
        outcome = "methane_closed_structure_candidate"
    elif cfg["thresholds"]["synthesis_min_periods"] <= stable_periods <= cfg["thresholds"]["synthesis_max_periods"]:
        outcome = "methane_resonance_window_synthesis_candidate"
    elif stable_periods > 0 or weak_periods > 0:
        outcome = "methane_accumulation_in_progress"
    else:
        outcome = "methane_no_stable_window"

    return {
        "seed": seed,
        "drive": drive,
        "spectrum_score": spec,
        "W_coh": round(W_coh, 8),
        "theta_balance": round(theta_balance, 8),
        "stable_periods": stable_periods,
        "weak_periods": weak_periods,
        "failed_periods": failed_periods,
        "chaos_rate": chaos_rate,
        "chemistry_overload_rate": chemistry_overload_rate,
        "mean_C": mean([x["C"] for x in sample]),
        "mean_Te_eV": mean([x["Te_eV"] for x in sample]),
        "mean_dissociation_fraction": mean([x["dissociation_fraction"] for x in sample]),
        "mean_chemistry_loss": mean([x["chemistry_loss"] for x in sample]),
        "outcome": outcome,
        "period_records": period_records,
        "series_sampled": sample
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))

    drives = []
    for freq in cfg["scan"]["freq_mhz"]:
        for power in cfg["scan"]["power_norm"]:
            for pressure in cfg["scan"]["pressure_mTorr"]:
                for duty in cfg["scan"]["duty"]:
                    drives.append({"freq_mhz": freq, "power_norm": power, "pressure_mTorr": pressure, "duty": duty})

    rows = [simulate(cfg["seed"] + i * 100, drive, cfg) for i, drive in enumerate(drives)]

    outcomes = {}
    for r in rows:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1

    best = sorted(
        rows,
        key=lambda r: (
            r["outcome"] == "methane_resonance_window_synthesis_candidate",
            r["stable_periods"],
            r["W_coh"],
            r["theta_balance"],
            r["spectrum_score"],
            -r["chemistry_overload_rate"]
        ),
        reverse=True
    )[:12]

    freq_hits = {}
    for r in best:
        f = str(r["drive"]["freq_mhz"])
        freq_hits[f] = freq_hits.get(f, 0) + 1

    summary = {
        "system_class": "nonlinear dissipative open dynamic systems",
        "methane_reference": {
            "molecule": "CH4",
            "ionization_energy_eV": cfg["methane"]["ionization_energy_eV"],
            "rf_reference_mhz": cfg["methane"]["rf_reference_mhz"],
            "diagnostic_notes": cfg["methane"]["diagnostic_notes"],
            "note": "Computational profile, not laboratory measurement."
        },
        "trials": len(rows),
        "outcomes": outcomes,
        "best_candidates": best,
        "recommended_frequency_hits_mhz": freq_hits,
        "main_conclusion": "methane_tests_molecular_dissipation_and_chemistry_sensitive_resonance_windows",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"methane_plasma_profile_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"methane_plasma_profile_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": len(rows),
        "outcomes": outcomes,
        "recommended_frequency_hits_mhz": freq_hits,
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
