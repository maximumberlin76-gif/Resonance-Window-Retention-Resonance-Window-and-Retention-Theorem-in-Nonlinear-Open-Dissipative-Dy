# Session Journal — v34

## Step

v34 — Methane Plasma Resonance Window Profile.

## Reason

After Ar, He, and H, methane tests the molecular regime.

## Added

- CH4 molecular gas profile
- dissociation fraction proxy
- recombination load proxy
- chemistry loss term in D(t)
- stable positive work periods
- chemistry overload rejection

## Core Principle

Methane tests whether the resonance-window theorem survives extra molecular dissipation and chemistry channels.
