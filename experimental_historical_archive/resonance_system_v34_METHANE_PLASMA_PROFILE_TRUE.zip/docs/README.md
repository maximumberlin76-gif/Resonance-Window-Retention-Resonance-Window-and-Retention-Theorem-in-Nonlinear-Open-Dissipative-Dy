# v34 — Methane Plasma Resonance Window Profile

## Abstract

This module maps the resonance-window framework onto a simplified methane plasma profile.

The system is treated strictly as a nonlinear dissipative open dynamic system.

Methane is the first molecular gas in this sequence, so the model adds simplified chemistry channels:

- dissociation,
- recombination load,
- chemistry loss,
- molecular dissipation.

This is a computational profile, not laboratory evidence.

## Why Methane Matters

Methane is not a noble gas.

It has more internal degrees of freedom than Ar, He, or H and therefore adds extra dissipation channels.

Expected behavior:

```text
more molecular channels → higher D(t)
slower response → possible longer accumulation
chemistry overload → narrower Ω(t)
```

## Core Criterion

```text
R is not enough.
Θ_N / W_period and positive C−P balance decide the window.
```

## System Class

```text
nonlinear dissipative open dynamic systems
```

## Spectrum Scan

The model scans:

- 6.78 MHz
- 7.40 MHz
- 13.56 MHz
- 14.80 MHz
- 22.20 MHz
- 27.12 MHz

with pressure, duty cycle, and normalized power.

## Run

```bash
python scripts/engine_v34_methane_plasma_profile.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/methane_plasma_profile_summary.json
results/methane_plasma_profile_trials.json
journal/session_journal_v34.md
```

## Next Step

v34.1 — Methane Kuramoto / work-accumulation coupling layer.
