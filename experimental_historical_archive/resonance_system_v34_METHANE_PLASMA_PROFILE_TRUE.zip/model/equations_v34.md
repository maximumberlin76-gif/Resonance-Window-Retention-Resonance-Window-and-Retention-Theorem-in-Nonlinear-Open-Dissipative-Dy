# v34 Equations

## Useful Coherent Work

W_period(k) =
∫ over period k useful_alignment_work(t) dt

Θ_N =
Σ W_period(k)

## Coherence Balance

Δ(t) = C(t) - P(t) - D(t)

## Molecular Loss

D(t) includes:
- base dissipation
- pressure/collision loss
- dissociation loss
- recombination load

## Candidate Rule

methane_resonance_window_synthesis_candidate if:

7 <= stable_periods <= 9
and
W_period >= threshold
and
(C - P)_periodic > 0
and
chemistry overload is bounded
