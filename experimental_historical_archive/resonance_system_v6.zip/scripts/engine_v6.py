
import numpy as np
import json
import random

class ResonanceSystem:
    def __init__(self, N=30):
        self.N = N
        self.reset()

    def reset(self):
        self.theta = np.random.uniform(0, 2*np.pi, self.N)
        self.omega = np.random.uniform(0.9,1.1,self.N)
        self.K = 0.6
        self.f_shift = 0.0

    def order_param(self):
        return np.abs(np.mean(np.exp(1j*self.theta)))

    def step(self, f0,f1,f2,A,phi,duty,noise,dt=0.05):
        # drift
        self.f_shift += np.random.uniform(-0.001,0.001)

        f0_eff = f0 + self.f_shift
        f1_eff = f1 + self.f_shift
        f2_eff = f2 + self.f_shift

        drive = A*(np.sin(2*np.pi*f0_eff*dt+phi)+
                   np.sin(2*np.pi*f1_eff*dt)+
                   np.sin(2*np.pi*f2_eff*dt))
        drive *= duty

        for i in range(self.N):
            coupling = np.sum(np.sin(self.theta - self.theta[i]))
            noise_term = noise*np.random.randn()
            self.theta[i] += (self.omega[i] + self.K*coupling/self.N + drive + noise_term)*dt

    def run(self, params, steps=200):
        R_vals=[]
        for _ in range(steps):
            self.step(**params)
            R_vals.append(self.order_param())
        return np.mean(R_vals)

def retention(sys, params):
    R_on = sys.run(params)
    zero = params.copy()
    zero.update({"f0":0,"f1":0,"f2":0,"A":0,"duty":0})
    R_off = sys.run(zero)
    return R_on, R_off

def adaptive_scan(config, generations=3):
    population = []
    freqs = config["freqs"]

    # initial seeds
    for f0 in freqs:
        for f1 in freqs:
            for f2 in freqs:
                population.append({
                    "f0":f0,"f1":f1,"f2":f2,
                    "A":random.choice(config["A"]),
                    "phi":random.choice(config["phi"]),
                    "duty":random.choice(config["duty"]),
                    "noise":config["noise"]
                })

    results = []

    for g in range(generations):
        scored = []
        for params in population:
            sys = ResonanceSystem()
            R_on, R_off = retention(sys, params)
            score = R_off - abs(R_on - R_off)  # stability preference
            scored.append((score, params, R_on, R_off))

        # sort best
        scored.sort(reverse=True, key=lambda x: x[0])
        top = scored[:len(scored)//4]

        # save
        for s,p,R_on,R_off in top:
            results.append({
                **p,
                "R_on":R_on,
                "R_off":R_off,
                "score":s,
                "gen":g
            })

        # mutate around top
        new_pop = []
        for _,p,_,_ in top:
            for _ in range(3):
                new = p.copy()
                new["f0"] += random.uniform(-5,5)
                new["f1"] += random.uniform(-5,5)
                new["f2"] += random.uniform(-5,5)
                new["phi"] += random.uniform(-0.2,0.2)
                new["duty"] += random.uniform(-0.1,0.1)
                new_pop.append(new)

        population = new_pop

    return results

if __name__ == "__main__":
    config = {
        "freqs":[50,100,150,300,600],
        "A":[0.3,0.5,0.7],
        "phi":[0,1.57,3.14],
        "duty":[0.3,0.6,0.9],
        "noise":0.02
    }

    res = adaptive_scan(config, generations=4)

    with open("results.json","w") as f:
        json.dump(res,f,indent=2)

    print("Adaptive scan complete")
