#!/usr/bin/env python3
"""
Resonance System v14 TRUE RECOVERY LAYER

Input: v13-style invariant modes.
Goal: test whether a critical backbone can recover after partial collapse.

Adds:
- damage simulation
- quarantine of unstable nodes
- recovery routing
- edge regeneration
- re-entry score
- recovery success/failure classification

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from itertools import combinations
from collections import deque

TARGET_RATIOS=[1,2,3,0.5,1/3,7,1/7]

def load_modes(path):
    rows=json.load(open(path,"r",encoding="utf-8"))
    return [r for r in rows if r.get("label") in ("invariant_stable","invariant_metastable")]

def retention(m):
    return float(m.get("checks",{}).get("env_mean",0.0))

def phase(a,b):
    return (1+math.cos(float(a["params"].get("phi",0))-float(b["params"].get("phi",0))))/2

def harmonic(a,b,eps=0.045):
    fa=[float(a["params"]["f0"]),float(a["params"]["f1"]),float(a["params"]["f2"])]
    fb=[float(b["params"]["f0"]),float(b["params"]["f1"]),float(b["params"]["f2"])]
    hits=0; total=0
    for x in fa:
        for y in fb:
            if x<=0 or y<=0: continue
            r=max(x,y)/min(x,y); total+=1
            if any(abs(r-t)/t<=eps for t in TARGET_RATIOS): hits+=1
    return hits/max(1,total)

def dist(a,b):
    pa,pb=a["params"],b["params"]
    d=(abs(pa["f0"]-pb["f0"])+abs(pa["f1"]-pb["f1"])+abs(pa["f2"]-pb["f2"]))/3
    return 1/(1+d/150)

def edge_score(a,b):
    return 0.55*harmonic(a,b)+0.15*phase(a,b)+0.20*((retention(a)+retention(b))/2)+0.10*dist(a,b)

def build_edges(modes,threshold):
    edges=[]
    for i,j in combinations(range(len(modes)),2):
        s=edge_score(modes[i],modes[j])
        if s>=threshold:
            edges.append({"i":i,"j":j,"score":s})
    return edges

def adj(n,edges,removed_nodes=None):
    removed_nodes=removed_nodes or set()
    g=[set() for _ in range(n)]
    for e in edges:
        i,j=e["i"],e["j"]
        if i in removed_nodes or j in removed_nodes: continue
        g[i].add(j); g[j].add(i)
    return g

def comps(n,edges,removed_nodes=None):
    removed_nodes=removed_nodes or set()
    g=adj(n,edges,removed_nodes)
    seen=set(); out=[]
    for i in range(n):
        if i in removed_nodes or i in seen: continue
        q=deque([i]); seen.add(i); c=[]
        while q:
            x=q.popleft(); c.append(x)
            for y in g[x]:
                if y not in seen:
                    seen.add(y); q.append(y)
        out.append(c)
    return sorted(out,key=len,reverse=True)

def degrees(n,edges):
    d=[0]*n
    for e in edges:
        d[e["i"]]+=1; d[e["j"]]+=1
    return d

def damage_nodes(n,edges,fraction,mode="hub",seed=42):
    count=max(1,int(n*fraction))
    if mode=="hub":
        deg=degrees(n,edges)
        return set(sorted(range(n),key=lambda x:deg[x],reverse=True)[:count])
    rng=random.Random(seed)
    return set(rng.sample(range(n),count))

def regenerate_edges(modes,edges,damaged,boost=0.05,threshold=0.925):
    # Recovery attempts to reconnect damaged/isolated nodes by slightly relaxing threshold
    existing={(min(e["i"],e["j"]),max(e["i"],e["j"])) for e in edges}
    new_edges=list(edges)
    recovery_threshold=max(0.55,threshold-boost)
    for i in damaged:
        for j in range(len(modes)):
            if i==j: continue
            key=(min(i,j),max(i,j))
            if key in existing: continue
            s=edge_score(modes[i],modes[j])
            if s>=recovery_threshold:
                new_edges.append({"i":i,"j":j,"score":s,"recovered":True})
                existing.add(key)
    return new_edges

def recovery_trial(modes,threshold,damage_fraction,damage_mode,boost):
    n=len(modes)
    base_edges=build_edges(modes,threshold)
    base_comp=comps(n,base_edges)
    base_largest=len(base_comp[0]) if base_comp else 0

    damaged=damage_nodes(n,base_edges,damage_fraction,damage_mode)
    damaged_comp=comps(n,base_edges,damaged)
    damaged_largest=len(damaged_comp[0]) if damaged_comp else 0

    recovered_edges=regenerate_edges(modes,base_edges,damaged,boost,threshold)
    recovered_comp=comps(n,recovered_edges,set())
    recovered_largest=len(recovered_comp[0]) if recovered_comp else 0

    reentry_score=(recovered_largest-damaged_largest)/max(1,base_largest-damaged_largest)
    recovered_new_edges=sum(1 for e in recovered_edges if e.get("recovered"))

    label="recovered" if recovered_largest>=base_largest*0.75 else ("partial_recovery" if recovered_largest>=base_largest*0.5 else "failed")
    return {
        "threshold":threshold,
        "damage_fraction":damage_fraction,
        "damage_mode":damage_mode,
        "boost":boost,
        "base_edges":len(base_edges),
        "base_largest":base_largest,
        "damaged_nodes":sorted(damaged),
        "damaged_largest":damaged_largest,
        "recovered_edges":len(recovered_edges),
        "recovered_new_edges":recovered_new_edges,
        "recovered_largest":recovered_largest,
        "reentry_score":reentry_score,
        "label":label,
        "component_sizes_after_recovery":[len(c) for c in recovered_comp]
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",default="results/invariance_results_all.json")
    ap.add_argument("--outdir",default="results")
    args=ap.parse_args()
    out=Path(args.outdir); out.mkdir(exist_ok=True)
    modes=load_modes(args.input)

    trials=[]
    for damage_mode in ["hub","random"]:
        for frac in [0.15,0.25,0.35]:
            for boost in [0.025,0.05,0.075]:
                trials.append(recovery_trial(modes,0.925,frac,damage_mode,boost))

    recovered=sum(1 for t in trials if t["label"]=="recovered")
    partial=sum(1 for t in trials if t["label"]=="partial_recovery")
    failed=sum(1 for t in trials if t["label"]=="failed")
    mean_reentry=sum(t["reentry_score"] for t in trials)/len(trials)

    summary={
        "nodes":len(modes),
        "trials":len(trials),
        "recovered":recovered,
        "partial_recovery":partial,
        "failed":failed,
        "mean_reentry_score":mean_reentry,
        "label":"recovery_capable" if recovered>=len(trials)*0.33 and mean_reentry>=0.5 else ("limited_recovery" if partial+recovered>failed else "recovery_failed"),
        "top_trials":sorted(trials,key=lambda x:x["reentry_score"],reverse=True)[:10],
        "all_trials":trials
    }
    json.dump(summary,open(out/"recovery_summary.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    json.dump({"nodes":modes,"trials":trials},open(out/"recovery_trials.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    print(json.dumps({k:summary[k] for k in ["nodes","trials","recovered","partial_recovery","failed","mean_reentry_score","label"]},indent=2))

if __name__=="__main__":
    main()
