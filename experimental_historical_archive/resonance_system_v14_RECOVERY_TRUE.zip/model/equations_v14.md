# v14 Metrics

reentry_score =
(recovered_largest - damaged_largest) / (base_largest - damaged_largest)

label:
recovered if recovered_largest >= 0.75 * base_largest
partial_recovery if recovered_largest >= 0.50 * base_largest
failed otherwise
