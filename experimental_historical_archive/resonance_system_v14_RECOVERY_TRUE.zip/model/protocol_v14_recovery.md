# v14 Recovery Protocol

1. Load invariant modes.
2. Build critical backbone at threshold 0.925.
3. Damage the graph:
   - hub removal
   - random removal
4. Attempt recovery by threshold relaxation:
   - 0.025
   - 0.050
   - 0.075
5. Measure recovered giant component.
6. Compute re-entry score.
7. Classify recovery.

reentry_score =
(recovered_largest - damaged_largest) /
(base_largest - damaged_largest)
