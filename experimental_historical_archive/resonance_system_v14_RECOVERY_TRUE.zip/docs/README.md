# Resonance System v14 TRUE RECOVERY

## Purpose

v13 found the critical backbone.  
v14 tests whether that backbone can recover after damage.

This layer asks:

```text
If the critical structure is partially broken,
can it re-enter a coherent connected state?
```

## What v14 Adds

1. Damage simulation
   - hub attack
   - random node loss

2. Quarantine logic
   Damaged nodes are removed from the graph temporarily.

3. Recovery edge regeneration
   The system attempts to reconnect damaged/isolated nodes by relaxing the edge threshold slightly.

4. Re-entry score
   Measures how much of the lost giant component is restored.

5. Recovery classification
   - recovered
   - partial_recovery
   - failed

## Run

```bash
python scripts/generate_invariant_modes.py
python scripts/engine_v14_recovery.py --input results/invariance_results_all.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/recovery_summary.json
results/recovery_trials.json
validation/triple_validation_summary.json
```

## Interpretation

- recovery_capable:
  the network can restore large-scale coherence after meaningful damage.

- limited_recovery:
  the network can recover partially, but not reliably.

- recovery_failed:
  the critical backbone breaks and does not restore.

## Limitation

This is still a computational topology sandbox.  
It validates recovery logic, not physical implementation.
