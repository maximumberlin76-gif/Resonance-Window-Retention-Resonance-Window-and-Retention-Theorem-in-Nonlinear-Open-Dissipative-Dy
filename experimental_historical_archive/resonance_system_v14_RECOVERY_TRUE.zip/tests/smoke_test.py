#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v14_recovery.py","results/recovery_summary.json","results/recovery_trials.json","docs/README.md"]:
    fp=Path(p); assert fp.exists() and fp.stat().st_size>100, p
s=json.load(open("results/recovery_summary.json","r",encoding="utf-8"))
assert "mean_reentry_score" in s and "all_trials" in s
print("SMOKE_OK")
