# Resonance System v26 TRUE FALLBACK vs STEPPED RE-LOCK

## Purpose

v25 showed stepped re-lock can help, but also caused collapses.
v26 compares passive fallback and stepped re-lock on identical adversarial seeds.

This is not another comfort upgrade.
It is a control-policy comparison.

## Question

```text
When prediction fails, is stepped re-lock actually better than fallback?
```

## Tested Policies

1. fallback only  
   Passive emergency correction.

2. conservative re-lock  
   Enters re-lock later and more carefully.

3. base re-lock  
   Same logic as v25.

4. aggressive re-lock  
   Enters re-lock early and strongly.

## Metrics

- delta_S
- delta_false_prediction_damage
- delta_lock_loss
- relock_success_rate
- relock_collapse
- best_profile

## Run

```bash
python scripts/engine_v26_compare.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/fallback_vs_relock_summary.json
results/fallback_vs_relock_trials.json
validation/triple_validation_summary.json
journal/session_journal_v26.md
```

## Interpretation

- relock_beats_fallback:
  best re-lock profile improves score without adding collapse.

- fallback_safer_or_equal:
  passive fallback remains safer under current settings.

## Limitation

Computational sandbox only.
