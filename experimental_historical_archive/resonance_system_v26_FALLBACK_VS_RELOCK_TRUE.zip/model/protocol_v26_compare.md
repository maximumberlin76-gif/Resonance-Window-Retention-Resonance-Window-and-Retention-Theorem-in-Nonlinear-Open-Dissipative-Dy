# v26 Protocol

1. Generate identical adversarial seeds.
2. Run fallback-only controller.
3. Run conservative re-lock.
4. Run base re-lock.
5. Run aggressive re-lock.
6. Compare:
   - score delta
   - false-damage delta
   - lock-loss delta
   - collapse count
7. Select best profile.
