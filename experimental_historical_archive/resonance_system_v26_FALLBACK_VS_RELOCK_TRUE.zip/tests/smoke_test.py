#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v26_compare.py","results/fallback_vs_relock_summary.json","results/fallback_vs_relock_trials.json","docs/README.md"]:
    fp=Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s=json.load(open("results/fallback_vs_relock_summary.json","r",encoding="utf-8"))
assert "best_profile" in s and "profile_summaries" in s
print("SMOKE_OK")
