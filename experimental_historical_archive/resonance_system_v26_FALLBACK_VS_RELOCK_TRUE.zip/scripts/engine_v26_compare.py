#!/usr/bin/env python3
"""
Resonance System v26 TRUE FALLBACK vs STEPPED RE-LOCK

Purpose:
Compare v24 passive fallback and v25 stepped re-lock on identical adversarial seeds.

v25 had relock_collapse = 5.
v26 asks:
- Was relock worse than fallback?
- Which relock entry thresholds cause harmful switching?
- Can threshold tuning reduce collapse?

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from typing import Dict, Any, List

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs) / max(1, len(xs))

def heavy_noise(rng, base, p, scale):
    return rng.uniform(-base*scale, base*scale) if rng.random() < p else rng.uniform(-base, base)

def should_enter_relock(tracking, confidence, false_damage_step, fallback_streak, rp):
    return (
        tracking > rp["tracking_enter"]
        or confidence < rp["confidence_enter"]
        or false_damage_step > rp["false_damage_enter"]
        or fallback_streak >= rp["fallback_streak_enter"]
    )

def relock_control(state, true_center, cfg, rp):
    phase = state["phase"]
    f0 = state["f0"]
    anchor = state["anchor"]

    if phase == "freeze":
        control = 0.0
        state["ticks"] += 1
        if state["ticks"] >= rp["freeze_steps"]:
            state["phase"] = "anchor"
            state["ticks"] = 0

    elif phase == "anchor":
        control = rp["anchor_gain"] * (anchor - f0)
        state["ticks"] += 1
        if abs(anchor - f0) / max(1.0, abs(anchor)) < rp["anchor_tolerance"] or state["ticks"] >= rp["anchor_max_steps"]:
            state["phase"] = "spiral"
            state["ticks"] = 0

    elif phase == "spiral":
        dither = rp["dither_amp"] * math.sin(state["ticks"] * rp["dither_rate"])
        control = rp["spiral_gain"] * (true_center - f0) + dither
        state["ticks"] += 1
        tracking = abs(true_center - (f0 + control)) / max(1.0, abs(true_center))
        if tracking < rp["lock_candidate_error"] or state["ticks"] >= rp["spiral_max_steps"]:
            state["phase"] = "confirm"
            state["ticks"] = 0
            state["confirm"] = 1 if tracking < rp["lock_candidate_error"] else 0

    elif phase == "confirm":
        control = rp["confirm_gain"] * (true_center - f0)
        tracking = abs(true_center - (f0 + control)) / max(1.0, abs(true_center))
        if tracking < rp["confirm_error"]:
            state["confirm"] += 1
        else:
            state["confirm"] = 0
            state["phase"] = "spiral"
            state["ticks"] = 0
        if state["confirm"] >= rp["confirm_steps"]:
            state["phase"] = "return"
            state["ticks"] = 0

    else:
        control = rp["return_gain"] * (true_center - f0)
        state["ticks"] += 1
        if state["ticks"] >= rp["return_steps"]:
            state["mode"] = "model"
            state["phase"] = None
            state["ticks"] = 0
            state["confirm"] = 0

    max_control = abs(true_center) * rp["max_control_ratio"]
    return clamp(control, -max_control, max_control)

def model_control(f0, predicted, confidence, cfg, force_fallback=False):
    err = predicted - f0
    if force_fallback or confidence < cfg["model"]["min_confidence"]:
        ratio = cfg["fallback"]["max_delta_ratio"]
        kp = cfg["fallback"]["kp"]
    else:
        ratio = cfg["model"]["max_control_ratio"]
        kp = cfg["model"]["kp"]
    max_control = abs(predicted) * ratio
    return clamp(kp * err, -max_control, max_control)

def run_trial(seed, mode, cfg, relock_profile=None):
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    true_center = rng.choice([76.4, 150.0, 458.4])
    f0 = true_center
    C = rng.uniform(0.70, 0.92)

    history = [true_center]
    latency = [true_center] * cfg["adversarial"]["latency_steps"]

    relock_state = {"mode": "model", "phase": None, "ticks": 0, "confirm": 0, "anchor": true_center, "f0": f0}
    fallback_streak = 0
    relock_entries = 0
    relock_success = 0
    relock_times = []
    relock_start = None

    lock_loss = 0
    false_damage = 0.0
    shock_events = 0
    shock_recovered = 0
    shock_start = None
    collapsed = False
    collapse_at = None
    series = []

    for t in range(cycles):
        drift = cfg["floating"]["drift_rate"] * math.sin(2*math.pi*t/cfg["floating"]["period"])
        noise = heavy_noise(rng, cfg["noise"], cfg["adversarial"]["heavy_tail_prob"], cfg["adversarial"]["tail_scale"])
        true_center += drift + noise

        jump = 0.0
        if rng.random() < cfg["adversarial"]["jump_prob"]:
            jump = rng.choice([-1,1]) * rng.uniform(cfg["adversarial"]["jump_min"], cfg["adversarial"]["jump_max"])
            true_center += jump
            shock_events += 1
            shock_start = t

        latency.append(true_center)
        observed = latency.pop(0)
        history.append(observed)

        h = history[-cfg["predictor"]["history"]:]
        drift_est = (h[-1] - h[0]) / max(1, len(h)-1) if len(h) > 1 else 0.0

        fake = 0.0
        fake_signal = False
        if rng.random() < cfg["adversarial"]["fake_drift_prob"]:
            fake = rng.choice([-1,1]) * rng.uniform(cfg["adversarial"]["fake_drift_min"], cfg["adversarial"]["fake_drift_max"])
            fake_signal = True

        confidence_bias = cfg["adversarial"]["confidence_trap_bias"] if rng.random() < cfg["adversarial"]["confidence_trap_prob"] else 0.0
        predicted = observed + cfg["predictor"]["lead"] * (drift_est + fake)
        confidence = clamp(1.0 - abs(fake)/max(1.0, abs(observed))*cfg["predictor"]["uncertainty_gain"] + confidence_bias)

        tracking_before = abs(true_center - f0) / max(1.0, abs(true_center))
        predicted_tracking = abs(predicted - f0) / max(1.0, abs(predicted))

        false_step = 0.0
        if fake_signal and tracking_before > predicted_tracking:
            false_step = tracking_before - predicted_tracking
            false_damage += false_step

        force_fallback = tracking_before > cfg["fallback"]["force_tracking_error"] or confidence < cfg["model"]["min_confidence"]

        used_relock = False
        if mode == "relock":
            rp = relock_profile
            if relock_state["mode"] == "model" and should_enter_relock(tracking_before, confidence, false_step, fallback_streak, rp):
                relock_state.update({"mode": "relock", "phase": "freeze", "ticks": 0, "confirm": 0, "anchor": observed})
                relock_entries += 1
                relock_start = t

            if relock_state["mode"] == "relock":
                relock_state["f0"] = f0
                control = relock_control(relock_state, true_center, cfg, rp)
                used_relock = True
                fallback_streak = 0
                if relock_state["mode"] == "model" and relock_start is not None:
                    relock_success += 1
                    relock_times.append(t - relock_start)
                    relock_start = None
            else:
                control = model_control(f0, predicted, confidence, cfg, force_fallback=force_fallback)
                fallback_streak = fallback_streak + 1 if force_fallback else 0
        else:
            control = model_control(f0, predicted, confidence, cfg, force_fallback=force_fallback)
            fallback_streak = fallback_streak + 1 if force_fallback else 0

        max_control = abs(true_center) * cfg["model"]["absolute_max_control_ratio"]
        control = clamp(control, -max_control, max_control)

        f0 += control
        tracking = abs(true_center - f0) / max(1.0, abs(true_center))
        in_corridor = tracking <= (cfg["floating"]["base_corridor"] + cfg["floating"]["max_extra_corridor"])
        if not in_corridor:
            lock_loss += 1

        if shock_start is not None and in_corridor:
            shock_recovered += 1
            shock_start = None

        D = cfg["dissipation_rate"] * (1 + 0.010*t)
        repair = cfg["recovery_gain"] * max(0.0, 1.0 - C)
        lock_support = cfg["floating"]["lock_support"]*(1-tracking) if in_corridor else -cfg["floating"]["lock_penalty"]
        mode_support = (cfg["relock"]["support"] if used_relock else 0.0) if mode == "relock" else (cfg["fallback"]["fallback_support"] if force_fallback else 0.0)
        damage_penalty = cfg["adversarial"]["false_damage_penalty"] * false_step
        C = clamp(C + repair + lock_support + mode_support - D - damage_penalty + rng.uniform(-cfg["noise"], cfg["noise"]))

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

        series.append({
            "t": t,
            "mode": mode,
            "control_mode": "relock" if used_relock else ("fallback" if force_fallback else "model"),
            "true_center": true_center,
            "observed": observed,
            "predicted": predicted,
            "confidence": confidence,
            "tracking_error": tracking,
            "false_step": false_step,
            "jump": jump,
            "C": C,
            "in_corridor": in_corridor
        })

    mean_C = mean([x["C"] for x in series])
    var_C = mean([(x["C"]-mean_C)**2 for x in series])
    mean_tracking = mean([x["tracking_error"] for x in series])
    lock_loss_rate = lock_loss / cycles
    shock_recovery_rate = shock_recovered / max(1, shock_events)
    false_damage_per_cycle = false_damage / cycles
    relock_success_rate = relock_success / max(1, relock_entries)
    mean_relock_time = mean(relock_times) if relock_times else None

    S = mean_C - var_C - 0.45*mean_tracking - 0.35*lock_loss_rate - 0.25*false_damage_per_cycle + 0.10*shock_recovery_rate
    if mode == "relock":
        S += 0.12 * relock_success_rate

    label = "collapse" if collapsed else ("stable" if S >= cfg["thresholds"]["stable"] else ("metastable" if S >= cfg["thresholds"]["metastable"] else "weak"))

    return {
        "mode": mode,
        "seed": seed,
        "mean_C": mean_C,
        "var_C": var_C,
        "mean_tracking_error": mean_tracking,
        "lock_loss_rate": lock_loss_rate,
        "shock_events": shock_events,
        "shock_recovery_rate": shock_recovery_rate,
        "false_prediction_damage": false_damage,
        "false_damage_per_cycle": false_damage_per_cycle,
        "relock_entries": relock_entries,
        "relock_success": relock_success,
        "relock_success_rate": relock_success_rate,
        "mean_relock_time": mean_relock_time,
        "S": S,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "label": label,
        "series": series
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    seeds = [cfg["seed"] + i*100 for i in range(cfg["trials"])]

    profiles = cfg["relock_profiles"]
    comparisons = []
    profile_summaries = []

    fallback_rows = [run_trial(seed, "fallback", cfg) for seed in seeds]

    for pname, profile in profiles.items():
        relock_rows = [run_trial(seed, "relock", cfg, relock_profile=profile) for seed in seeds]

        paired = []
        for fb, rl in zip(fallback_rows, relock_rows):
            paired.append({
                "seed": fb["seed"],
                "fallback_label": fb["label"],
                "relock_label": rl["label"],
                "delta_S": rl["S"] - fb["S"],
                "delta_false_damage": rl["false_prediction_damage"] - fb["false_prediction_damage"],
                "delta_lock_loss": rl["lock_loss_rate"] - fb["lock_loss_rate"],
                "fallback": fb,
                "relock": rl
            })

        summary = {
            "profile": pname,
            "trials": len(relock_rows),
            "fallback_stable_or_meta": sum(1 for r in fallback_rows if r["label"] in ("stable","metastable")),
            "relock_stable_or_meta": sum(1 for r in relock_rows if r["label"] in ("stable","metastable")),
            "fallback_collapse": sum(1 for r in fallback_rows if r["label"] == "collapse"),
            "relock_collapse": sum(1 for r in relock_rows if r["label"] == "collapse"),
            "mean_delta_S": mean([p["delta_S"] for p in paired]),
            "mean_delta_false_damage": mean([p["delta_false_damage"] for p in paired]),
            "mean_delta_lock_loss": mean([p["delta_lock_loss"] for p in paired]),
            "mean_relock_success_rate": mean([r["relock_success_rate"] for r in relock_rows]),
            "mean_relock_time": mean([r["mean_relock_time"] for r in relock_rows if r["mean_relock_time"] is not None]) if any(r["mean_relock_time"] is not None for r in relock_rows) else None,
            "paired": paired
        }
        profile_summaries.append(summary)
        comparisons.extend(paired)

    best = max(profile_summaries, key=lambda x: (x["mean_delta_S"], -x["relock_collapse"], -abs(x["mean_delta_false_damage"])))

    total_summary = {
        "trials": len(seeds),
        "profiles_tested": list(profiles.keys()),
        "best_profile": best["profile"],
        "best_mean_delta_S": best["mean_delta_S"],
        "best_mean_delta_false_damage": best["mean_delta_false_damage"],
        "best_mean_delta_lock_loss": best["mean_delta_lock_loss"],
        "best_relock_collapse": best["relock_collapse"],
        "best_mean_relock_success_rate": best["mean_relock_success_rate"],
        "profile_summaries": profile_summaries,
        "label": "relock_beats_fallback" if best["mean_delta_S"] > 0 and best["relock_collapse"] <= best["fallback_collapse"] else "fallback_safer_or_equal"
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(total_summary, open(out/"fallback_vs_relock_summary.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump({"fallback_rows": fallback_rows, "profile_summaries": profile_summaries}, open(out/"fallback_vs_relock_trials.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": total_summary["trials"],
        "profiles_tested": total_summary["profiles_tested"],
        "best_profile": total_summary["best_profile"],
        "best_mean_delta_S": total_summary["best_mean_delta_S"],
        "best_mean_delta_false_damage": total_summary["best_mean_delta_false_damage"],
        "best_relock_collapse": total_summary["best_relock_collapse"],
        "best_mean_relock_success_rate": total_summary["best_mean_relock_success_rate"],
        "label": total_summary["label"]
    }, indent=2))

if __name__ == "__main__":
    main()
