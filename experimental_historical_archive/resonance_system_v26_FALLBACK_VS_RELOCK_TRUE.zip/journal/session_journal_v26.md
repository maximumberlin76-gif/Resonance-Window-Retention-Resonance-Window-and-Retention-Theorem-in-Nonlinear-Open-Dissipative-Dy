# Session Journal — v26

## Step

v26 — Fallback vs Stepped Re-lock on identical adversarial seeds.

## Reason

v25 introduced stepped re-lock but produced 5 collapses.
Therefore we need direct comparison with fallback and threshold tuning.

## Added

- same-seed policy comparison
- conservative/base/aggressive re-lock profiles
- delta_S
- delta_false_prediction_damage
- delta_lock_loss
- best_profile selection

## Core Principle

A self-healing controller must prove it beats simpler fallback.
If it does not, fallback remains safer.

## Next Candidate Step

v27 — optimize the winning re-lock profile with parameter sweep / Bayesian-like search.
