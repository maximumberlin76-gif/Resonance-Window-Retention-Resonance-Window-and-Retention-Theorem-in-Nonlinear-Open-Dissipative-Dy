#!/usr/bin/env python3
from pathlib import Path
import json, random
random.seed(2222)
rows = []
for i in range(18):
    rows.append({
        "trial_index": i,
        "label": "gain_stable",
        "reentry_norm": random.uniform(0.76, 1.0),
        "new_edge_penalty": random.uniform(0.03, 0.16),
        "mean_C": random.uniform(0.74, 0.96),
        "S_gain": random.uniform(0.70, 0.94),
        "mean_tracking_error": random.uniform(0.001, 0.010),
        "mean_predictive_error": random.uniform(0.001, 0.006),
        "overshoot_rate": 0.0,
        "lock_loss_rate": random.uniform(0.0, 0.02),
        "series": []
    })
Path("results").mkdir(exist_ok=True)
json.dump(rows, open("results/adaptive_gain_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("generated adaptive gain trials", len(rows))
