#!/usr/bin/env python3
"""
Resonance System v22 TRUE STATE-AWARE CONTROL

v21 solved overshoot with adaptive gain scheduling.
v22 adds memory of system state.

Core additions:
- integral error memory
- derivative damping
- regime switch: calm / tracking / recovery / danger
- state vector H(t)
- controller output depends on present + memory

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from typing import Dict, Any, List

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def mean(xs: List[float]) -> float:
    return sum(xs) / max(1, len(xs))

def classify_regime(tracking_error: float, lock_loss_streak: int, C: float, cfg: Dict[str, Any]) -> str:
    if C < cfg["regime"]["danger_C"] or lock_loss_streak >= cfg["regime"]["danger_lock_streak"]:
        return "danger"
    if C < cfg["regime"]["recovery_C"]:
        return "recovery"
    if tracking_error > cfg["regime"]["tracking_error"]:
        return "tracking"
    return "calm"

def simulate_trial(trial: Dict[str, Any], cfg: Dict[str, Any], seed: int) -> Dict[str, Any]:
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    window_center = trial.get("f_center", rng.choice([76.4, 150.0, 458.4]))
    f0 = window_center
    C = clamp(trial["reentry_norm"] - trial["new_edge_penalty"])

    # State memory
    integral_error = 0.0
    prev_error = 0.0
    prev_delta = 0.0
    lock_loss_streak = 0
    regime_counts = {"calm": 0, "tracking": 0, "recovery": 0, "danger": 0}

    history = [window_center]
    series = []
    collapsed = False
    collapse_at = None

    for t in range(cycles):
        # Floating window
        drift = cfg["floating"]["drift_rate"] * math.sin(2 * math.pi * t / cfg["floating"]["period"])
        jitter = rng.uniform(-cfg["floating"]["jitter"], cfg["floating"]["jitter"])
        window_center += drift + jitter
        history.append(window_center)

        # Predictor
        recent = history[-cfg["predictor"]["history"]:]
        predicted_drift = (recent[-1] - recent[0]) / max(1, len(recent) - 1) if len(recent) > 1 else 0.0
        predicted_center = window_center + cfg["predictor"]["lead"] * predicted_drift

        error = predicted_center - f0
        tracking_error = abs(window_center - f0) / max(1.0, abs(window_center))
        predictive_error = abs(predicted_center - window_center) / max(1.0, abs(window_center))

        # State-aware memory
        integral_error = clamp(
            integral_error + error / max(1.0, abs(window_center)),
            -cfg["state"]["integral_limit"],
            cfg["state"]["integral_limit"]
        )
        derivative_error = (error - prev_error) / max(1.0, abs(window_center))

        local_regime = classify_regime(tracking_error, lock_loss_streak, C, cfg)
        regime_counts[local_regime] += 1

        # Regime-specific gains
        rp = cfg["regime_params"][local_regime]
        kp = rp["kp"]
        ki = rp["ki"]
        kd = rp["kd"]
        max_delta_ratio = rp["max_delta_ratio"]

        # PID-like control term
        control = (
            kp * error
            + ki * integral_error * abs(window_center)
            + kd * derivative_error * abs(window_center)
        )

        # Jerk limiter
        jerk = control - prev_delta
        max_jerk = abs(window_center) * cfg["state"]["max_jerk_ratio"]
        if abs(jerk) > max_jerk:
            control = prev_delta + max_jerk * (1 if jerk > 0 else -1)

        # Delta limiter
        max_delta = abs(window_center) * max_delta_ratio
        if abs(control) > max_delta:
            control = max_delta * (1 if control > 0 else -1)

        f0 += control
        f1 = 2.0 * f0
        f2 = 0.5 * f0

        # Corridor and lock
        new_tracking_error = abs(window_center - f0) / max(1.0, abs(window_center))
        corridor = cfg["floating"]["base_corridor"] + min(
            cfg["floating"]["max_extra_corridor"],
            abs(predicted_drift) / max(1.0, abs(window_center)) * cfg["floating"]["corridor_gain"]
        )
        in_corridor = new_tracking_error <= corridor

        if in_corridor:
            lock_loss_streak = 0
        else:
            lock_loss_streak += 1

        # Coherence dynamics
        D_t = cfg["dissipation_rate"] * (1.0 + 0.009 * t)
        noise = rng.uniform(-cfg["noise"], cfg["noise"])
        repair = cfg["recovery_gain"] * max(0.0, 1.0 - C)

        regime_support = rp["support"]
        lock_support = cfg["floating"]["lock_support"] * (1.0 - new_tracking_error) if in_corridor else -cfg["floating"]["lock_penalty"]

        memory_penalty = cfg["state"]["integral_penalty"] * abs(integral_error)
        derivative_penalty = cfg["state"]["derivative_penalty"] * abs(derivative_error)

        C = clamp(C + repair + lock_support + regime_support - D_t - memory_penalty - derivative_penalty + noise)

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

        series.append({
            "t": t,
            "window_center": window_center,
            "predicted_center": predicted_center,
            "predicted_drift": predicted_drift,
            "f0": f0,
            "f1": f1,
            "f2": f2,
            "regime": local_regime,
            "error": error,
            "tracking_error": new_tracking_error,
            "predictive_error": predictive_error,
            "integral_error": integral_error,
            "derivative_error": derivative_error,
            "control": control,
            "corridor": corridor,
            "in_corridor": in_corridor,
            "lock_loss_streak": lock_loss_streak,
            "C": C,
            "D_t": D_t,
            "repair": repair,
            "lock_support": lock_support,
            "regime_support": regime_support,
            "memory_penalty": memory_penalty,
            "derivative_penalty": derivative_penalty,
            "noise": noise
        })

        prev_error = error
        prev_delta = control

    Cs = [x["C"] for x in series]
    tracking_errors = [x["tracking_error"] for x in series]
    predictive_errors = [x["predictive_error"] for x in series]
    controls = [x["control"] for x in series]
    lock_loss_rate = sum(1 for x in series if not x["in_corridor"]) / cycles

    mean_C = mean(Cs)
    var_C = mean([(x - mean_C) ** 2 for x in Cs])
    mean_tracking_error = mean(tracking_errors)
    mean_predictive_error = mean(predictive_errors)
    mean_abs_control = mean([abs(x) for x in controls])
    control_var = mean([(x - mean(controls)) ** 2 for x in controls])

    S_state = (
        mean_C
        - var_C
        - 0.35 * lock_loss_rate
        - 0.45 * mean_tracking_error
        - 0.25 * mean_predictive_error
        - 0.10 * control_var
    )

    if collapsed:
        label = "state_collapse"
    elif S_state >= cfg["thresholds"]["state_stable"] and lock_loss_rate <= cfg["thresholds"]["max_lock_loss"]:
        label = "state_stable"
    elif S_state >= cfg["thresholds"]["state_metastable"]:
        label = "state_metastable"
    else:
        label = "state_weak"

    return {
        "mean_C": mean_C,
        "var_C": var_C,
        "mean_tracking_error": mean_tracking_error,
        "mean_predictive_error": mean_predictive_error,
        "mean_abs_control": mean_abs_control,
        "control_var": control_var,
        "lock_loss_rate": lock_loss_rate,
        "regime_counts": regime_counts,
        "S_state": S_state,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "label": label,
        "series": series
    }

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="results/adaptive_gain_trials.json")
    parser.add_argument("--outdir", default="results")
    args = parser.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    trials = json.load(open(args.input, "r", encoding="utf-8"))

    rows = []
    for idx, trial in enumerate(trials):
        base = {
            "trial_index": trial.get("trial_index", idx),
            "previous_label": trial.get("label", "gain_unknown"),
            "reentry_norm": trial.get("reentry_norm", 0.82),
            "new_edge_penalty": trial.get("new_edge_penalty", 0.10),
            "f_center": [76.4, 150.0, 458.4][idx % 3],
        }
        sim = simulate_trial(base, cfg, cfg["seed"] + idx * 100)
        rows.append({**base, **sim})

    stable = [r for r in rows if r["label"] == "state_stable"]
    meta = [r for r in rows if r["label"] == "state_metastable"]
    weak = [r for r in rows if r["label"] == "state_weak"]
    collapse = [r for r in rows if r["label"] == "state_collapse"]

    summary = {
        "trials": len(rows),
        "state_stable": len(stable),
        "state_metastable": len(meta),
        "state_weak": len(weak),
        "state_collapse": len(collapse),
        "mean_S_state": mean([r["S_state"] for r in rows]),
        "mean_tracking_error": mean([r["mean_tracking_error"] for r in rows]),
        "mean_predictive_error": mean([r["mean_predictive_error"] for r in rows]),
        "mean_lock_loss_rate": mean([r["lock_loss_rate"] for r in rows]),
        "mean_abs_control": mean([r["mean_abs_control"] for r in rows]),
        "label": "state_aware_success" if len(stable) + len(meta) >= len(rows) * 0.75 and len(collapse) == 0 else "state_aware_limited",
        "top_trials": sorted(rows, key=lambda x: x["S_state"], reverse=True)[:10],
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out / "state_control_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out / "state_control_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "state_stable": summary["state_stable"],
        "state_metastable": summary["state_metastable"],
        "state_weak": summary["state_weak"],
        "state_collapse": summary["state_collapse"],
        "mean_S_state": summary["mean_S_state"],
        "mean_lock_loss_rate": summary["mean_lock_loss_rate"],
        "label": summary["label"]
    }, indent=2))

if __name__ == "__main__":
    main()
