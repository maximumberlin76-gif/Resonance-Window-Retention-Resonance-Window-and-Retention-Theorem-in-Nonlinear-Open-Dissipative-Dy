#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v22_state_control.py","results/state_control_summary.json","results/state_control_trials.json","docs/README.md"]:
    fp = Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s = json.load(open("results/state_control_summary.json", "r", encoding="utf-8"))
assert "mean_S_state" in s and "all_trials" in s
print("SMOKE_OK")
