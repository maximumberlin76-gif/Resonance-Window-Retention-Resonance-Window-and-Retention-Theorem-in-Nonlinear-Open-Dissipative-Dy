# Resonance System v22 TRUE STATE-AWARE CONTROL

## Purpose

v21 solved overshoot by adaptive gain scheduling.  
v22 adds memory of the system state.

The controller is no longer only reactive.  
It remembers accumulated error, detects derivative change, and switches regime.

## Core Shift

```text
v21 = gain depends on current error
v22 = control depends on current error + memory + regime
```

## Added Mechanisms

1. Integral memory  
   Tracks accumulated normalized error.

2. Derivative damping  
   Reacts to fast error changes.

3. Regime switching  
   The controller switches between:

   - calm
   - tracking
   - recovery
   - danger

4. Regime-specific control parameters  
   Each regime has different kp / ki / kd / max_delta / support.

5. State score  
   Stability includes coherence, lock loss, tracking error, predictive error, and control variance.

## Run

```bash
python scripts/generate_adaptive_gain_seed.py
python scripts/engine_v22_state_control.py --input results/adaptive_gain_trials.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/state_control_summary.json
results/state_control_trials.json
validation/triple_validation_summary.json
```

## Interpretation

- state_stable:
  state-aware control keeps lock and coherence.

- state_metastable:
  control holds, but with fragility.

- state_weak:
  state memory helps but not enough.

- state_collapse:
  coherence collapses.

## Engineering Meaning

v22 moves the architecture from adaptive gain toward a PID-like state-aware controller.

## Limitation

Computational sandbox only.
