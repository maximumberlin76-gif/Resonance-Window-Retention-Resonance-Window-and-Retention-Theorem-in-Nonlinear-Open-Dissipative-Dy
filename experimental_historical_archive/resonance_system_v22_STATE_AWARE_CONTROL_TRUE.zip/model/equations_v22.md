# v22 Equations

control =
kp * error
+ ki * integral_error * abs(window_center)
+ kd * derivative_error * abs(window_center)

S_state =
mean_C
- var_C
- 0.35 * lock_loss_rate
- 0.45 * mean_tracking_error
- 0.25 * mean_predictive_error
- 0.10 * control_var

Regime:
calm / tracking / recovery / danger
