# v22 State-Aware Control Protocol

1. Load adaptive-gain trials from v21.
2. Simulate floating window.
3. Predict local drift.
4. Compute:
   - tracking_error
   - predictive_error
   - integral_error
   - derivative_error
5. Classify regime:
   - calm
   - tracking
   - recovery
   - danger
6. Apply regime-specific kp/ki/kd.
7. Limit jerk and delta.
8. Update f0, f1, f2.
9. Compute state stability score.
10. Classify state control result.
