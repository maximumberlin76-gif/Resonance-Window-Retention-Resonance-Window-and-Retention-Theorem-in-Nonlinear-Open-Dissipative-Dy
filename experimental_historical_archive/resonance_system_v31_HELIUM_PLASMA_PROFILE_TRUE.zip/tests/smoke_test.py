#!/usr/bin/env python3
from pathlib import Path
import json
for item in ["scripts/engine_v31_helium_plasma_profile.py","results/helium_plasma_profile_summary.json","results/helium_plasma_profile_trials.json","docs/README.md","model/equations_v31.md","journal/session_journal_v31.md"]:
    p=Path(item)
    assert p.exists(), item
    assert p.stat().st_size>100, item
s=json.load(open("results/helium_plasma_profile_summary.json","r",encoding="utf-8"))
assert s["system_class"]=="nonlinear dissipative open dynamic systems"
print("SMOKE_OK")
