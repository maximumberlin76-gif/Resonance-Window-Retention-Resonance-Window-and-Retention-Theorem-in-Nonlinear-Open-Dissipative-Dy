# Session Journal — v31

## Step

v31 — Helium Plasma Resonance Window Profile.

## Reason

After argon, helium tests whether the resonance-window framework transfers to a lighter noble gas.

## Added

- helium ionization reference
- faster response proxy
- higher drift sensitivity
- helium spectral scan
- useful coherent work W_coh
- resonance-window candidate classification

## Core Principle

Helium should respond faster than argon, but should also lose retention more easily under drift.
