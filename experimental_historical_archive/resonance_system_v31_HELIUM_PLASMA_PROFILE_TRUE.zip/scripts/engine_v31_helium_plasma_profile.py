#!/usr/bin/env python3
"""
v31 TRUE HELIUM PLASMA RESONANCE WINDOW PROFILE

System class:
nonlinear dissipative open dynamic systems

This is a computational resonance-window sandbox, not a laboratory measurement.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0): return max(lo, min(hi, x))
def mean(xs): return sum(xs) / max(1, len(xs))
def gaussian(x, mu, sigma): return math.exp(-0.5*((x-mu)/max(1e-12,sigma))**2)

def spectrum_score(freq_mhz, duty, pressure_mTorr, cfg):
    h = cfg["helium"]
    anchor = h["acoustic_anchor_mhz"]
    anchor_component = gaussian(freq_mhz, anchor, 2.8)
    harmonic_component = 0.60 * gaussian(freq_mhz, anchor*2.0, 5.0)
    rf_component = 0.45 * gaussian(freq_mhz, h["rf_reference_mhz"], 3.0)
    pressure_component = gaussian(pressure_mTorr, h["pressure_center_mTorr"], h["pressure_sigma_mTorr"])
    duty_component = gaussian(duty, h["duty_center"], h["duty_sigma"])
    return clamp((anchor_component + harmonic_component + rf_component) * pressure_component * duty_component)

def simulate(seed, drive, cfg):
    rng = random.Random(seed)
    steps = cfg["simulation"]["steps"]
    period_steps = cfg["simulation"]["period_steps"]
    h = cfg["helium"]

    Te = rng.uniform(3.5, 7.0)
    ne = rng.uniform(5e8, 3e10)
    ion_frac = rng.uniform(1e-6, 1e-4)
    C = rng.uniform(0.30, 0.50)

    W_coh = 0.0
    theta = 0.0
    stable_periods = 0
    period_work = 0.0
    period_theta = 0.0
    chaos_events = 0
    drift_events = 0
    sample = []
    spec = spectrum_score(drive["freq_mhz"], drive["duty"], drive["pressure_mTorr"], cfg)

    for t in range(steps):
        phase = 2 * math.pi * (t % period_steps) / period_steps
        pulse = 1.0 if (t % period_steps) < int(period_steps * drive["duty"]) else 0.0
        modulation = 1.0 + 0.20 * math.sin(phase)

        heating = drive["power_norm"] * spec * pulse * modulation
        collision_rate = drive["pressure_mTorr"] / 350.0
        drift_pressure = 0.06 * abs(math.sin(2 * math.pi * t / max(1, steps)))

        dissipation = h["base_dissipation"] + 0.08 * collision_rate + 0.035 * abs(Te - h["Te_target_eV"])
        destructive = h["base_pressure"] + 0.07 * max(0.0, Te - h["Te_upper_soft_eV"]) + drift_pressure

        useful_alignment = spec * pulse * gaussian(Te, h["Te_target_eV"], h["Te_sigma_eV"])
        useful_work_step = useful_alignment * drive["power_norm"] * cfg["simulation"]["work_gain"]

        Te += 0.055*heating - 0.030*(Te - h["Te_relax_eV"]) - 0.010*collision_rate + rng.uniform(-0.020, 0.020)
        Te = max(0.1, min(30.0, Te))

        ion_drive = gaussian(Te, h["Te_ionization_eff_eV"], h["Te_ionization_sigma_eV"]) * heating
        ion_frac = clamp(ion_frac + 7e-4*ion_drive - 3e-4*collision_rate*ion_frac, 0.0, 0.05)
        ne = max(1e7, ne * (1.0 + 0.012*ion_drive - 0.003*collision_rate + rng.uniform(-0.004,0.004)))

        P = destructive
        D = dissipation
        C_prev = C
        C = clamp(C + 0.030*useful_alignment*(1-C) - 0.012*P - 0.010*D + rng.uniform(-cfg["simulation"]["noise"], cfg["simulation"]["noise"]))

        if abs(C - C_prev) > cfg["simulation"]["safe_dC_limit"]:
            chaos_events += 1
        if drift_pressure > 0.055:
            drift_events += 1

        delta = C - P - D
        if delta > 0:
            theta += delta
            period_theta += delta
            W_coh += useful_work_step
            period_work += useful_work_step

        if (t + 1) % period_steps == 0:
            if period_theta >= cfg["thresholds"]["period_theta_min"] and period_work >= cfg["thresholds"]["period_work_min"]:
                stable_periods += 1
            period_theta = 0.0
            period_work = 0.0

        if t % cfg["simulation"]["sample_every"] == 0 or t == steps - 1:
            sample.append({
                "step": t,
                "Te_eV": Te,
                "ne_cm3": ne,
                "ionization_fraction_proxy": ion_frac,
                "C": C,
                "P": P,
                "D": D,
                "delta": delta,
                "W_coh": W_coh,
                "theta": theta
            })

    chaos_rate = chaos_events / steps
    drift_rate = drift_events / steps

    if chaos_rate >= cfg["thresholds"]["chaos_rate_limit"]:
        outcome = "helium_chaotic_overdrive"
    elif stable_periods >= cfg["thresholds"]["closed_structure_periods"]:
        outcome = "helium_closed_structure_candidate"
    elif cfg["thresholds"]["synthesis_min_periods"] <= stable_periods <= cfg["thresholds"]["synthesis_max_periods"]:
        outcome = "helium_resonance_window_synthesis_candidate"
    elif stable_periods > 0:
        outcome = "helium_accumulation_in_progress"
    else:
        outcome = "helium_no_stable_window"

    return {
        "seed": seed,
        "drive": drive,
        "spectrum_score": spec,
        "W_coh": W_coh,
        "theta": theta,
        "stable_periods": stable_periods,
        "chaos_rate": chaos_rate,
        "drift_rate": drift_rate,
        "mean_C": mean([x["C"] for x in sample]),
        "mean_Te_eV": mean([x["Te_eV"] for x in sample]),
        "mean_ne_cm3": mean([x["ne_cm3"] for x in sample]),
        "mean_ionization_fraction_proxy": mean([x["ionization_fraction_proxy"] for x in sample]),
        "outcome": outcome,
        "series_sampled": sample
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))

    drives = []
    for freq in cfg["scan"]["freq_mhz"]:
        for power in cfg["scan"]["power_norm"]:
            for pressure in cfg["scan"]["pressure_mTorr"]:
                for duty in cfg["scan"]["duty"]:
                    drives.append({"freq_mhz":freq,"power_norm":power,"pressure_mTorr":pressure,"duty":duty})

    rows = [simulate(cfg["seed"] + i*100, drive, cfg) for i, drive in enumerate(drives)]
    outcomes = {}
    for r in rows:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1

    best = sorted(rows, key=lambda r:(r["outcome"]=="helium_resonance_window_synthesis_candidate", r["stable_periods"], r["W_coh"], r["spectrum_score"], -r["chaos_rate"]), reverse=True)[:12]
    freq_hits = {}
    for r in best:
        f = str(r["drive"]["freq_mhz"])
        freq_hits[f] = freq_hits.get(f,0)+1

    summary = {
        "system_class":"nonlinear dissipative open dynamic systems",
        "helium_reference":{
            "ionization_energy_eV":cfg["helium"]["ionization_energy_eV"],
            "rf_reference_mhz":cfg["helium"]["rf_reference_mhz"],
            "diagnostic_lines_nm":cfg["helium"]["diagnostic_lines_nm"],
            "note":"Computational profile, not laboratory measurement."
        },
        "trials":len(rows),
        "outcomes":outcomes,
        "best_candidates":best,
        "recommended_frequency_hits_mhz":freq_hits,
        "main_conclusion":"helium_window_is_faster_and_more_drift_sensitive_than_argon",
        "all_trials":rows
    }
    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"helium_plasma_profile_summary.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"helium_plasma_profile_trials.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
    print(json.dumps({"trials":len(rows),"outcomes":outcomes,"recommended_frequency_hits_mhz":freq_hits,"main_conclusion":summary["main_conclusion"]}, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
