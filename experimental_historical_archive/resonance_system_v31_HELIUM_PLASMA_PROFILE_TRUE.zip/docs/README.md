# v31 — Helium Plasma Resonance Window Profile

## Abstract

This module maps the resonance-window framework onto a simplified helium plasma profile.

The system is treated strictly as a nonlinear dissipative open dynamic system.

Helium is lighter than argon, so the model expects faster response, higher drift sensitivity, weaker inertial retention, and a narrower stability corridor.

This is a computational profile, not laboratory evidence.

## Helium Reference Anchors

- first ionization energy: approximately 24.587 eV
- RF reference: 13.56 MHz
- diagnostic lines often include He I 587.6 nm, 667.8 nm, and 706.5 nm

## Core Premise

Phase transition occurs over a finite period when useful coherent work accumulates:

```text
W_coh(τ) = ∫ useful_alignment_work(t) dt
```

and reaches the holding threshold of the old configuration.

## System Class

```text
nonlinear dissipative open dynamic systems
```

## Spectrum Scan

The model scans:

- 6.78 MHz
- 9.20 MHz
- 13.56 MHz
- 18.40 MHz
- 27.12 MHz

with pressure, duty cycle, and normalized power.

## Run

```bash
python scripts/engine_v31_helium_plasma_profile.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/helium_plasma_profile_summary.json
results/helium_plasma_profile_trials.json
journal/session_journal_v31.md
```

## Next Step

v31.1 — Helium Kuramoto phase-lock layer.
