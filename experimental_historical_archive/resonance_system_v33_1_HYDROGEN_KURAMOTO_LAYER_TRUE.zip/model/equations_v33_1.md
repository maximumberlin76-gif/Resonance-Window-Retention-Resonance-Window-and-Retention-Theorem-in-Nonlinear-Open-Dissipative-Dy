# v33.1 Equations

## Kuramoto Layer

dφ_i/dt =
ω_i
+ (K/N) Σ sin(φ_j - φ_i)
+ F_ext sin(ω_ext t - φ_i)
+ η_i(t)

## Order Parameter

R =
|(1/N) Σ exp(i φ_j)|

## Useful Coherent Work

W_coh(τ) =
∫ max(0, R(t) - R_floor) · F_ext(t) dt

## Mapping

R(t) -> C(t) -> W_coh(τ) -> Ω(t)
