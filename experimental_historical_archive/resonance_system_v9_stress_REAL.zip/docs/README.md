# Resonance System v9 STRESS REAL

Hard anti-self-deception version.

## Run
python scripts/engine_v9_stress.py --config configs/config.json --outdir results
python scripts/build_stress_attractor_map.py

## Criteria
stress_stable:
- 7 independent runs per mode
- R_off_mean >= 0.85
- R_off_std <= 0.05
- fail_rate <= 0.10
- R_shift_mean >= 0.75

This package includes generated results and triple ZIP validation.
