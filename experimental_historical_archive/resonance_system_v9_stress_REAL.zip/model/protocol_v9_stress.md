# v9 Stress Protocol

1. Enter candidate mode with multi-drive.
2. Measure R_on.
3. Turn drive OFF for long interval.
4. Measure R_off.
5. Apply shifted parameters under noise/drift.
6. Repeat for 7 independent seeds.
7. Compute mean/std/fail_rate.
8. Classify:
   - stress_stable
   - stress_metastable
   - reject

One successful run is not accepted.
