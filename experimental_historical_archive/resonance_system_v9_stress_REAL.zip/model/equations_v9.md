# v9 Equations

R = |mean(exp(i*theta_j))|

score = R_off_mean - R_off_std - fail_rate - 0.25*abs(R_on_mean - R_off_mean)
