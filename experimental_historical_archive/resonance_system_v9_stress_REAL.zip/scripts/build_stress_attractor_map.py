
#!/usr/bin/env python3
from pathlib import Path
from collections import defaultdict
import json, csv

def bucket(x, width=25.0):
    return str(round(float(x)/width)*width)

rows = json.load(open("results/stress_results_all.json", "r", encoding="utf-8"))
groups = defaultdict(list)
for r in rows:
    p = r["params"]
    groups[(bucket(p["f0"]), bucket(p["f1"]), bucket(p["f2"]))].append(r)

out = []
for key, items in groups.items():
    labels = [x["label"] for x in items]
    mean_score = sum(x["score"] for x in items)/len(items)
    mean_ret = sum(x["R_off_mean"] for x in items)/len(items)
    mean_fail = sum(x["fail_rate"] for x in items)/len(items)
    stable = labels.count("stress_stable")
    meta = labels.count("stress_metastable")
    reject = labels.count("reject")
    kind = "stress_stable_attractor" if stable else ("stress_metastable_cloud" if meta else "noise_or_false_peak")
    out.append({
        "bucket_f0": key[0], "bucket_f1": key[1], "bucket_f2": key[2],
        "count": len(items), "stable": stable, "metastable": meta, "reject": reject,
        "mean_score": mean_score, "mean_retention": mean_ret, "mean_fail_rate": mean_fail,
        "kind": kind, "samples": items[:3]
    })

out.sort(key=lambda x: (x["kind"]!="stress_stable_attractor", x["kind"]!="stress_metastable_cloud", -x["mean_score"]))
Path("results").mkdir(exist_ok=True); Path("logs").mkdir(exist_ok=True)
json.dump(out, open("results/stress_attractor_map.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
summary = {
    "total_buckets": len(out),
    "stress_stable_attractors": sum(1 for x in out if x["kind"]=="stress_stable_attractor"),
    "stress_metastable_clouds": sum(1 for x in out if x["kind"]=="stress_metastable_cloud"),
    "noise_or_false_peak": sum(1 for x in out if x["kind"]=="noise_or_false_peak"),
    "top_10": out[:10]
}
json.dump(summary, open("results/stress_attractor_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
with open("logs/stress_attractor_map.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["f0","f1","f2","kind","count","mean_score","mean_retention","mean_fail_rate"])
    for a in out:
        w.writerow([a["bucket_f0"],a["bucket_f1"],a["bucket_f2"],a["kind"],a["count"],a["mean_score"],a["mean_retention"],a["mean_fail_rate"]])
print(json.dumps(summary, indent=2, ensure_ascii=False))
