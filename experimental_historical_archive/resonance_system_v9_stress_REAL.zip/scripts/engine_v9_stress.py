
#!/usr/bin/env python3
"""
Resonance System v9 STRESS REAL - compact executable package.

Hard anti-self-deception filter:
- 7 independent runs per mode
- long OFF retention
- noise multiplier
- drift
- parameter-shift anti-lock test
- fail-rate filter

This is a computational sandbox/protocol engine, not physical validation.
"""

from __future__ import annotations
import argparse, json, math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List
import numpy as np

@dataclass
class ModeParams:
    f0: float
    f1: float
    f2: float
    A: float
    phi: float
    duty: float
    noise: float

@dataclass
class RunResult:
    R_on: float
    R_off: float
    R_shift: float
    survived: bool

class ResonanceSystem:
    def __init__(self, n=24, coupling_k=0.7, seed=None, drift_strength=0.06):
        self.n = n
        self.K = coupling_k
        self.drift_strength = drift_strength
        self.rng = np.random.default_rng(seed)
        self.theta = self.rng.uniform(0, 2*np.pi, self.n)
        self.omega = self.rng.uniform(0.92, 1.08, self.n)
        self.f_shift = 0.0

    def R(self):
        return float(np.abs(np.mean(np.exp(1j*self.theta))))

    def step(self, p: ModeParams, dt=0.05):
        self.f_shift += float(self.rng.uniform(-self.drift_strength, self.drift_strength))
        drift = 1.0 + self.f_shift * 0.01
        f0, f1, f2 = p.f0*drift, p.f1*drift, p.f2*drift
        drive = p.A * (
            math.sin(2*math.pi*f0*dt + p.phi) +
            math.sin(2*math.pi*f1*dt) +
            math.sin(2*math.pi*f2*dt)
        ) * p.duty
        new = self.theta.copy()
        for i in range(self.n):
            coupling = np.sum(np.sin(self.theta - self.theta[i])) / self.n
            new[i] += (self.omega[i] + self.K*coupling + drive + p.noise*self.rng.normal()) * dt
        self.theta = np.mod(new, 2*np.pi)

    def run(self, p: ModeParams, steps: int):
        vals = []
        for _ in range(steps):
            self.step(p)
            vals.append(self.R())
        return float(np.mean(vals))

def zero(p: ModeParams, noise_multiplier: float):
    return ModeParams(0.0,0.0,0.0,0.0,0.0,0.0,p.noise*noise_multiplier)

def shifted(p: ModeParams, shift: float, noise_multiplier: float):
    return ModeParams(
        p.f0*(1+shift), p.f1*(1-shift), p.f2*(1+shift/2),
        p.A, p.phi, p.duty, p.noise*noise_multiplier
    )

def single_run(p: ModeParams, seed: int, cfg: Dict[str, Any]) -> RunResult:
    s = ResonanceSystem(cfg["n_oscillators"], cfg["coupling_k"], seed, cfg["drift_strength"])
    R_on = s.run(p, cfg["on_steps"])
    R_off = s.run(zero(p, cfg["noise_multiplier"]), cfg["off_steps"])
    R_shift = s.run(shifted(p, cfg["param_shift"], cfg["noise_multiplier"]), cfg["shift_steps"])
    survived = R_off >= cfg["thresholds"]["R_off_min"] and R_shift >= cfg["thresholds"]["R_shift_min"]
    return RunResult(R_on, R_off, R_shift, survived)

def evaluate(p: ModeParams, cfg: Dict[str, Any], base_seed: int):
    runs = [single_run(p, base_seed + i*1009, cfg) for i in range(cfg["runs_per_mode"])]
    R_offs = np.array([r.R_off for r in runs])
    R_ons = np.array([r.R_on for r in runs])
    R_shifts = np.array([r.R_shift for r in runs])
    fails = np.array([not r.survived for r in runs], dtype=float)

    R_off_mean = float(np.mean(R_offs))
    R_off_std = float(np.std(R_offs))
    R_on_mean = float(np.mean(R_ons))
    R_shift_mean = float(np.mean(R_shifts))
    fail_rate = float(np.mean(fails))

    score = R_off_mean - R_off_std - fail_rate - 0.25*abs(R_on_mean - R_off_mean)

    if (
        R_off_mean >= cfg["thresholds"]["R_off_min"] and
        R_off_std <= cfg["thresholds"]["R_off_std_max"] and
        fail_rate <= cfg["thresholds"]["fail_rate_max"] and
        R_shift_mean >= cfg["thresholds"]["R_shift_min"]
    ):
        label = "stress_stable"
    elif R_off_mean >= cfg["thresholds"]["metastable_R_off_min"]:
        label = "stress_metastable"
    else:
        label = "reject"

    return {
        "params": asdict(p),
        "runs": cfg["runs_per_mode"],
        "R_off_mean": R_off_mean,
        "R_off_std": R_off_std,
        "R_on_mean": R_on_mean,
        "R_shift_mean": R_shift_mean,
        "fail_rate": fail_rate,
        "label": label,
        "score": score,
        "run_results": [asdict(r) for r in runs]
    }

def candidate_modes(cfg):
    out = []
    for f0 in cfg["freqs"]:
        for f1 in cfg["freqs"]:
            for f2 in cfg["freqs"]:
                out.append(ModeParams(float(f0), float(f1), float(f2), cfg["A"], cfg["phi"], cfg["duty"], cfg["noise"]))
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/config.json")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    cfg = json.load(open(args.config, "r", encoding="utf-8"))
    outdir = Path(args.outdir); outdir.mkdir(exist_ok=True)

    modes = candidate_modes(cfg)
    rows = []
    for idx, p in enumerate(modes):
        rows.append(evaluate(p, cfg, cfg["seed"] + idx*10000))

    rows.sort(key=lambda x: x["score"], reverse=True)
    stable = [r for r in rows if r["label"] == "stress_stable"]
    meta = [r for r in rows if r["label"] == "stress_metastable"]
    rej = [r for r in rows if r["label"] == "reject"]

    def dump(name, obj):
        json.dump(obj, open(outdir/name, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    dump("stress_results_all.json", rows)
    dump("stress_stable_modes.json", stable)
    dump("stress_metastable_modes.json", meta)
    dump("stress_rejected_modes.json", rej)
    summary = {
        "total_modes": len(rows),
        "stress_stable": len(stable),
        "stress_metastable": len(meta),
        "reject": len(rej),
        "best_score": rows[0]["score"] if rows else None,
        "best_label": rows[0]["label"] if rows else None,
        "criteria": cfg["thresholds"],
        "runs_per_mode": cfg["runs_per_mode"],
        "stress": {
            "noise_multiplier": cfg["noise_multiplier"],
            "drift_strength": cfg["drift_strength"],
            "param_shift": cfg["param_shift"],
            "off_steps": cfg["off_steps"]
        }
    }
    dump("stress_summary.json", summary)
    print(json.dumps(summary, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
