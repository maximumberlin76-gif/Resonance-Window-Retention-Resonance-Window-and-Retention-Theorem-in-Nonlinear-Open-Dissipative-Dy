
#!/usr/bin/env python3
"""Standalone feedback demo."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.engine_v7 import ModeParams, online_feedback

params = json.load(open("configs/one_params.json", "r", encoding="utf-8"))
hist = online_feedback(ModeParams(**params), target_R=0.8, steps=60, seed=123)
print(json.dumps(hist[-10:], indent=2))
