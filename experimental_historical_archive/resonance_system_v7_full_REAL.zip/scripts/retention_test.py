
#!/usr/bin/env python3
"""Standalone retention test."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.engine_v7 import ModeParams, retention_test

params = json.load(open("configs/one_params.json", "r", encoding="utf-8"))
out = retention_test(ModeParams(**params), seed=123)
print(json.dumps(out, indent=2))
