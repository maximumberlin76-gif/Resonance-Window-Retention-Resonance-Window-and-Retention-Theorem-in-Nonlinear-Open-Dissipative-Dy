
#!/usr/bin/env python3
"""
Resonance System v7 FULL
Kuramoto + multi-drive + retention + adaptive scan + online feedback.

This is a MODEL/SANDBOX engine, not a physical validation engine.

Core loop:
scan -> multi-drive -> retention OFF -> classify -> mutate -> repeat

Core metric:
R_net_proxy = R_off_mean - abs(R_on_mean - R_off_mean)

Class:
stable      if R_off_mean >= stable_threshold
metastable  if R_on_mean >= metastable_threshold
reject      otherwise
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Tuple, Any

import numpy as np


@dataclass
class ModeParams:
    f0: float
    f1: float
    f2: float
    A: float
    phi: float
    duty: float
    noise: float


@dataclass
class ModeResult:
    f0: float
    f1: float
    f2: float
    A: float
    phi: float
    duty: float
    noise: float
    R_on_mean: float
    R_on_std: float
    R_off_mean: float
    R_off_std: float
    score: float
    label: str
    generation: int
    retention_margin: float


class ResonanceSystem:
    """
    Kuramoto oscillator sandbox with 3-frequency drive.
    f0 = base anchor
    f1 = harmonic/subharmonic component
    f2 = beat/control component
    """

    def __init__(
        self,
        n: int = 40,
        coupling_k: float = 0.7,
        seed: int | None = None,
        drift_strength: float = 0.0005,
    ) -> None:
        self.n = n
        self.coupling_k = coupling_k
        self.drift_strength = drift_strength
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self) -> None:
        self.theta = self.rng.uniform(0, 2 * np.pi, self.n)
        self.omega = self.rng.uniform(0.95, 1.05, self.n)
        self.f_shift = 0.0

    def order_param(self) -> float:
        return float(np.abs(np.mean(np.exp(1j * self.theta))))

    def phase_error_proxy(self, target_r: float) -> float:
        return float(target_r - self.order_param())

    def step(self, params: ModeParams, dt: float = 0.05) -> None:
        self.f_shift += float(self.rng.uniform(-self.drift_strength, self.drift_strength))

        f0 = params.f0 + self.f_shift
        f1 = params.f1 + self.f_shift
        f2 = params.f2 + self.f_shift

        # Three-component multi-drive.
        drive = params.A * (
            math.sin(2 * math.pi * f0 * dt + params.phi)
            + math.sin(2 * math.pi * f1 * dt)
            + math.sin(2 * math.pi * f2 * dt)
        )
        drive *= params.duty

        new_theta = self.theta.copy()
        for i in range(self.n):
            coupling = np.sum(np.sin(self.theta - self.theta[i])) / self.n
            noise_term = params.noise * self.rng.normal()
            new_theta[i] += (
                self.omega[i]
                + self.coupling_k * coupling
                + drive
                + noise_term
            ) * dt
        self.theta = np.mod(new_theta, 2 * np.pi)

    def run(self, params: ModeParams, steps: int = 300) -> Tuple[float, float]:
        values = []
        for _ in range(steps):
            self.step(params)
            values.append(self.order_param())
        return float(np.mean(values)), float(np.std(values))


def zero_drive(params: ModeParams) -> ModeParams:
    return ModeParams(
        f0=0.0,
        f1=0.0,
        f2=0.0,
        A=0.0,
        phi=0.0,
        duty=0.0,
        noise=params.noise,
    )


def retention_test(
    params: ModeParams,
    seed: int | None = None,
    n: int = 40,
    on_steps: int = 300,
    off_steps: int = 250,
    coupling_k: float = 0.7,
) -> Dict[str, float]:
    system = ResonanceSystem(n=n, coupling_k=coupling_k, seed=seed)
    R_on_mean, R_on_std = system.run(params, steps=on_steps)
    R_off_mean, R_off_std = system.run(zero_drive(params), steps=off_steps)
    return {
        "R_on_mean": R_on_mean,
        "R_on_std": R_on_std,
        "R_off_mean": R_off_mean,
        "R_off_std": R_off_std,
    }


def classify(
    R_on_mean: float,
    R_off_mean: float,
    stable_threshold: float = 0.70,
    metastable_threshold: float = 0.50,
) -> str:
    if R_off_mean >= stable_threshold:
        return "stable"
    if R_on_mean >= metastable_threshold:
        return "metastable"
    return "reject"


def evaluate_mode(
    params: ModeParams,
    generation: int,
    seed: int | None = None,
    stable_threshold: float = 0.70,
    metastable_threshold: float = 0.50,
) -> ModeResult:
    ret = retention_test(params, seed=seed)
    score = ret["R_off_mean"] - abs(ret["R_on_mean"] - ret["R_off_mean"])
    label = classify(ret["R_on_mean"], ret["R_off_mean"], stable_threshold, metastable_threshold)
    retention_margin = ret["R_off_mean"] - stable_threshold

    return ModeResult(
        **asdict(params),
        R_on_mean=ret["R_on_mean"],
        R_on_std=ret["R_on_std"],
        R_off_mean=ret["R_off_mean"],
        R_off_std=ret["R_off_std"],
        score=float(score),
        label=label,
        generation=generation,
        retention_margin=float(retention_margin),
    )


def seed_population(config: Dict[str, Any], rng: np.random.Generator) -> List[ModeParams]:
    pop: List[ModeParams] = []
    freqs = config["freqs"]
    for f0 in freqs:
        for f1 in freqs:
            for f2 in freqs:
                pop.append(
                    ModeParams(
                        f0=float(f0),
                        f1=float(f1),
                        f2=float(f2),
                        A=float(rng.choice(config["A"])),
                        phi=float(rng.choice(config["phi"])),
                        duty=float(rng.choice(config["duty"])),
                        noise=float(config["noise"]),
                    )
                )
    return pop


def mutate(params: ModeParams, rng: np.random.Generator, config: Dict[str, Any]) -> ModeParams:
    return ModeParams(
        f0=float(params.f0 + rng.uniform(-config["mutation"]["df"], config["mutation"]["df"])),
        f1=float(params.f1 + rng.uniform(-config["mutation"]["df"], config["mutation"]["df"])),
        f2=float(params.f2 + rng.uniform(-config["mutation"]["df"], config["mutation"]["df"])),
        A=float(np.clip(params.A + rng.uniform(-config["mutation"]["dA"], config["mutation"]["dA"]), 0.0, 1.0)),
        phi=float(params.phi + rng.uniform(-config["mutation"]["dphi"], config["mutation"]["dphi"])),
        duty=float(np.clip(params.duty + rng.uniform(-config["mutation"]["dduty"], config["mutation"]["dduty"]), 0.0, 1.0)),
        noise=float(params.noise),
    )


def adaptive_scan(config: Dict[str, Any]) -> List[ModeResult]:
    rng = np.random.default_rng(config.get("seed", 42))
    population = seed_population(config, rng)
    all_results: List[ModeResult] = []

    generations = int(config["generations"])
    top_k = int(config["top_k"])

    for gen in range(generations):
        results = [
            evaluate_mode(
                p,
                generation=gen,
                seed=int(rng.integers(0, 2_000_000_000)),
                stable_threshold=float(config["thresholds"]["stable"]),
                metastable_threshold=float(config["thresholds"]["metastable"]),
            )
            for p in population
        ]

        results.sort(key=lambda r: r.score, reverse=True)
        top = results[:top_k]
        all_results.extend(top)

        next_population: List[ModeParams] = []
        for r in top:
            base = ModeParams(r.f0, r.f1, r.f2, r.A, r.phi, r.duty, r.noise)
            next_population.append(base)
            for _ in range(int(config["children_per_top"])):
                next_population.append(mutate(base, rng, config))

        population = next_population

    all_results.sort(key=lambda r: r.score, reverse=True)
    return all_results


def online_feedback(
    params: ModeParams,
    target_R: float = 0.80,
    steps: int = 120,
    seed: int | None = None,
    k_f: float = 0.5,
    k_A: float = 0.2,
) -> List[Dict[str, float]]:
    system = ResonanceSystem(seed=seed)
    hist: List[Dict[str, float]] = []
    current = ModeParams(**asdict(params))

    for t in range(steps):
        R_mean, R_std = system.run(current, steps=5)
        err = target_R - R_mean

        # Feedback correction.
        current.f0 += k_f * err
        current.A = float(np.clip(current.A + k_A * err, 0.0, 1.0))

        hist.append(
            {
                "t": t,
                "R": float(R_mean),
                "R_std": float(R_std),
                "err": float(err),
                "f0": float(current.f0),
                "f1": float(current.f1),
                "f2": float(current.f2),
                "A": float(current.A),
            }
        )
    return hist


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.json")
    parser.add_argument("--outdir", default="results")
    parser.add_argument("--logdir", default="logs")
    args = parser.parse_args()

    config = json.load(open(args.config, "r", encoding="utf-8"))
    outdir = Path(args.outdir)
    logdir = Path(args.logdir)
    outdir.mkdir(exist_ok=True)
    logdir.mkdir(exist_ok=True)

    results = adaptive_scan(config)
    results_dict = [asdict(r) for r in results]

    stable = [r for r in results_dict if r["label"] == "stable"]
    metastable = [r for r in results_dict if r["label"] == "metastable"]
    rejected = [r for r in results_dict if r["label"] == "reject"]

    save_json(outdir / "results_all.json", results_dict)
    save_json(outdir / "stable_modes.json", stable)
    save_json(outdir / "metastable_modes.json", metastable)
    save_json(outdir / "rejected_modes.json", rejected)

    if results:
        best = results[0]
        best_params = ModeParams(best.f0, best.f1, best.f2, best.A, best.phi, best.duty, best.noise)
        feedback_hist = online_feedback(
            best_params,
            target_R=float(config["feedback"]["target_R"]),
            steps=int(config["feedback"]["steps"]),
            seed=int(config.get("seed", 42)) + 1,
        )
        save_json(logdir / "feedback_history.json", feedback_hist)

    summary = {
        "total_kept_results": len(results),
        "stable": len(stable),
        "metastable": len(metastable),
        "reject": len(rejected),
        "best_score": results[0].score if results else None,
        "best_label": results[0].label if results else None,
    }
    save_json(outdir / "summary.json", summary)

    print("Resonance System v7 FULL complete")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
