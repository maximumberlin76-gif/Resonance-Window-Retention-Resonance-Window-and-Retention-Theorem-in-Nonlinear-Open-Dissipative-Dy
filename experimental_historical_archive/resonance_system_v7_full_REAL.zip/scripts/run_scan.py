
#!/usr/bin/env python3
"""Run full adaptive resonance scan."""
import subprocess
import sys

raise SystemExit(subprocess.call([
    sys.executable,
    "scripts/engine_v7.py",
    "--config",
    "configs/config.json",
    "--outdir",
    "results",
    "--logdir",
    "logs",
]))
