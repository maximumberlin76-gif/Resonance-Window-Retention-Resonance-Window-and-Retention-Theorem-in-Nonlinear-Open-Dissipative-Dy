
# Resonance System v7 FULL REAL

## Purpose

This package contains a complete sandbox engine for resonance-window search and retention testing.

It is not a physical validation package. It is a computational protocol package.

Core cycle:

```text
scan -> multi-drive -> retention OFF -> classify -> mutate -> feedback -> repeat
```

## Core Idea

A valid window is not a single peak.

A valid window is a regime that:

```text
1. appears under multi-drive
2. survives OFF / retention
3. resists noise and drift
4. can be re-entered by feedback
```

## Core Metric

```text
R_net_proxy = R_off_mean - abs(R_on_mean - R_off_mean)
```

Classification:

```text
stable      -> R_off_mean >= stable_threshold
metastable  -> R_on_mean >= metastable_threshold
reject      -> otherwise
```

## Multi-drive

```text
drive = f0 + f1 + f2

f0 = base anchor
f1 = harmonic / structural component
f2 = control / beat component
```

## Run

From package root:

```bash
python scripts/engine_v7.py --config configs/config.json --outdir results --logdir logs
```

Or:

```bash
python scripts/run_scan.py
python scripts/retention_test.py
python scripts/feedback_demo.py
```

## Outputs

```text
results/results_all.json
results/stable_modes.json
results/metastable_modes.json
results/rejected_modes.json
results/summary.json
logs/feedback_history.json
```

## Important Rule

Do not trust a peak without retention.

Only a retained, reproducible mode is treated as a real candidate window.
