
# Resonance Window Engineering Protocol v7

## 7/1 Cycle

1. Scan frequency f
2. Scan amplitude A
3. Scan phase phi
4. Scan duty-cycle
5. Measure coherence R
6. Measure retention after OFF
7. Compute score / stability

8. Decision:
   - stable
   - metastable
   - reject

## Retention Gate

A mode is only a true candidate if it persists after external drive is removed.

```text
forced peak != retained mode
```

## Feedback

A feedback controller adjusts f0 and A using an order-parameter error proxy.

```text
err = target_R - R
f0(t+1) = f0(t) + k_f * err
A(t+1)  = A(t)  + k_A * err
```

## Adaptive Search

The system keeps the top modes, mutates them, and scans around them.

This implements:

```text
find -> retain -> mutate -> refine
```
