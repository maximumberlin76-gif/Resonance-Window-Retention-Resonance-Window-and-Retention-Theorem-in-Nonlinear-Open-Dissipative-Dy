
# Equations

## Kuramoto Order Parameter

```text
R = | mean(exp(i * theta_j)) |
```

## Coupling

```text
d theta_i / dt = omega_i + K/N * sum_j sin(theta_j - theta_i) + drive + noise
```

## Multi-drive

```text
drive(t) = A * duty * [
    sin(2*pi*f0*t + phi)
  + sin(2*pi*f1*t)
  + sin(2*pi*f2*t)
]
```

## Retention Score

```text
score = R_off_mean - abs(R_on_mean - R_off_mean)
```

## Stability Classes

```text
stable      if R_off_mean >= 0.70
metastable  if R_on_mean  >= 0.50
reject      otherwise
```
