
# Architecture

## Components

- ResonanceSystem: Kuramoto-based oscillator network
- retention_test: ON/OFF mode verification
- adaptive_scan: evolutionary search around candidate windows
- online_feedback: real-time correction using R error
- classifier: stable / metastable / reject

## Design Principle

The package searches for retained coherent regimes, not transient peaks.
