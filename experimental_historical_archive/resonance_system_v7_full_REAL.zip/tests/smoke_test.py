
#!/usr/bin/env python3
"""Smoke test for package completeness."""
from pathlib import Path

required = [
    "scripts/engine_v7.py",
    "scripts/run_scan.py",
    "scripts/retention_test.py",
    "scripts/feedback_demo.py",
    "configs/config.json",
    "docs/README.md",
    "model/protocol.md",
    "model/equations.md",
]

for item in required:
    p = Path(item)
    assert p.exists(), f"Missing: {item}"
    assert p.stat().st_size > 100, f"Too small / likely empty: {item}"

print("SMOKE OK")
