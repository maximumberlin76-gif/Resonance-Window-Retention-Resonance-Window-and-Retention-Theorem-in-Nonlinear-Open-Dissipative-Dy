# Resonance System v12 SPARSE BACKBONE REAL

## Purpose

v11 produced a dense coherent network. That is useful, but too comfortable:
if every node connects to almost every node, the graph can look stable even when
the real structure is not selective.

v12 introduces a harsher network test.

## What v12 Tests

1. Sparse threshold sweep  
   The system builds graphs at several edge thresholds:
   0.55, 0.60, 0.65, 0.70, 0.75, 0.80.

2. Minimum viable backbone  
   The goal is not maximum edge count.
   The goal is the sparsest graph that still preserves a functional giant component.

3. Targeted hub attack  
   The highest-degree nodes are removed.
   If the network collapses immediately, the backbone is fragile.

4. Random attack  
   Random nodes are removed.
   This checks general resilience.

5. Low-degree removal  
   Weak peripheral nodes are removed.
   This checks whether the core remains stable.

## Interpretation

- sparse_resilient:
  the network keeps a large connected component even after hub attack.

- fragile_backbone:
  the network exists but depends too strongly on a few hubs.

- no_viable_backbone:
  no sparse threshold keeps the structure functional.

## Run

```bash
python scripts/generate_v10_seed_modes.py
python scripts/engine_v12_sparse_backbone.py --input results/invariance_results_all.json --outdir results
```

## Outputs

- results/sparse_network_graph.json
- results/sparse_network_summary.json

## Important

v12 is not looking for “more connections”.
v12 is looking for the minimal resilient structure.

That is the difference between a dense illusion and a real backbone.
