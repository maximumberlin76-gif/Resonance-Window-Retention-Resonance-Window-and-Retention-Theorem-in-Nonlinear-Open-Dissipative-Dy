
#!/usr/bin/env python3
"""
Resonance System v12 SPARSE BACKBONE REAL

Purpose:
v11 showed that the network can become too dense and therefore too comfortable.
v12 makes the test harsher.

Adds:
- sparse edge threshold sweep
- backbone attack
- random failure test
- targeted hub-removal test
- bridge-removal test
- minimum viable backbone detection

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from itertools import combinations
from statistics import mean
from collections import defaultdict, deque

def load_modes(path):
    rows = json.load(open(path, "r", encoding="utf-8"))
    return [r for r in rows if r["label"] in ("invariant_stable", "invariant_metastable")]

def phase_compat(a,b):
    return (1 + math.cos(a["params"].get("phi",0)-b["params"].get("phi",0))) / 2

def harmonic_score(a,b,eps=0.06):
    fa=[a["params"]["f0"],a["params"]["f1"],a["params"]["f2"]]
    fb=[b["params"]["f0"],b["params"]["f1"],b["params"]["f2"]]
    targets=[1,2,3,0.5,1/3,7,1/7]
    hits=0; total=0
    for x in fa:
        for y in fb:
            if x<=0 or y<=0: continue
            r=max(x,y)/min(x,y); total+=1
            if any(abs(r-t)/t <= eps for t in targets): hits+=1
    return hits/max(1,total)

def retention(x):
    return float(x.get("checks",{}).get("env_mean",0.0))

def freq_distance(a,b):
    pa,pb=a["params"],b["params"]
    return (abs(pa["f0"]-pb["f0"])+abs(pa["f1"]-pb["f1"])+abs(pa["f2"]-pb["f2"]))/3

def edge_score(a,b):
    h=harmonic_score(a,b)
    ph=phase_compat(a,b)
    r=(retention(a)+retention(b))/2
    d=1/(1+freq_distance(a,b)/200)
    # v12 harsher: harmonic relation dominates, distance penalty stronger
    return 0.50*h + 0.20*ph + 0.20*r + 0.10*d

def build_edges(modes, threshold):
    edges=[]
    for i,j in combinations(range(len(modes)),2):
        s=edge_score(modes[i],modes[j])
        if s>=threshold:
            edges.append({"i":i,"j":j,"score":s})
    return edges

def adj(n,edges,removed=None):
    removed=removed or set()
    g=[set() for _ in range(n)]
    for e in edges:
        if e["i"] in removed or e["j"] in removed: continue
        g[e["i"]].add(e["j"]); g[e["j"]].add(e["i"])
    return g

def component_sizes(n,edges,removed=None):
    removed=removed or set()
    g=adj(n,edges,removed)
    seen=set(); sizes=[]
    for i in range(n):
        if i in removed or i in seen: continue
        q=[i]; seen.add(i); c=0
        while q:
            x=q.pop(); c+=1
            for y in g[x]:
                if y not in seen:
                    seen.add(y); q.append(y)
        sizes.append(c)
    return sorted(sizes,reverse=True)

def degree_list(n,edges):
    deg=[0]*n
    for e in edges:
        deg[e["i"]]+=1; deg[e["j"]]+=1
    return deg

def attack(n,edges,mode,frac=0.25,seed=1):
    count=max(1,int(n*frac))
    deg=degree_list(n,edges)
    if mode=="targeted_hub":
        removed=set(sorted(range(n),key=lambda i:deg[i],reverse=True)[:count])
    elif mode=="random":
        rng=random.Random(seed); removed=set(rng.sample(range(n),count))
    elif mode=="low_degree":
        removed=set(sorted(range(n),key=lambda i:deg[i])[:count])
    else:
        removed=set()
    sizes=component_sizes(n,edges,removed)
    largest=sizes[0] if sizes else 0
    remaining=n-len(removed)
    return {"mode":mode,"removed":sorted(removed),"largest_component_fraction":largest/max(1,remaining),"component_sizes":sizes}

def threshold_sweep(modes, thresholds):
    out=[]
    n=len(modes)
    for th in thresholds:
        edges=build_edges(modes,th)
        comps=component_sizes(n,edges)
        deg=degree_list(n,edges)
        global_coh=mean([e["score"] for e in edges]) if edges else 0
        targeted=attack(n,edges,"targeted_hub",0.25,seed=42)
        random_a=attack(n,edges,"random",0.25,seed=42)
        out.append({
            "threshold":th,
            "edges":len(edges),
            "mean_degree":sum(deg)/max(1,n),
            "components":len(comps),
            "largest_component":comps[0] if comps else 0,
            "global_coherence":global_coh,
            "targeted_attack":targeted,
            "random_attack":random_a
        })
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",default="results/invariance_results_all.json")
    ap.add_argument("--outdir",default="results")
    args=ap.parse_args()
    modes=load_modes(args.input)
    out=Path(args.outdir); out.mkdir(exist_ok=True)

    thresholds=[0.55,0.60,0.65,0.70,0.75,0.80]
    sweep=threshold_sweep(modes,thresholds)

    # choose minimum viable backbone: connected enough but not fully overconnected
    viable=[x for x in sweep if x["largest_component"]>=max(3,int(len(modes)*0.5)) and x["targeted_attack"]["largest_component_fraction"]>=0.5]
    chosen=viable[-1] if viable else (sweep[0] if sweep else None)

    chosen_edges=build_edges(modes,chosen["threshold"]) if chosen else []
    deg=degree_list(len(modes),chosen_edges)
    backbone=[e for e in chosen_edges if e["score"]>=max(chosen["threshold"],0.72)] if chosen else []

    summary={
        "nodes":len(modes),
        "threshold_sweep":sweep,
        "chosen_threshold":chosen["threshold"] if chosen else None,
        "chosen_edges":len(chosen_edges),
        "backbone_edges":len(backbone),
        "chosen_mean_degree":sum(deg)/max(1,len(modes)),
        "chosen_components":component_sizes(len(modes),chosen_edges),
        "network_label": "sparse_resilient" if chosen and chosen["targeted_attack"]["largest_component_fraction"]>=0.65 else ("fragile_backbone" if chosen else "no_viable_backbone"),
        "hub_nodes": sorted([{"idx":i,"degree":d,"params":modes[i]["params"],"label":modes[i]["label"]} for i,d in enumerate(deg)],key=lambda x:x["degree"],reverse=True)[:10],
        "chosen_attacks": {
            "targeted_hub": attack(len(modes),chosen_edges,"targeted_hub",0.25,seed=42) if chosen else None,
            "random": attack(len(modes),chosen_edges,"random",0.25,seed=42) if chosen else None,
            "low_degree": attack(len(modes),chosen_edges,"low_degree",0.25,seed=42) if chosen else None
        }
    }
    graph={"nodes":modes,"edges":chosen_edges,"backbone":backbone}
    json.dump(graph,open(out/"sparse_network_graph.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    json.dump(summary,open(out/"sparse_network_summary.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=="__main__":
    main()
