# v12 Sparse Backbone Protocol

1. Load invariant modes.
2. Build compatibility edges using a stricter score:
   - harmonic score
   - phase compatibility
   - retention strength
   - frequency distance penalty
3. Sweep thresholds from loose to strict.
4. Find minimum viable backbone.
5. Attack hubs.
6. Attack random nodes.
7. Attack low-degree nodes.
8. Classify:
   - sparse_resilient
   - fragile_backbone
   - no_viable_backbone

Goal: find the smallest resilient structure, not the densest graph.
