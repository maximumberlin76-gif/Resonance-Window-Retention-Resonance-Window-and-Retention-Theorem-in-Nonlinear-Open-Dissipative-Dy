# v12 Edge Score

edge_score =
0.50 * harmonic_score
+ 0.20 * phase_compat
+ 0.20 * retention_strength
+ 0.10 * distance_penalty

A backbone edge is an edge that survives a stricter threshold.

Resilience metric:
largest_component_fraction after node removal.
