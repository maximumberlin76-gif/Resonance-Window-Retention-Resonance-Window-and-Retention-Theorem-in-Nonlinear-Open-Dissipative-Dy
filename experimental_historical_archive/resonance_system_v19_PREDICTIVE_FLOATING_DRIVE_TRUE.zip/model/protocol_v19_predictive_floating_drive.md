v19 protocol: drift prediction -> phase lead -> overshoot limit -> adaptive corridor -> predictive lock classification.
