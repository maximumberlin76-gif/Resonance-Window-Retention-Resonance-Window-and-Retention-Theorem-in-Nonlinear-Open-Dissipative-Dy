S_predict = mean_C - var_C - 0.35*lock_loss_rate - 0.45*tracking_error - 0.30*predictive_error - 0.20*overshoot_rate
