# Resonance System v19 TRUE PREDICTIVE FLOATING DRIVE

## Purpose

v18 made the drive follow a floating resonance window.  
v19 makes the drive anticipate the floating window.

## Adds

- drift predictor
- phase-lead compensation
- overshoot control
- adaptive corridor
- predictive lock score

## Run

```bash
python scripts/generate_floating_seed.py
python scripts/engine_v19_predictive_floating_drive.py --input results/floating_drive_trials.json --outdir results
python tests/smoke_test.py
```

## Outputs

- results/predictive_drive_summary.json
- results/predictive_drive_trials.json
- validation/triple_validation_summary.json

## Limitation

Computational sandbox only.
