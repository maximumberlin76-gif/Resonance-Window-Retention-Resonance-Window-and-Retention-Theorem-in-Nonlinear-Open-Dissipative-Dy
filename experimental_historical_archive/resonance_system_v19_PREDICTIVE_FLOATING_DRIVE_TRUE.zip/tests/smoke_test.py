#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v19_predictive_floating_drive.py","results/predictive_drive_summary.json","results/predictive_drive_trials.json","docs/README.md"]:
    fp=Path(p); assert fp.exists() and fp.stat().st_size>100,p
s=json.load(open("results/predictive_drive_summary.json","r",encoding="utf-8")); assert "mean_predictive_error" in s and "all_trials" in s
print("SMOKE_OK")
