#!/usr/bin/env python3
import argparse,json,random,math
from pathlib import Path

def clamp(x,lo=0,hi=1): return max(lo,min(hi,x))
def mean(xs): return sum(xs)/max(1,len(xs))

def simulate(trial,cfg,seed):
    rng=random.Random(seed); cycles=cfg["cycles"]
    fc=trial.get("f_center",rng.choice([76.4,150.0,458.4])); f0=fc
    C=clamp(trial["reentry_norm"]-trial["new_edge_penalty"])
    hist=[fc]; lock_loss=0; overs=0; collapsed=False; collapse_at=None; series=[]
    for t in range(cycles):
        fc += cfg["floating"]["drift_rate"]*math.sin(2*math.pi*t/cfg["floating"]["period"]) + rng.uniform(-cfg["floating"]["jitter"],cfg["floating"]["jitter"])
        hist.append(fc)
        h=hist[-cfg["predictor"]["history"]:]
        pd=(h[-1]-h[0])/max(1,len(h)-1) if len(h)>1 else 0
        pred=fc+cfg["predictor"]["lead"]*pd
        jump=pred-f0; max_jump=abs(fc)*cfg["predictor"]["max_jump_ratio"]
        if abs(jump)>max_jump:
            pred=f0+max_jump*(1 if jump>0 else -1); overs+=1
        f0 += cfg["floating"]["follow_gain"]*(pred-f0)
        f1=2*f0; f2=0.5*f0
        terr=abs(fc-f0)/max(1,abs(fc)); perr=abs(pred-fc)/max(1,abs(fc))
        corridor=cfg["floating"]["base_corridor"]+min(cfg["floating"]["max_extra_corridor"],abs(pd)/max(1,abs(fc))*cfg["floating"]["corridor_gain"])
        inside=terr<=corridor
        if not inside: lock_loss+=1
        D=cfg["dissipation_rate"]*(1+0.010*t); noise=rng.uniform(-cfg["noise"],cfg["noise"])
        ps=cfg["predictor"]["predictive_support"]*(1-perr)
        ls=cfg["floating"]["lock_support"]*(1-terr) if inside else -cfg["floating"]["lock_penalty"]
        repair=cfg["recovery_gain"]*max(0,1-C)
        C=clamp(C+repair+ls+ps-D+noise)
        if C<cfg["collapse_threshold"] and not collapsed:
            collapsed=True; collapse_at=t
        series.append({"t":t,"window_center":fc,"predicted_center":pred,"predicted_drift":pd,"f0":f0,"f1":f1,"f2":f2,"tracking_error":terr,"predictive_error":perr,"local_corridor":corridor,"in_corridor":inside,"C":C,"D_t":D,"repair":repair,"lock_support":ls,"predictive_support":ps,"noise":noise})
    Cs=[x["C"] for x in series]; m=mean(Cs); var=mean([(x-m)**2 for x in Cs])
    mterr=mean([x["tracking_error"] for x in series]); mperr=mean([x["predictive_error"] for x in series])
    ll=lock_loss/cycles; orate=overs/cycles
    S=m-var-0.35*ll-0.45*mterr-0.30*mperr-0.20*orate
    if collapsed: label="predictive_collapse"
    elif S>=cfg["thresholds"]["predictive_stable"] and ll<=cfg["thresholds"]["max_lock_loss"]: label="predictive_stable"
    elif S>=cfg["thresholds"]["predictive_metastable"]: label="predictive_metastable"
    else: label="predictive_weak"
    return {"mean_C":m,"var_C":var,"mean_tracking_error":mterr,"mean_predictive_error":mperr,"lock_loss_rate":ll,"overshoot_rate":orate,"S_predict":S,"collapsed":collapsed,"collapse_at":collapse_at,"label":label,"series":series}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--input",default="results/floating_drive_trials.json"); ap.add_argument("--outdir",default="results"); args=ap.parse_args()
    cfg=json.load(open("configs/config.json","r",encoding="utf-8")); trials=json.load(open(args.input,"r",encoding="utf-8"))
    rows=[]
    for i,t in enumerate(trials):
        base={"trial_index":t.get("trial_index",i),"previous_label":t.get("label","floating_unknown"),"reentry_norm":t.get("reentry_norm",0.78),"new_edge_penalty":t.get("new_edge_penalty",0.12),"f_center":[76.4,150.0,458.4][i%3]}
        rows.append({**base,**simulate(base,cfg,cfg["seed"]+i*100)})
    stable=[r for r in rows if r["label"]=="predictive_stable"]; meta=[r for r in rows if r["label"]=="predictive_metastable"]; weak=[r for r in rows if r["label"]=="predictive_weak"]; col=[r for r in rows if r["label"]=="predictive_collapse"]
    summary={"trials":len(rows),"predictive_stable":len(stable),"predictive_metastable":len(meta),"predictive_weak":len(weak),"predictive_collapse":len(col),"mean_S_predict":mean([r["S_predict"] for r in rows]),"mean_tracking_error":mean([r["mean_tracking_error"] for r in rows]),"mean_predictive_error":mean([r["mean_predictive_error"] for r in rows]),"mean_lock_loss_rate":mean([r["lock_loss_rate"] for r in rows]),"mean_overshoot_rate":mean([r["overshoot_rate"] for r in rows]),"label":"predictive_drive_success" if len(stable)+len(meta)>=len(rows)*0.75 and len(col)==0 else "predictive_drive_limited","top_trials":sorted(rows,key=lambda x:x["S_predict"],reverse=True)[:10],"all_trials":rows}
    out=Path(args.outdir); out.mkdir(exist_ok=True)
    json.dump(summary,open(out/"predictive_drive_summary.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    json.dump(rows,open(out/"predictive_drive_trials.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    print(json.dumps({k:summary[k] for k in ["trials","predictive_stable","predictive_metastable","predictive_weak","predictive_collapse","mean_S_predict","label"]},indent=2))
if __name__=="__main__": main()
