# Experiment 02 — Refine Window

Search near Experiment 01 candidate, but with lower forcing.

Goal: identify minimal-energy resonance window.

Candidate:

```text
R_final >= 0.70
retention_time >= 1.8 after forcing OFF
```

Files:

- results/all_results.csv
- results/minimal_energy_candidates.csv
- results/max_performance_candidates.csv
