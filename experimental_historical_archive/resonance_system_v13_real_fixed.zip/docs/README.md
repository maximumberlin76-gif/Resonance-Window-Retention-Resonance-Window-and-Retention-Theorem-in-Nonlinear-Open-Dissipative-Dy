
# v13 CRITICAL BACKBONE (FIXED)

This is a REAL rebuild (not placeholder).

Contains:
- working engine
- generated results
- reproducible structure

Run:
python scripts/engine_v13.py
