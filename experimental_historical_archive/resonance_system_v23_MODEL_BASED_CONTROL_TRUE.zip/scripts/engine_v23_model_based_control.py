#!/usr/bin/env python3
"""
Resonance System v23 TRUE MODEL-BASED CONTROL

v22 controlled the current state.
v23 predicts the future state and chooses control by minimizing a short-horizon cost.

Adds:
- state predictor H(t+Δ)
- short-horizon rollout
- control candidate search
- cost function J
- confidence estimate
- fallback to v22-style state-aware control when confidence is low

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from typing import Dict, Any, List


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def mean(xs: List[float]) -> float:
    return sum(xs) / max(1, len(xs))


def regime(C: float, tracking: float, lock_streak: int, cfg: Dict[str, Any]) -> str:
    if C < cfg["regime"]["danger_C"] or lock_streak >= cfg["regime"]["danger_lock_streak"]:
        return "danger"
    if C < cfg["regime"]["recovery_C"]:
        return "recovery"
    if tracking > cfg["regime"]["tracking_error"]:
        return "tracking"
    return "calm"


def predict_window(history: List[float], cfg: Dict[str, Any]) -> Dict[str, float]:
    h = history[-cfg["predictor"]["history"]:]
    if len(h) < 2:
        drift = 0.0
        curvature = 0.0
    else:
        drift = (h[-1] - h[0]) / (len(h) - 1)
        if len(h) >= 3:
            prev_drift = (h[-2] - h[0]) / max(1, len(h) - 2)
            curvature = drift - prev_drift
        else:
            curvature = 0.0

    predicted = history[-1] + cfg["predictor"]["lead"] * drift + cfg["predictor"]["curvature_gain"] * curvature
    uncertainty = min(1.0, abs(curvature) / max(1.0, abs(history[-1])) * cfg["predictor"]["uncertainty_gain"])
    confidence = 1.0 - uncertainty
    return {"predicted_center": predicted, "drift": drift, "curvature": curvature, "confidence": confidence}


def rollout_cost(state: Dict[str, float], control: float, predicted_center: float, cfg: Dict[str, Any]) -> float:
    f0 = state["f0"]
    C = state["C"]
    integral = state["integral_error"]
    derivative = state["derivative_error"]

    cost = 0.0
    local_f0 = f0
    local_C = C
    local_integral = integral
    local_derivative = derivative

    for k in range(cfg["model"]["horizon"]):
        # Apply candidate control with simple decay over horizon.
        u = control * (cfg["model"]["control_decay"] ** k)
        local_f0 += u

        tracking_future = abs(predicted_center - local_f0) / max(1.0, abs(predicted_center))
        local_integral = clamp(local_integral + tracking_future, -cfg["state"]["integral_limit"], cfg["state"]["integral_limit"])
        local_derivative = tracking_future - local_derivative

        # Future coherence approximation.
        future_D = cfg["dissipation_rate"] * (1.0 + 0.010 * k)
        future_repair = cfg["recovery_gain"] * max(0.0, 1.0 - local_C)
        lock_loss_future = 1.0 if tracking_future > cfg["floating"]["base_corridor"] else 0.0
        local_C = clamp(local_C + future_repair - future_D - 0.20 * tracking_future - 0.05 * lock_loss_future)

        instability = max(0.0, cfg["model"]["min_C"] - local_C)
        energy = abs(u) / max(1.0, abs(predicted_center))

        cost += (
            cfg["cost"]["tracking"] * tracking_future
            + cfg["cost"]["lock_loss"] * lock_loss_future
            + cfg["cost"]["energy"] * energy
            + cfg["cost"]["instability"] * instability
            + cfg["cost"]["integral"] * abs(local_integral)
            + cfg["cost"]["derivative"] * abs(local_derivative)
        )

    return cost


def choose_control(state: Dict[str, float], predicted: Dict[str, float], cfg: Dict[str, Any]) -> Dict[str, float]:
    # Candidate controls around predicted error.
    target_error = predicted["predicted_center"] - state["f0"]
    max_delta = abs(predicted["predicted_center"]) * cfg["model"]["max_control_ratio"]

    candidates = [
        -max_delta,
        -0.5 * max_delta,
        0.0,
        0.5 * max_delta,
        max_delta,
        clamp(target_error, -max_delta, max_delta),
    ]

    scored = []
    for u in candidates:
        J = rollout_cost(state, u, predicted["predicted_center"], cfg)
        scored.append({"control": u, "J": J})

    best = min(scored, key=lambda x: x["J"])
    return {"control": best["control"], "J": best["J"], "candidates": scored}


def fallback_v22_control(state: Dict[str, float], predicted_center: float, cfg: Dict[str, Any]) -> float:
    error = predicted_center - state["f0"]
    local_regime = state["regime"]
    rp = cfg["regime_params"][local_regime]
    control = (
        rp["kp"] * error
        + rp["ki"] * state["integral_error"] * abs(predicted_center)
        + rp["kd"] * state["derivative_error"] * abs(predicted_center)
    )
    max_delta = abs(predicted_center) * rp["max_delta_ratio"]
    return clamp(control, -max_delta, max_delta)


def simulate_trial(trial: Dict[str, Any], cfg: Dict[str, Any], seed: int) -> Dict[str, Any]:
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    window_center = trial.get("f_center", rng.choice([76.4, 150.0, 458.4]))
    f0 = window_center
    C = clamp(trial["reentry_norm"] - trial["new_edge_penalty"])

    history = [window_center]
    integral_error = 0.0
    derivative_error = 0.0
    lock_streak = 0

    fallback_count = 0
    lock_loss_count = 0
    collapsed = False
    collapse_at = None
    series = []

    for t in range(cycles):
        # True floating window.
        drift_true = cfg["floating"]["drift_rate"] * math.sin(2 * math.pi * t / cfg["floating"]["period"])
        jitter = rng.uniform(-cfg["floating"]["jitter"], cfg["floating"]["jitter"])
        window_center += drift_true + jitter
        history.append(window_center)

        predicted = predict_window(history, cfg)

        tracking_error = abs(window_center - f0) / max(1.0, abs(window_center))
        local_regime = regime(C, tracking_error, lock_streak, cfg)

        integral_error = clamp(
            integral_error + tracking_error,
            -cfg["state"]["integral_limit"],
            cfg["state"]["integral_limit"]
        )

        state = {
            "f0": f0,
            "C": C,
            "integral_error": integral_error,
            "derivative_error": derivative_error,
            "regime": local_regime
        }

        if predicted["confidence"] >= cfg["model"]["min_confidence"]:
            chosen = choose_control(state, predicted, cfg)
            control = chosen["control"]
            used_fallback = False
            J = chosen["J"]
        else:
            control = fallback_v22_control(state, predicted["predicted_center"], cfg)
            used_fallback = True
            fallback_count += 1
            J = None

        # Jerk limit
        max_jerk = abs(window_center) * cfg["state"]["max_jerk_ratio"]
        control = clamp(control, -max_jerk, max_jerk)

        f0 += control
        f1 = 2.0 * f0
        f2 = 0.5 * f0

        new_tracking = abs(window_center - f0) / max(1.0, abs(window_center))
        derivative_error = new_tracking - tracking_error

        corridor = cfg["floating"]["base_corridor"] + min(
            cfg["floating"]["max_extra_corridor"],
            abs(predicted["drift"]) / max(1.0, abs(window_center)) * cfg["floating"]["corridor_gain"]
        )
        in_corridor = new_tracking <= corridor

        if in_corridor:
            lock_streak = 0
        else:
            lock_streak += 1
            lock_loss_count += 1

        D_t = cfg["dissipation_rate"] * (1.0 + 0.009 * t)
        noise = rng.uniform(-cfg["noise"], cfg["noise"])
        repair = cfg["recovery_gain"] * max(0.0, 1.0 - C)

        confidence_support = cfg["model"]["confidence_support"] * predicted["confidence"]
        lock_support = cfg["floating"]["lock_support"] * (1.0 - new_tracking) if in_corridor else -cfg["floating"]["lock_penalty"]
        control_energy = abs(control) / max(1.0, abs(window_center))
        energy_penalty = cfg["model"]["energy_penalty"] * control_energy

        C = clamp(C + repair + lock_support + confidence_support - D_t - energy_penalty + noise)

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

        series.append({
            "t": t,
            "window_center": window_center,
            "predicted_center": predicted["predicted_center"],
            "confidence": predicted["confidence"],
            "drift": predicted["drift"],
            "curvature": predicted["curvature"],
            "f0": f0,
            "f1": f1,
            "f2": f2,
            "regime": local_regime,
            "tracking_error": new_tracking,
            "integral_error": integral_error,
            "derivative_error": derivative_error,
            "control": control,
            "used_fallback": used_fallback,
            "J": J,
            "corridor": corridor,
            "in_corridor": in_corridor,
            "C": C,
            "D_t": D_t,
            "repair": repair,
            "lock_support": lock_support,
            "confidence_support": confidence_support,
            "energy_penalty": energy_penalty,
            "noise": noise
        })

    Cs = [x["C"] for x in series]
    tracking = [x["tracking_error"] for x in series]
    confidence = [x["confidence"] for x in series]
    controls = [abs(x["control"]) for x in series]

    mean_C = mean(Cs)
    var_C = mean([(x - mean_C) ** 2 for x in Cs])
    mean_tracking = mean(tracking)
    mean_confidence = mean(confidence)
    mean_control = mean(controls)
    lock_loss_rate = lock_loss_count / cycles
    fallback_rate = fallback_count / cycles

    S_model = (
        mean_C
        - var_C
        - 0.40 * lock_loss_rate
        - 0.45 * mean_tracking
        - 0.20 * fallback_rate
        - 0.15 * mean_control
        + 0.10 * mean_confidence
    )

    if collapsed:
        label = "model_collapse"
    elif S_model >= cfg["thresholds"]["model_stable"] and lock_loss_rate <= cfg["thresholds"]["max_lock_loss"]:
        label = "model_stable"
    elif S_model >= cfg["thresholds"]["model_metastable"]:
        label = "model_metastable"
    else:
        label = "model_weak"

    return {
        "mean_C": mean_C,
        "var_C": var_C,
        "mean_tracking_error": mean_tracking,
        "mean_confidence": mean_confidence,
        "mean_abs_control": mean_control,
        "lock_loss_rate": lock_loss_rate,
        "fallback_rate": fallback_rate,
        "S_model": S_model,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "label": label,
        "series": series
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="results/state_control_trials.json")
    parser.add_argument("--outdir", default="results")
    args = parser.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    trials = json.load(open(args.input, "r", encoding="utf-8"))

    rows = []
    for idx, trial in enumerate(trials):
        base = {
            "trial_index": trial.get("trial_index", idx),
            "previous_label": trial.get("label", "state_unknown"),
            "reentry_norm": trial.get("reentry_norm", 0.84),
            "new_edge_penalty": trial.get("new_edge_penalty", 0.09),
            "f_center": [76.4, 150.0, 458.4][idx % 3],
        }
        sim = simulate_trial(base, cfg, cfg["seed"] + idx * 100)
        rows.append({**base, **sim})

    stable = [r for r in rows if r["label"] == "model_stable"]
    meta = [r for r in rows if r["label"] == "model_metastable"]
    weak = [r for r in rows if r["label"] == "model_weak"]
    collapse = [r for r in rows if r["label"] == "model_collapse"]

    summary = {
        "trials": len(rows),
        "model_stable": len(stable),
        "model_metastable": len(meta),
        "model_weak": len(weak),
        "model_collapse": len(collapse),
        "mean_S_model": mean([r["S_model"] for r in rows]),
        "mean_tracking_error": mean([r["mean_tracking_error"] for r in rows]),
        "mean_confidence": mean([r["mean_confidence"] for r in rows]),
        "mean_lock_loss_rate": mean([r["lock_loss_rate"] for r in rows]),
        "mean_fallback_rate": mean([r["fallback_rate"] for r in rows]),
        "mean_abs_control": mean([r["mean_abs_control"] for r in rows]),
        "label": "model_based_success" if len(stable) + len(meta) >= len(rows)*0.75 and len(collapse) == 0 else "model_based_limited",
        "top_trials": sorted(rows, key=lambda x: x["S_model"], reverse=True)[:10],
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"model_based_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"model_based_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "model_stable": summary["model_stable"],
        "model_metastable": summary["model_metastable"],
        "model_weak": summary["model_weak"],
        "model_collapse": summary["model_collapse"],
        "mean_S_model": summary["mean_S_model"],
        "mean_tracking_error": summary["mean_tracking_error"],
        "mean_fallback_rate": summary["mean_fallback_rate"],
        "label": summary["label"]
    }, indent=2))


if __name__ == "__main__":
    main()
