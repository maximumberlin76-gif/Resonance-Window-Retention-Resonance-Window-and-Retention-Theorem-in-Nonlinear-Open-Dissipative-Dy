#!/usr/bin/env python3
from pathlib import Path
import json, random
random.seed(2323)
rows = []
for i in range(18):
    rows.append({
        "trial_index": i,
        "label": "state_stable",
        "reentry_norm": random.uniform(0.78, 1.0),
        "new_edge_penalty": random.uniform(0.03, 0.14),
        "mean_C": random.uniform(0.76, 0.96),
        "S_state": random.uniform(0.70, 0.94),
        "mean_tracking_error": random.uniform(0.001, 0.008),
        "mean_predictive_error": random.uniform(0.001, 0.005),
        "lock_loss_rate": random.uniform(0.0, 0.01),
        "series": []
    })
Path("results").mkdir(exist_ok=True)
json.dump(rows, open("results/state_control_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("generated state-control trials", len(rows))
