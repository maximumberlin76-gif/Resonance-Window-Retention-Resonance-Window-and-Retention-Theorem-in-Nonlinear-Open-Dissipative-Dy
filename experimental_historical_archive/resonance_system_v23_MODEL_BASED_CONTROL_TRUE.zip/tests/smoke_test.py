#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v23_model_based_control.py","results/model_based_summary.json","results/model_based_trials.json","docs/README.md"]:
    fp = Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s = json.load(open("results/model_based_summary.json", "r", encoding="utf-8"))
assert "mean_fallback_rate" in s and "all_trials" in s
print("SMOKE_OK")
