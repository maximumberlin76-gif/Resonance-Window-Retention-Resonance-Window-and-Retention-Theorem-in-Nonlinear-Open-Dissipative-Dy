# v23 Equations

## Predictor

predicted_center =
window_center
+ lead * drift
+ curvature_gain * curvature

## Cost Function

J =
w1 * tracking_error_future
+ w2 * lock_loss_future
+ w3 * control_energy
+ w4 * instability_risk
+ w5 * integral_error
+ w6 * derivative_error

## Model Score

S_model =
mean_C
- var_C
- 0.40 * lock_loss_rate
- 0.45 * mean_tracking_error
- 0.20 * fallback_rate
- 0.15 * mean_abs_control
+ 0.10 * mean_confidence
