# v23 Model-Based Control Protocol

1. Load v22 state-control trials.
2. Simulate floating resonance window.
3. Predict next window center using drift and curvature.
4. Estimate prediction confidence.
5. If confidence is high:
   - evaluate candidate controls
   - roll out future state over short horizon
   - compute cost J
   - choose minimum J
6. If confidence is low:
   - fallback to v22 state-aware control
7. Update f0, f1, f2.
8. Track coherence C(t), lock loss, fallback rate, control energy.
9. Classify model-based stability.
