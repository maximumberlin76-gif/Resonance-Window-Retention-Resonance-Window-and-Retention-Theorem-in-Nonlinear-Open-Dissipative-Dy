# v28.4 Instability Detection

Core:
Instability point detected when:

dC/dt ≈ 0
and
variance(dC) ↑

This marks transition:
accumulation → release
