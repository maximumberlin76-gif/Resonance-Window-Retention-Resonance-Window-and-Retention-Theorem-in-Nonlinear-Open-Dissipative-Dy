# Detection Rule

instability if:

mean(dC over window) ~ 0
and
var(dC) > threshold
