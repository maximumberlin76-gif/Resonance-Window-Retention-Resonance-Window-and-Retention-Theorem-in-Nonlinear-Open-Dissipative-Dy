#!/usr/bin/env python3
# v28.4 numerical instability detection

import json, random, math
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def run(seed=1, cycles=200):
    rng = random.Random(seed)
    C = 0.4
    P = 0.08
    D = 0.06

    theta = 0.0
    tau = 0

    dC_hist = []
    var_hist = []
    instability_points = []

    series = []

    for t in range(cycles):
        growth = 0.015*(1-C)
        noise = rng.uniform(-0.02,0.02)
        overshoot = 0.0

        if rng.random() < 0.04:
            overshoot = rng.uniform(0.05,0.15)

        C_prev = C
        C = clamp(C + growth - D - P + noise + overshoot)

        dC = C - C_prev
        dC_hist.append(dC)

        if len(dC_hist) > 10:
            window = dC_hist[-10:]
            var = sum((x - sum(window)/len(window))**2 for x in window)/len(window)
        else:
            var = 0.0

        var_hist.append(var)

        delta = C - P - D

        if delta > 0:
            theta += delta
            tau += 1
        else:
            tau = 0

        # instability detection
        if len(dC_hist) > 5:
            if abs(sum(dC_hist[-5:])/5) < 0.001 and var > 0.002:
                instability_points.append(t)

        series.append({
            "t": t,
            "C": C,
            "dC": dC,
            "var": var,
            "theta": theta,
            "tau": tau,
            "delta": delta
        })

    return {
        "instability_points": instability_points,
        "theta_final": theta,
        "tau_final": tau,
        "series": series
    }

def main():
    out = Path("results")
    out.mkdir(exist_ok=True)

    trials = []
    for i in range(20):
        trials.append(run(seed=100+i))

    summary = {
        "trials": len(trials),
        "mean_instability_points": sum(len(t["instability_points"]) for t in trials)/len(trials),
        "mean_theta": sum(t["theta_final"] for t in trials)/len(trials),
        "mean_tau": sum(t["tau_final"] for t in trials)/len(trials),
        "conclusion": "instability_detected_via_dC_and_variance"
    }

    json.dump(summary, open(out/"instability_summary.json","w"), indent=2)
    json.dump(trials, open(out/"instability_trials.json","w"), indent=2)

    print(summary)

if __name__ == "__main__":
    main()
