# Session v28.4

Added:
- numerical instability detection
- dC/dt + variance criterion

Next:
link to release dynamics
