#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v28_2_coherence_accumulation.py","results/coherence_accumulation_summary.json","results/coherence_accumulation_trials.json","docs/README.md"]:
    fp=Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s=json.load(open("results/coherence_accumulation_summary.json","r",encoding="utf-8"))
assert "theta_crit" in s and "tau_min" in s and "window_type_summary" in s
print("SMOKE_OK")
