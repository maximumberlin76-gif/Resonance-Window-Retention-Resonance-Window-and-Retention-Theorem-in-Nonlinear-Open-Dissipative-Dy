# v28.2 TRUE COHERENCE ACCUMULATION / SYNTHESIS THRESHOLD

## Core Thesis

Synthesis is not caused by an instantaneous threshold.

```text
Instantaneous spike ≠ synthesis
Fast overload ≈ chaos / explosion
Accumulated coherence over time ⇒ synthesis candidate
```

## Main Formula

```text
Theta(t0, tau) = ∫[C(t) - P(t) - D(t)] dt
```

Synthesis candidate exists only if:

```text
Theta >= Theta_crit
and
tau >= tau_min
```

## Window Types

A resonance window is never fully stationary in a nonlinear dissipative dynamic structure.

Minimum classes:

```text
1. quasi_stationary
2. floating
3. strong_drift
```

## Interpretation

- quasi_stationary:
  low drift; narrow corridor is acceptable.

- floating:
  moderate drift/volatility; requires tracking.

- strong_drift:
  pronounced drift; requires active drift compensation.

## Why Time Matters

Accumulation over time gives the structure room for:

```text
adaptation
internal reconfiguration
controlled scaling
```

Without time:

```text
short spike -> not synthesis
instant overload -> chaos / explosion
```

## Run

```bash
python scripts/engine_v28_2_coherence_accumulation.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/coherence_accumulation_summary.json
results/coherence_accumulation_trials.json
journal/session_journal_v28_2.md
```

## Limitation

Computational sandbox only.
