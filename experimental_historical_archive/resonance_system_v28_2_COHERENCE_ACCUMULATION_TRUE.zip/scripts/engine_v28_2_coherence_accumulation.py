#!/usr/bin/env python3
"""
v28.2 TRUE COHERENCE ACCUMULATION / SYNTHESIS THRESHOLD

Core correction:
Synthesis is not triggered by instantaneous C >= C_crit.
Synthesis requires accumulated structural coherence over time.

Invariant:
- if accumulation is too short -> spike / forced peak
- if accumulation is too fast / unstable -> chaos / explosion
- if accumulation persists over dwell time -> synthesis / scaling

Window classes:
1. quasi_stationary
2. floating
3. strong_drift

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def mean(xs):
    return sum(xs)/max(1,len(xs))

def classify_window(drift_ratio, volatility, cfg):
    if drift_ratio >= cfg["window_types"]["strong_drift_threshold"]:
        return "strong_drift"
    if volatility >= cfg["window_types"]["floating_volatility_threshold"]:
        return "floating"
    return "quasi_stationary"

def classify_outcome(theta, tau, overshoot_rate, chaos_index, cfg):
    if chaos_index >= cfg["thresholds"]["chaos_index"] or overshoot_rate >= cfg["thresholds"]["overshoot_chaos"]:
        return "chaos_or_explosion"
    if tau < cfg["thresholds"]["tau_min"]:
        return "spike_not_synthesis"
    if theta >= cfg["thresholds"]["theta_crit"] and tau >= cfg["thresholds"]["tau_min"]:
        return "synthesis_candidate"
    return "accumulation_incomplete"

def simulate_trial(seed, cfg):
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    # window family base
    base_center = rng.choice([76.4, 150.0, 458.4])
    mode_bias = rng.choice(["quasi_stationary", "floating", "strong_drift"])

    if mode_bias == "quasi_stationary":
        drift_amp = rng.uniform(0.02, 0.08)
        volatility = rng.uniform(0.001, 0.006)
    elif mode_bias == "floating":
        drift_amp = rng.uniform(0.10, 0.28)
        volatility = rng.uniform(0.010, 0.030)
    else:
        drift_amp = rng.uniform(0.35, 0.75)
        volatility = rng.uniform(0.025, 0.060)

    center = base_center
    C = rng.uniform(0.45, 0.72)
    P = rng.uniform(0.05, 0.12)
    D = rng.uniform(0.04, 0.10)

    theta = 0.0
    tau = 0
    max_tau = 0
    current_tau = 0
    overshoot_count = 0
    unstable_count = 0
    series = []

    for t in range(cycles):
        center += drift_amp * math.sin(2*math.pi*t/cfg["period"]) + rng.uniform(-volatility*base_center, volatility*base_center)

        # Coherence evolves slowly; fast jumps create overshoot/chaos risk.
        growth = cfg["coherence"]["growth"] * (1.0 - C)
        adaptation = cfg["coherence"]["adaptation_gain"] * current_tau / max(1, cfg["thresholds"]["tau_min"])
        disturbance = rng.uniform(-cfg["noise"], cfg["noise"])

        if rng.random() < cfg["events"]["overshoot_prob"]:
            disturbance += rng.uniform(cfg["events"]["overshoot_min"], cfg["events"]["overshoot_max"])
            overshoot_count += 1

        C_prev = C
        C = clamp(C + growth + adaptation - D*cfg["coherence"]["dissipation_weight"] - P*cfg["coherence"]["load_weight"] + disturbance)

        dC = abs(C - C_prev)
        if dC > cfg["thresholds"]["max_safe_dC"]:
            unstable_count += 1

        delta = C - P - D

        # Accumulation exists only when net coherence balance is positive and phase/tracking are implicitly stable.
        if delta > 0:
            theta += delta
            current_tau += 1
        else:
            max_tau = max(max_tau, current_tau)
            current_tau = 0

        max_tau = max(max_tau, current_tau)

        drift_ratio = abs(drift_amp) / max(1.0, abs(center))
        wtype = classify_window(drift_ratio, volatility, cfg)

        series.append({
            "t": t,
            "center": center,
            "window_type": wtype,
            "C": C,
            "P": P,
            "D": D,
            "delta": delta,
            "theta": theta,
            "current_tau": current_tau,
            "dC": dC,
        })

    tau = max_tau
    overshoot_rate = overshoot_count / cycles
    chaos_index = unstable_count / cycles
    final_window_type = max(["quasi_stationary","floating","strong_drift"], key=lambda wt: sum(1 for x in series if x["window_type"] == wt))

    outcome = classify_outcome(theta, tau, overshoot_rate, chaos_index, cfg)

    return {
        "seed": seed,
        "biased_mode": mode_bias,
        "final_window_type": final_window_type,
        "theta_accumulated": theta,
        "tau_max": tau,
        "overshoot_rate": overshoot_rate,
        "chaos_index": chaos_index,
        "outcome": outcome,
        "mean_C": mean([x["C"] for x in series]),
        "mean_delta": mean([x["delta"] for x in series]),
        "series": series
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    cfg = json.load(open("configs/config.json","r",encoding="utf-8"))

    rows = [simulate_trial(cfg["seed"] + i*100, cfg) for i in range(cfg["trials"])]

    by_outcome = {}
    by_type = {}
    for r in rows:
        by_outcome[r["outcome"]] = by_outcome.get(r["outcome"],0)+1
        by_type.setdefault(r["final_window_type"], []).append(r)

    type_summary = {}
    for wt, items in by_type.items():
        type_summary[wt] = {
            "count": len(items),
            "mean_theta": mean([x["theta_accumulated"] for x in items]),
            "mean_tau": mean([x["tau_max"] for x in items]),
            "synthesis_candidates": sum(1 for x in items if x["outcome"] == "synthesis_candidate"),
            "chaos_or_explosion": sum(1 for x in items if x["outcome"] == "chaos_or_explosion"),
        }

    synthesis = [r for r in rows if r["outcome"] == "synthesis_candidate"]
    chaos = [r for r in rows if r["outcome"] == "chaos_or_explosion"]

    summary = {
        "trials": len(rows),
        "theta_crit": cfg["thresholds"]["theta_crit"],
        "tau_min": cfg["thresholds"]["tau_min"],
        "outcome_counts": by_outcome,
        "window_type_summary": type_summary,
        "synthesis_candidates": len(synthesis),
        "chaos_or_explosion": len(chaos),
        "mean_theta_all": mean([r["theta_accumulated"] for r in rows]),
        "mean_tau_all": mean([r["tau_max"] for r in rows]),
        "main_conclusion": "synthesis_requires_coherence_accumulation_over_time",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"coherence_accumulation_summary.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"coherence_accumulation_trials.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "theta_crit": summary["theta_crit"],
        "tau_min": summary["tau_min"],
        "outcome_counts": summary["outcome_counts"],
        "window_type_summary": summary["window_type_summary"],
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
