# Session Journal — v28.2

## Step

v28.2 — Coherence Accumulation / Synthesis Threshold.

## User correction

Synthesis is not an instantaneous threshold.
The core is accumulation of structural integrity / coherence over time.

## Fixed invariants

1. There are at least three resonance-window regimes:
   - quasi_stationary
   - floating
   - strong_drift

2. Synthesis is a consequence of accumulated coherence over time.

3. Instantaneous overload is not synthesis.
   It is more likely chaos, explosion, or structural rupture.

## Added

- Theta accumulation integral
- tau_min dwell time
- theta_crit threshold
- chaos / overshoot rejection
- window-type summary

## Core Formula

Theta = ∫[C(t) - P(t) - D(t)] dt

Synthesis candidate if:
Theta >= Theta_crit and tau >= tau_min.

## Next Step

Use v28.2 as theoretical core for the big README:
Theorem of resonance -> theorem of resonance window -> accumulation law -> v1-v27 experimental path.
