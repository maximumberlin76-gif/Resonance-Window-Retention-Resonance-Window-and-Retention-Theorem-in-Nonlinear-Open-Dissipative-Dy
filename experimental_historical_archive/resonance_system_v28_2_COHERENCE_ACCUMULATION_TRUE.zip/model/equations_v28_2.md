# v28.2 Equations

## Net Coherence Balance

Delta(t) = C(t) - P(t) - D(t)

## Accumulation Integral

Theta(t0, tau) =
∫ from t0 to t0+tau [C(t) - P(t) - D(t)] dt

## Synthesis Candidate

Synthesis is possible if:

Theta >= Theta_crit
and
tau >= tau_min
and
chaos_index < chaos_limit

## Anti-condition

If tau is too short:
spike_not_synthesis

If accumulation is too violent:
chaos_or_explosion
