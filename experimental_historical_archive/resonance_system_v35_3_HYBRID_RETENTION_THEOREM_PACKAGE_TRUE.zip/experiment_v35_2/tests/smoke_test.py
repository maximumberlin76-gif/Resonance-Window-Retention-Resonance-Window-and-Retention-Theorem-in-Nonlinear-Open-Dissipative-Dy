#!/usr/bin/env python3
from pathlib import Path
import json
required = [
    "scripts/engine_v35_2_ar_he_h_deep_hybrid_tests.py",
    "results/ar_he_h_deep_hybrid_tests_summary.json",
    "results/ar_he_h_deep_hybrid_tests_trials.json",
    "results/ar_he_h_deep_hybrid_tests_summary.md",
    "docs/README.md",
    "model/equations_v35_2.md",
    "journal/session_journal_v35_2.md"
]
for item in required:
    p=Path(item)
    assert p.exists(), f"missing {item}"
    assert p.stat().st_size > 100, f"too small {item}"
s=json.load(open("results/ar_he_h_deep_hybrid_tests_summary.json","r",encoding="utf-8"))
assert s["system_class"]=="nonlinear dissipative open dynamic systems"
assert s["trials"] >= 500
print("SMOKE_OK")
