#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, random, math
from pathlib import Path

def mean(xs):
    return sum(xs) / max(1, len(xs))

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def gas_vector(seq, gases):
    retention = mean([gases[g]["retention"] for g in seq])
    response = mean([gases[g]["response"] for g in seq])
    drift = mean([gases[g]["drift"] for g in seq])
    diss = mean([gases[g]["dissipation"] for g in seq])
    argon_bonus = 0.12 if seq[0] == "argon" else 0.0
    return retention, response, drift, diss, argon_bonus

def simulate_trial(seed, scenario, channel_name, channel, cfg):
    rng = random.Random(seed)
    gases = cfg["gases"]
    th = cfg["thresholds"]

    retention, response, drift, diss, argon_bonus = gas_vector(scenario["sequence"], gases)
    stress = scenario["stress"]
    reduction = scenario["drive_reduction"]

    # Three-stage control:
    # stage 1 acoustic entry, stage 2 hybrid overlap, stage 3 EM retention after acoustic reduction.
    entry = channel["entry_gain"] * response * (1.0 - 0.25 * stress) + argon_bonus
    phase = channel["phase_precision"] * (0.55 + 0.45 * response) - 0.18 * drift * stress
    work = channel["entry_gain"] * channel["acoustic"] + 0.55 * channel["em"] * channel["retention_gain"]
    diss_loss = diss * channel["dissipation_penalty"] + 0.20 * stress + 0.08 * reduction

    noise = rng.gauss(0, 0.045)
    theta_N = clamp(0.25 + 0.55*entry + 0.45*work + noise - 0.40*diss_loss, 0, 1.5)

    balance = clamp(0.10 + 0.45*retention + 0.20*phase - 0.35*diss_loss + rng.gauss(0,0.035), -0.5, 1.2)

    retention_tail = clamp(
        retention * channel["retention_gain"]
        + 0.35 * channel["em"]
        - 0.30 * drift * stress
        - 0.22 * reduction
        + argon_bonus
        + rng.gauss(0, 0.04),
        0, 1
    )

    stable_periods = max(0, int(round(2 + 7*theta_N + 3*balance - 3*stress + rng.gauss(0,1.0))))
    collapse = clamp(0.20 + 0.55*drift*stress + 0.35*diss_loss - 0.40*retention_tail + rng.gauss(0,0.035), 0, 1)

    if (
        theta_N >= th["theta_crit"]
        and balance >= th["balance_crit"]
        and retention_tail >= th["retention_min"]
        and stable_periods >= th["stable_periods_min"]
        and collapse <= th["collapse_limit"]
    ):
        outcome = "valid_hybrid_resonance_window"
    elif theta_N >= th["theta_crit"] and retention_tail < th["retention_min"]:
        outcome = "accumulation_without_retention"
    elif theta_N < th["theta_crit"] and phase >= 0.65:
        outcome = "phase_alignment_without_work"
    elif collapse > th["collapse_limit"]:
        outcome = "collapse_after_drive_reduction"
    else:
        outcome = "no_window"

    return {
        "seed": seed,
        "scenario": scenario["name"],
        "sequence": scenario["sequence"],
        "channel": channel_name,
        "theta_N": round(theta_N, 6),
        "balance_periodic": round(balance, 6),
        "retention_tail": round(retention_tail, 6),
        "stable_periods": stable_periods,
        "collapse_risk": round(collapse, 6),
        "outcome": outcome
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    rows = []
    seed = cfg["seed"]
    n = cfg["monte_carlo_trials_per_scenario"]

    for sidx, scenario in enumerate(cfg["scenarios"]):
        for cname, channel in cfg["channels"].items():
            for i in range(n):
                rows.append(simulate_trial(seed + sidx*10000 + i*97 + len(cname), scenario, cname, channel, cfg))

    outcomes = {}
    by_channel = {}
    by_scenario = {}

    for r in rows:
        outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1
        by_channel.setdefault(r["channel"], []).append(r)
        by_scenario.setdefault(r["scenario"], []).append(r)

    def summarize(items):
        total = len(items)
        valid = sum(1 for x in items if x["outcome"] == "valid_hybrid_resonance_window")
        return {
            "count": total,
            "valid_count": valid,
            "valid_ratio": round(valid/max(1,total), 6),
            "mean_theta_N": round(mean([x["theta_N"] for x in items]), 6),
            "mean_balance_periodic": round(mean([x["balance_periodic"] for x in items]), 6),
            "mean_retention_tail": round(mean([x["retention_tail"] for x in items]), 6),
            "mean_collapse_risk": round(mean([x["collapse_risk"] for x in items]), 6),
            "outcomes": {k: sum(1 for x in items if x["outcome"] == k) for k in sorted(set(x["outcome"] for x in items))}
        }

    channel_summary = {k: summarize(v) for k,v in by_channel.items()}
    scenario_summary = {k: summarize(v) for k,v in by_scenario.items()}

    best_channels = sorted(channel_summary.items(), key=lambda kv: (kv[1]["valid_ratio"], kv[1]["mean_retention_tail"], -kv[1]["mean_collapse_risk"]), reverse=True)
    best_scenarios = sorted(scenario_summary.items(), key=lambda kv: (kv[1]["valid_ratio"], kv[1]["mean_theta_N"]), reverse=True)

    summary = {
        "system_class": cfg["system_class"],
        "model": cfg["model"],
        "trials": len(rows),
        "outcomes": outcomes,
        "channel_summary": channel_summary,
        "scenario_summary": scenario_summary,
        "best_channels": best_channels,
        "best_scenarios": best_scenarios,
        "main_conclusion": "hybrid_em_retention_and_hybrid_balanced_are_the_best_candidates_for_deep_Ar_He_H_testing",
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"ar_he_h_deep_hybrid_tests_summary.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"ar_he_h_deep_hybrid_tests_trials.json","w",encoding="utf-8"), indent=2, ensure_ascii=False)

    md = "# Ar-He-H Deep Hybrid Tests — Summary\n\n"
    md += f"Total trials: {len(rows)}\n\n"
    md += "## Best channels\n\n"
    for name, s in best_channels:
        md += f"- {name}: valid_ratio={s['valid_ratio']}, retention={s['mean_retention_tail']}, collapse={s['mean_collapse_risk']}\n"
    md += "\n## Best scenarios\n\n"
    for name, s in best_scenarios:
        md += f"- {name}: valid_ratio={s['valid_ratio']}, theta_N={s['mean_theta_N']}\n"
    (out/"ar_he_h_deep_hybrid_tests_summary.md").write_text(md, encoding="utf-8")

    print(json.dumps({
        "trials": len(rows),
        "outcomes": outcomes,
        "best_channels": best_channels[:3],
        "best_scenarios": best_scenarios[:3],
        "main_conclusion": summary["main_conclusion"]
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
