# v35.2 — Ar-He-H Deep Hybrid Tests

## Abstract

This module deepens the hybrid control model:

```text
Argon → Helium → Hydrogen
```

with a larger Monte Carlo test matrix across:

- acoustic-only,
- EM-only,
- hybrid-soft,
- hybrid-balanced,
- hybrid-EM-retention.

The system class remains:

```text
nonlinear dissipative open dynamic systems
```

## Core Principle

```text
acoustic = economical entry into Ω(t)
EM = retention / Ω_ret stabilization
hybrid = best candidate for Θ_N + retention
```

## Tested Failure Modes

```text
phase alignment without work
accumulation without retention
collapse after drive reduction
no window
valid hybrid resonance window
```

## Criterion

```text
Θ_N >= Θ_crit
and
(C − P)_periodic > 0
and
retention_tail >= threshold
and
collapse_risk <= threshold
```

## Run

```bash
python scripts/engine_v35_2_ar_he_h_deep_hybrid_tests.py --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/ar_he_h_deep_hybrid_tests_summary.json
results/ar_he_h_deep_hybrid_tests_trials.json
results/ar_he_h_deep_hybrid_tests_summary.md
```
