# v35.2 Equations

F_total(t) = F_acoustic(t) + F_EM(t)

valid_hybrid_window =
Θ_N >= Θ_crit
and
(C - P)_periodic > 0
and
retention_tail >= R_retention_min
and
collapse_risk <= collapse_limit

Failure modes:
- phase_alignment_without_work
- accumulation_without_retention
- collapse_after_drive_reduction
- no_window
