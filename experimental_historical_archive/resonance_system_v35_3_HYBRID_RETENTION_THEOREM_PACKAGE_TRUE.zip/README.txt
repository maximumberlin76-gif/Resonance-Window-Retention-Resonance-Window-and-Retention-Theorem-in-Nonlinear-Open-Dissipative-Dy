v35.3 HYBRID RETENTION PACKAGE

Contains:
- Full experiment (v35.2 deep hybrid tests)
- Hybrid retention principle text

Core idea:
acoustic entry + EM retention = stable Ω_ret

System class:
nonlinear dissipative open dynamic systems
