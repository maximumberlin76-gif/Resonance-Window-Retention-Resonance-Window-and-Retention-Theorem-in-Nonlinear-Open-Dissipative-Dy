#!/usr/bin/env python3
"""
Resonance System v24 TRUE ADVERSARIAL / CHAOTIC STRESS

v23 model-based control worked under clean prediction.
v24 attacks the predictor.

Adds:
- rare phase/window jumps
- fake drift injection
- heavy-tail noise
- observation latency
- confidence trap
- fallback efficiency measurement
- shock recovery time

Computational sandbox only.
"""

from __future__ import annotations
import argparse, json, math, random
from pathlib import Path
from typing import Dict, Any, List

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def mean(xs: List[float]) -> float:
    return sum(xs) / max(1, len(xs))

def heavy_noise(rng: random.Random, base: float, tail_prob: float, tail_scale: float) -> float:
    if rng.random() < tail_prob:
        return rng.uniform(-base * tail_scale, base * tail_scale)
    return rng.uniform(-base, base)

def predict(history: List[float], cfg: Dict[str, Any], fake_drift: float, confidence_bias: float) -> Dict[str, float]:
    h = history[-cfg["predictor"]["history"]:]
    if len(h) < 2:
        drift = 0.0
        curvature = 0.0
    else:
        drift = (h[-1] - h[0]) / max(1, len(h)-1)
        curvature = 0.0
        if len(h) >= 3:
            prev = (h[-2] - h[0]) / max(1, len(h)-2)
            curvature = drift - prev

    observed_drift = drift + fake_drift
    predicted_center = h[-1] + cfg["predictor"]["lead"] * observed_drift + cfg["predictor"]["curvature_gain"] * curvature

    uncertainty = min(1.0, abs(curvature + fake_drift) / max(1.0, abs(h[-1])) * cfg["predictor"]["uncertainty_gain"])
    confidence = clamp(1.0 - uncertainty + confidence_bias)
    return {"predicted_center": predicted_center, "drift": observed_drift, "curvature": curvature, "confidence": confidence}

def fallback_control(f0: float, predicted_center: float, cfg: Dict[str, Any]) -> float:
    error = predicted_center - f0
    max_delta = abs(predicted_center) * cfg["fallback"]["max_delta_ratio"]
    return clamp(cfg["fallback"]["kp"] * error, -max_delta, max_delta)

def choose_control(f0: float, C: float, predicted_center: float, confidence: float, cfg: Dict[str, Any]) -> Dict[str, float]:
    err = predicted_center - f0
    max_delta = abs(predicted_center) * cfg["model"]["max_control_ratio"]
    candidates = [-max_delta, -0.5*max_delta, 0.0, 0.5*max_delta, max_delta, clamp(err, -max_delta, max_delta)]
    scored = []
    for u in candidates:
        future_f0 = f0 + u
        tracking = abs(predicted_center - future_f0) / max(1.0, abs(predicted_center))
        energy = abs(u) / max(1.0, abs(predicted_center))
        instability = max(0.0, cfg["model"]["min_C"] - C)
        J = cfg["cost"]["tracking"]*tracking + cfg["cost"]["energy"]*energy + cfg["cost"]["instability"]*instability - cfg["cost"]["confidence"]*confidence
        scored.append({"control": u, "J": J})
    best = min(scored, key=lambda x: x["J"])
    return {"control": best["control"], "J": best["J"], "candidates": scored}

def simulate_trial(trial: Dict[str, Any], cfg: Dict[str, Any], seed: int) -> Dict[str, Any]:
    rng = random.Random(seed)
    cycles = cfg["cycles"]

    true_center = trial.get("f_center", rng.choice([76.4, 150.0, 458.4]))
    f0 = true_center
    C = clamp(trial["reentry_norm"] - trial["new_edge_penalty"])

    observed_history = [true_center]
    latency_buffer = [true_center] * max(1, cfg["adversarial"]["latency_steps"])

    fallback_count = 0
    lock_loss_count = 0
    shock_events = 0
    recovered_shocks = 0
    shock_recovery_times = []
    active_shock_start = None
    false_prediction_damage = 0.0
    collapsed = False
    collapse_at = None

    series = []

    for t in range(cycles):
        # Base floating dynamics.
        drift = cfg["floating"]["drift_rate"] * math.sin(2 * math.pi * t / cfg["floating"]["period"])
        noise = heavy_noise(rng, cfg["noise"], cfg["adversarial"]["heavy_tail_prob"], cfg["adversarial"]["tail_scale"])
        true_center += drift + noise

        jump = 0.0
        if rng.random() < cfg["adversarial"]["jump_prob"]:
            jump = rng.choice([-1, 1]) * rng.uniform(cfg["adversarial"]["jump_min"], cfg["adversarial"]["jump_max"])
            true_center += jump
            shock_events += 1
            active_shock_start = t

        latency_buffer.append(true_center)
        observed_center = latency_buffer.pop(0)

        fake_drift = 0.0
        confidence_bias = 0.0
        fake_signal = False

        if rng.random() < cfg["adversarial"]["fake_drift_prob"]:
            fake_drift = rng.choice([-1, 1]) * rng.uniform(cfg["adversarial"]["fake_drift_min"], cfg["adversarial"]["fake_drift_max"])
            fake_signal = True

        if rng.random() < cfg["adversarial"]["confidence_trap_prob"]:
            confidence_bias = cfg["adversarial"]["confidence_trap_bias"]

        observed_history.append(observed_center)
        pred = predict(observed_history, cfg, fake_drift=fake_drift, confidence_bias=confidence_bias)

        # fallback if low confidence or shock tracking too bad
        tracking_before = abs(true_center - f0) / max(1.0, abs(true_center))
        force_fallback = tracking_before > cfg["fallback"]["force_tracking_error"]

        if pred["confidence"] < cfg["model"]["min_confidence"] or force_fallback:
            control = fallback_control(f0, pred["predicted_center"], cfg)
            used_fallback = True
            fallback_count += 1
            J = None
        else:
            choice = choose_control(f0, C, pred["predicted_center"], pred["confidence"], cfg)
            control = choice["control"]
            used_fallback = False
            J = choice["J"]

        # adversarial false prediction damage
        predicted_tracking = abs(pred["predicted_center"] - (f0 + control)) / max(1.0, abs(pred["predicted_center"]))
        true_tracking_after_control = abs(true_center - (f0 + control)) / max(1.0, abs(true_center))
        if fake_signal and true_tracking_after_control > predicted_tracking:
            false_prediction_damage += true_tracking_after_control - predicted_tracking

        # control limiter
        max_control = abs(true_center) * cfg["model"]["max_control_ratio"]
        control = clamp(control, -max_control, max_control)
        f0 += control
        f1 = 2.0 * f0
        f2 = 0.5 * f0

        tracking = abs(true_center - f0) / max(1.0, abs(true_center))
        corridor = cfg["floating"]["base_corridor"] + cfg["floating"]["max_extra_corridor"]
        in_corridor = tracking <= corridor

        if not in_corridor:
            lock_loss_count += 1

        # shock recovery detection
        if active_shock_start is not None and in_corridor:
            recovered_shocks += 1
            shock_recovery_times.append(t - active_shock_start)
            active_shock_start = None

        D_t = cfg["dissipation_rate"] * (1.0 + 0.010*t)
        repair = cfg["recovery_gain"] * max(0.0, 1.0-C)
        lock_support = cfg["floating"]["lock_support"]*(1.0-tracking) if in_corridor else -cfg["floating"]["lock_penalty"]
        confidence_support = cfg["model"]["confidence_support"] * pred["confidence"]
        fallback_support = cfg["fallback"]["fallback_support"] if used_fallback else 0.0
        adversarial_penalty = cfg["adversarial"]["false_damage_penalty"] * max(0.0, true_tracking_after_control - predicted_tracking)

        C = clamp(C + repair + lock_support + confidence_support + fallback_support - D_t - adversarial_penalty + rng.uniform(-cfg["noise"], cfg["noise"]))

        if C < cfg["collapse_threshold"] and not collapsed:
            collapsed = True
            collapse_at = t

        series.append({
            "t": t,
            "true_center": true_center,
            "observed_center": observed_center,
            "predicted_center": pred["predicted_center"],
            "confidence": pred["confidence"],
            "fake_signal": fake_signal,
            "fake_drift": fake_drift,
            "confidence_bias": confidence_bias,
            "jump": jump,
            "f0": f0,
            "f1": f1,
            "f2": f2,
            "control": control,
            "used_fallback": used_fallback,
            "J": J,
            "tracking_error": tracking,
            "predicted_tracking": predicted_tracking,
            "in_corridor": in_corridor,
            "C": C,
            "D_t": D_t,
            "repair": repair,
            "lock_support": lock_support,
            "confidence_support": confidence_support,
            "fallback_support": fallback_support,
            "adversarial_penalty": adversarial_penalty
        })

    Cs = [x["C"] for x in series]
    tracking_errors = [x["tracking_error"] for x in series]
    confidences = [x["confidence"] for x in series]

    mean_C = mean(Cs)
    var_C = mean([(x-mean_C)**2 for x in Cs])
    mean_tracking = mean(tracking_errors)
    mean_confidence = mean(confidences)
    lock_loss_rate = lock_loss_count / cycles
    fallback_rate = fallback_count / cycles
    shock_recovery_time = mean(shock_recovery_times) if shock_recovery_times else None
    shock_recovery_rate = recovered_shocks / max(1, shock_events)

    fallback_efficiency = shock_recovery_rate * (1.0 - lock_loss_rate)

    S_adv = (
        mean_C
        - var_C
        - 0.45*mean_tracking
        - 0.35*lock_loss_rate
        - 0.20*(false_prediction_damage / max(1, cycles))
        + 0.12*fallback_efficiency
        + 0.08*mean_confidence
    )

    if collapsed:
        label = "adversarial_collapse"
    elif S_adv >= cfg["thresholds"]["adversarial_stable"] and shock_recovery_rate >= cfg["thresholds"]["min_shock_recovery"]:
        label = "adversarial_stable"
    elif S_adv >= cfg["thresholds"]["adversarial_metastable"]:
        label = "adversarial_metastable"
    else:
        label = "adversarial_weak"

    return {
        "mean_C": mean_C,
        "var_C": var_C,
        "mean_tracking_error": mean_tracking,
        "mean_confidence": mean_confidence,
        "lock_loss_rate": lock_loss_rate,
        "fallback_rate": fallback_rate,
        "shock_events": shock_events,
        "recovered_shocks": recovered_shocks,
        "shock_recovery_rate": shock_recovery_rate,
        "shock_recovery_time": shock_recovery_time,
        "false_prediction_damage": false_prediction_damage,
        "fallback_efficiency": fallback_efficiency,
        "S_adversarial": S_adv,
        "collapsed": collapsed,
        "collapse_at": collapse_at,
        "label": label,
        "series": series
    }

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="results/model_based_trials.json")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cfg = json.load(open("configs/config.json", "r", encoding="utf-8"))
    trials = json.load(open(args.input, "r", encoding="utf-8"))

    rows = []
    for idx, trial in enumerate(trials):
        base = {
            "trial_index": trial.get("trial_index", idx),
            "previous_label": trial.get("label", "model_unknown"),
            "reentry_norm": trial.get("reentry_norm", 0.84),
            "new_edge_penalty": trial.get("new_edge_penalty", 0.09),
            "f_center": [76.4, 150.0, 458.4][idx % 3],
        }
        sim = simulate_trial(base, cfg, cfg["seed"] + idx * 100)
        rows.append({**base, **sim})

    stable = [r for r in rows if r["label"] == "adversarial_stable"]
    meta = [r for r in rows if r["label"] == "adversarial_metastable"]
    weak = [r for r in rows if r["label"] == "adversarial_weak"]
    collapse = [r for r in rows if r["label"] == "adversarial_collapse"]

    summary = {
        "trials": len(rows),
        "adversarial_stable": len(stable),
        "adversarial_metastable": len(meta),
        "adversarial_weak": len(weak),
        "adversarial_collapse": len(collapse),
        "mean_S_adversarial": mean([r["S_adversarial"] for r in rows]),
        "mean_tracking_error": mean([r["mean_tracking_error"] for r in rows]),
        "mean_lock_loss_rate": mean([r["lock_loss_rate"] for r in rows]),
        "mean_fallback_rate": mean([r["fallback_rate"] for r in rows]),
        "mean_shock_recovery_rate": mean([r["shock_recovery_rate"] for r in rows]),
        "mean_false_prediction_damage": mean([r["false_prediction_damage"] for r in rows]),
        "label": "adversarial_resilient" if len(stable)+len(meta) >= len(rows)*0.70 and len(collapse) == 0 else "adversarial_limited",
        "top_trials": sorted(rows, key=lambda x: x["S_adversarial"], reverse=True)[:10],
        "all_trials": rows
    }

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)
    json.dump(summary, open(out/"adversarial_stress_summary.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(rows, open(out/"adversarial_stress_trials.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps({
        "trials": summary["trials"],
        "adversarial_stable": summary["adversarial_stable"],
        "adversarial_metastable": summary["adversarial_metastable"],
        "adversarial_weak": summary["adversarial_weak"],
        "adversarial_collapse": summary["adversarial_collapse"],
        "mean_S_adversarial": summary["mean_S_adversarial"],
        "mean_fallback_rate": summary["mean_fallback_rate"],
        "mean_shock_recovery_rate": summary["mean_shock_recovery_rate"],
        "label": summary["label"]
    }, indent=2))

if __name__ == "__main__":
    main()
