# v24 Metrics

S_adversarial =
mean_C
- var_C
- 0.45 * mean_tracking_error
- 0.35 * lock_loss_rate
- 0.20 * false_prediction_damage_per_cycle
+ 0.12 * fallback_efficiency
+ 0.08 * mean_confidence

fallback_efficiency =
shock_recovery_rate * (1 - lock_loss_rate)
