#!/usr/bin/env python3
from pathlib import Path
import json
for p in ["scripts/engine_v24_adversarial_stress.py","results/adversarial_stress_summary.json","results/adversarial_stress_trials.json","docs/README.md"]:
    fp = Path(p)
    assert fp.exists() and fp.stat().st_size > 100, p
s = json.load(open("results/adversarial_stress_summary.json","r",encoding="utf-8"))
assert "mean_fallback_rate" in s and "mean_shock_recovery_rate" in s
print("SMOKE_OK")
