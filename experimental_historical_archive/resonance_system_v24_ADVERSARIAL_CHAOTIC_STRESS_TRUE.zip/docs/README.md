# Resonance System v24 TRUE ADVERSARIAL / CHAOTIC STRESS

## Purpose

v23 succeeded under clean model-based prediction.  
v24 attacks the predictor and the control loop.

The purpose is not to improve metrics under comfort.
The purpose is to expose weak points.

## Attacks Added

1. Phase / window jumps  
   Rare sudden movement of the resonance window.

2. Fake drift  
   The predictor receives misleading drift.

3. Confidence trap  
   The model may be overconfident when it should not be.

4. Heavy-tail noise  
   Noise sometimes produces large outliers.

5. Observation latency  
   The controller sees delayed window position.

## New Metrics

- shock_recovery_rate
- shock_recovery_time
- false_prediction_damage
- fallback_rate
- fallback_efficiency
- S_adversarial

## Run

```bash
python scripts/generate_model_seed.py
python scripts/engine_v24_adversarial_stress.py --input results/model_based_trials.json --outdir results
python tests/smoke_test.py
```

## Outputs

```text
results/adversarial_stress_summary.json
results/adversarial_stress_trials.json
validation/triple_validation_summary.json
journal/session_journal_v24.md
```

## Interpretation

- adversarial_stable:
  survives shocks and fake prediction.

- adversarial_metastable:
  survives but with fragility.

- adversarial_weak:
  partial survival, poor recovery.

- adversarial_collapse:
  coherence collapse.

## Limitation

Computational sandbox only.
