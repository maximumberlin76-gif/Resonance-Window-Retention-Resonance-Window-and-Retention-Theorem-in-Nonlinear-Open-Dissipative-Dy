
import numpy as np

class ResonanceSystem:
    def __init__(self, N=20):
        self.N = N
        self.theta = np.random.uniform(0, 2*np.pi, N)
        self.omega = np.random.uniform(0.9,1.1,N)
        self.K = 0.5

    def order_param(self):
        return np.abs(np.mean(np.exp(1j*self.theta)))

    def step(self, f0, f1, f2, A, dt=0.05):
        drive = A*(np.sin(2*np.pi*f0*dt)+
                   np.sin(2*np.pi*f1*dt)+
                   np.sin(2*np.pi*f2*dt))
        for i in range(self.N):
            coupling = np.sum(np.sin(self.theta - self.theta[i]))
            self.theta[i] += (self.omega[i] + self.K*coupling/self.N + drive)*dt

    def run(self, f0,f1,f2,A,steps=200):
        R_vals=[]
        for _ in range(steps):
            self.step(f0,f1,f2,A)
            R_vals.append(self.order_param())
        return np.mean(R_vals)

def retention_test(sys, f0,f1,f2,A):
    R_on = sys.run(f0,f1,f2,A)
    R_off = sys.run(0,0,0,0)
    return R_on, R_off

if __name__ == "__main__":
    sys = ResonanceSystem()
    results=[]
    for f in [50,150,300,600]:
        R_on,R_off = retention_test(sys,f,f/2,f*2,0.5)
        results.append({"f":f,"R_on":R_on,"R_off":R_off})
    print(results)
